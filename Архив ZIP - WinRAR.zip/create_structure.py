import os
import itertools

# Создаем структуру папок
structure = {
    "level_hunter_bot": [
        # Основные файлы
        ["README.md"],
        ["pyproject.toml"],
        ["requirements.txt"],
        ["requirements-dev.txt"],
        [".env.example"],
        [".gitignore"],
        ["docker-compose.yml"],
        ["Dockerfile"],
        ["alembic.ini"],
        ["main.py"],
        ["run_bot.py"],

        # CONFIGS
        ["CONFIGS", "__init__.py"],
        ["CONFIGS", "base.yaml"],
        ["CONFIGS", "development.yaml"],
        ["CONFIGS", "production.yaml"],
        ["CONFIGS", "bot.yaml"],
        ["CONFIGS", "logging.yaml"],
        ["CONFIGS", "risk.yaml"],
        ["CONFIGS", "strategies", "__init__.py"],
        ["CONFIGS", "strategies", "level_hunter.yaml"],
        ["CONFIGS", "strategies", "common.yaml"],

        # INFRA
        ["INFRA", "__init__.py"],
        ["INFRA", "exchange", "__init__.py"],
        ["INFRA", "exchange", "base.py"],
        ["INFRA", "exchange", "binance", "__init__.py"],
        ["INFRA", "exchange", "binance", "client.py"],
        ["INFRA", "exchange", "binance", "websocket.py"],
        ["INFRA", "exchange", "binance", "models.py"],
        ["INFRA", "exchange", "binance", "utils.py"],
        ["INFRA", "database", "__init__.py"],
        ["INFRA", "database", "redis_cache.py"],
        ["INFRA", "database", "postgres.py"],
        ["INFRA", "database", "migrations", "__init__.py"],
        ["INFRA", "database", "migrations", "versions", "001_initial.py"],
        ["INFRA", "monitoring", "__init__.py"],
        ["INFRA", "monitoring", "logger.py"],
        ["INFRA", "monitoring", "metrics.py"],
        ["INFRA", "monitoring", "health_check.py"],

        # DOMAIN
        ["DOMAIN", "__init__.py"],
        ["DOMAIN", "interfaces", "__init__.py"],
        ["DOMAIN", "interfaces", "repositories.py"],
        ["DOMAIN", "interfaces", "exchange_client.py"],
        ["DOMAIN", "interfaces", "ml_predictor.py"],
        ["DOMAIN", "models", "__init__.py"],
        ["DOMAIN", "models", "candle.py"],
        ["DOMAIN", "models", "order.py"],
        ["DOMAIN", "models", "position.py"],
        ["DOMAIN", "models", "signal.py"],
        ["DOMAIN", "models", "portfolio.py"],
        ["DOMAIN", "models", "market_state.py"],
        ["DOMAIN", "indicators", "__init__.py"],
        ["DOMAIN", "indicators", "ema.py"],
        ["DOMAIN", "indicators", "rsi.py"],
        ["DOMAIN", "indicators", "macd.py"],
        ["DOMAIN", "indicators", "atr.py"],
        ["DOMAIN", "indicators", "bollinger_bands.py"],
        ["DOMAIN", "indicators", "volatility.py"],
        ["DOMAIN", "strategies", "__init__.py"],
        ["DOMAIN", "strategies", "base.py"],
        ["DOMAIN", "strategies", "level_hunter.py"],
        ["DOMAIN", "strategies", "mean_reversion.py"],
        ["DOMAIN", "risk", "__init__.py"],
        ["DOMAIN", "risk", "risk_engine.py"],
        ["DOMAIN", "risk", "level_hunter_risk.py"],
        ["DOMAIN", "risk", "kill_switch.py"],
        ["DOMAIN", "services", "__init__.py"],
        ["DOMAIN", "services", "signal_engine.py"],
        ["DOMAIN", "services", "strategy_engine.py"],
        ["DOMAIN", "services", "execution_engine.py"],
        ["DOMAIN", "events", "__init__.py"],
        ["DOMAIN", "events", "event_types.py"],
        ["DOMAIN", "events", "event_bus.py"],

        # DATA
        ["DATA", "__init__.py"],
        ["DATA", "feeds", "__init__.py"],
        ["DATA", "feeds", "market_feed.py"],
        ["DATA", "feeds", "orderbook_feed.py"],
        ["DATA", "repositories", "__init__.py"],
        ["DATA", "repositories", "market_repository.py"],
        ["DATA", "repositories", "portfolio_repository.py"],
        ["DATA", "loaders", "__init__.py"],
        ["DATA", "loaders", "historical_loader.py"],

        # ML
        ["ML", "__init__.py"],
        ["ML", "features", "__init__.py"],
        ["ML", "features", "builder.py"],
        ["ML", "features", "scalers.py"],
        ["ML", "models", "__init__.py"],
        ["ML", "models", "lstm.py"],
        ["ML", "models", "ensemble.py"],
        ["ML", "training", "__init__.py"],
        ["ML", "training", "trainer.py"],
        ["ML", "inference", "__init__.py"],
        ["ML", "inference", "realtime_predictor.py"],

        # ENGINE
        ["ENGINE", "__init__.py"],
        ["ENGINE", "dependency_container.py"],
        ["ENGINE", "orchestrator.py"],
        ["ENGINE", "scheduler.py"],
        ["ENGINE", "state_manager.py"],
        ["ENGINE", "error_handler.py"],
        ["ENGINE", "feature_flags.py"],
        ["ENGINE", "app.py"],

        # EXECUTION
        ["EXECUTION", "__init__.py"],
        ["EXECUTION", "order_manager.py"],
        ["EXECUTION", "position_manager.py"],
        ["EXECUTION", "trade_executor.py"],
        ["EXECUTION", "level_hunter_executor.py"],

        # API
        ["API", "__init__.py"],
        ["API", "rest", "__init__.py"],
        ["API", "rest", "server.py"],
        ["API", "rest", "routes", "__init__.py"],
        ["API", "rest", "routes", "trading.py"],
        ["API", "rest", "routes", "system.py"],

        # UTILS
        ["UTILS", "__init__.py"],
        ["UTILS", "config_loader.py"],
        ["UTILS", "serializers.py"],
        ["UTILS", "time.py"],
        ["UTILS", "math_tools.py"],
        ["UTILS", "decorators.py"],
        ["UTILS", "async_tools.py"],
        ["UTILS", "error_handling.py"],

        # TESTS
        ["TESTS", "__init__.py"],
        ["TESTS", "conftest.py"],
        ["TESTS", "unit", "__init__.py"],
        ["TESTS", "unit", "test_level_hunter.py"],
        ["TESTS", "unit", "test_risk_engine.py"],
        ["TESTS", "unit", "test_indicators.py"],
        ["TESTS", "integration", "__init__.py"],
        ["TESTS", "integration", "test_trading_flow.py"],
        ["TESTS", "integration", "test_exchange.py"],
        ["TESTS", "fixtures", "__init__.py"],
        ["TESTS", "fixtures", "market_data.py"],
        ["TESTS", "fixtures", "strategies.py"],

        # SCRIPTS
        ["SCRIPTS", "deploy", "build_docker.sh"],
        ["SCRIPTS", "deploy", "deploy.sh"],
        ["SCRIPTS", "monitoring", "setup.sh"],
        ["SCRIPTS", "migration", "run_migrations.sh"],
    ]
}


def create_structure():
    base_dir = "level_hunter_bot"

    for path_parts in structure[base_dir]:
        full_path = os.path.join(base_dir, *path_parts)
        dir_path = os.path.dirname(full_path)

        # Создаем папки
        os.makedirs(dir_path, exist_ok=True)

        # Создаем файлы
        if full_path.endswith('.py') or full_path.endswith('.sh') or full_path.endswith('.md') or full_path.endswith(
                '.txt') or full_path.endswith('.yml') or full_path.endswith('.yaml') or full_path.endswith(
                '.ini') or full_path.endswith('.toml') or full_path.endswith('.example') or full_path.endswith(
                '.gitignore'):
            with open(full_path, 'w') as f:
                if full_path.endswith('__init__.py'):
                    f.write('"""Module initialization."""\n')
                elif full_path.endswith('.sh'):
                    f.write('#!/bin/bash\n\n')
                else:
                    f.write(f'# {os.path.basename(full_path)}\n')

    print("✅ Структура проекта создана успешно!")
    print(f"📁 Папка: {base_dir}")
    print("🎯 Теперь можно начать заполнять файлы кодом")


if __name__ == "__main__":
    create_structure()