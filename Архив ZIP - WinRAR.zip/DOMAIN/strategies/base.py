"""
Базовый класс для всех торговых стратегий
"""

from abc import ABC, abstractmethod
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Any
from enum import Enum
from pydantic import BaseModel, Field

from domain.models.candle import Candle
from domain.models.signal import Signal, SignalType, SignalStrength
from domain.models.order import Order, OrderSide, OrderType


class StrategyStatus(Enum):
    """Статус стратегии"""
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    STOPPED = "STOPPED"
    ERROR = "ERROR"


class StrategySignal(BaseModel):
    """Сигнал стратегии"""
    symbol: str
    signal_type: SignalType
    strength: SignalStrength
    price_level: Decimal
    stop_loss: Optional[Decimal] = None
    take_profit: Optional[Decimal] = None
    confidence: Decimal = Field(..., ge=0, le=1)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class StrategyConfig(BaseModel):
    """Базовая конфигурация стратегии"""
    name: str
    version: str = "1.0.0"
    enabled: bool = True
    symbols: List[str] = Field(default_factory=list)

    # Risk параметры
    max_position_size: Decimal = Field(default=Decimal('2.0'), ge=0.1, le=10.0)
    max_open_orders: int = Field(default=5, ge=1, le=20)
    daily_loss_limit: Decimal = Field(default=Decimal('5.0'), ge=1.0, le=20.0)

    # Trading параметры
    order_type: OrderType = OrderType.LIMIT
    use_stop_orders: bool = True
    time_in_force: str = "GTC"

    class Config:
        json_encoders = {
            Decimal: str,
            datetime: lambda v: v.isoformat()
        }


class BaseStrategy(ABC):
    """
    Абстрактный базовый класс для всех торговых стратегий
    Определяет общий интерфейс и реализует общую логику
    """

    def __init__(self, config: StrategyConfig):
        self.config = config
        self.status: StrategyStatus = StrategyStatus.ACTIVE
        self._performance_metrics: Dict[str, Any] = {}
        self._signals_generated: int = 0
        self._orders_created: int = 0
        self._last_analysis_time: Optional[datetime] = None

        # История сигналов и сделок
        self._signal_history: List[StrategySignal] = []
        self._order_history: List[str] = []  # order IDs

    @property
    def name(self) -> str:
        """Название стратегии"""
        return self.config.name

    @property
    def is_active(self) -> bool:
        """Активна ли стратегия"""
        return self.status == StrategyStatus.ACTIVE

    @property
    def performance_metrics(self) -> Dict[str, Any]:
        """Метрики производительности стратегии"""
        return self._performance_metrics.copy()

    @abstractmethod
    async def analyze_market(self, symbol: str, candles: List[Candle]) -> List[StrategySignal]:
        """
        Анализирует рынок и генерирует торговые сигналы

        Args:
            symbol: Торговая пара
            candles: Список свечей для анализа

        Returns:
            List[StrategySignal]: Список торговых сигналов
        """
        pass

    @abstractmethod
    def calculate_position_size(self, signal: StrategySignal, portfolio_balance: Decimal) -> Decimal:
        """
        Рассчитывает размер позиции для сигнала

        Args:
            signal: Торговый сигнал
            portfolio_balance: Баланс портфеля

        Returns:
            Decimal: Размер позиции
        """
        pass

    async def generate_orders(self, signal: StrategySignal, portfolio_balance: Decimal) -> List[Order]:
        """
        Генерирует ордера на основе сигнала

        Args:
            signal: Торговый сигнал
            portfolio_balance: Баланс портфеля

        Returns:
            List[Order]: Список ордеров для исполнения
        """
        if not self.is_active:
            return []

        # Рассчитываем размер позиции
        position_size = self.calculate_position_size(signal, portfolio_balance)

        if position_size <= Decimal('0'):
            return []

        # Создаем основной ордер
        orders = []

        main_order = Order(
            symbol=signal.symbol,
            side=OrderSide.BUY if "BUY" in signal.signal_type.value else OrderSide.SELL,
            order_type=self.config.order_type,
            quantity=position_size,
            price=signal.price_level,
            client_order_id=f"{self.name}_{signal.symbol}_{datetime.utcnow().timestamp()}",
            strategy=self.name,
            level_price=signal.price_level,
            level_type=signal.metadata.get('level_type', 'UNKNOWN'),
            expiry_time=datetime.utcnow().replace(hour=23, minute=59, second=59)
        )

        orders.append(main_order)

        # Добавляем стоп-лосс ордер если включено
        if self.config.use_stop_orders and signal.stop_loss:
            stop_order = Order(
                symbol=signal.symbol,
                side=OrderSide.SELL if "BUY" in signal.signal_type.value else OrderSide.BUY,
                order_type=OrderType.STOP_LOSS_LIMIT,
                quantity=position_size,
                price=signal.stop_loss,
                stop_price=signal.stop_loss,
                client_order_id=f"{self.name}_{signal.symbol}_STOP_{datetime.utcnow().timestamp()}",
                strategy=self.name,
                metadata={'is_stop_loss': True, 'parent_signal': signal.model_dump()}
            )
            orders.append(stop_order)

        self._orders_created += len(orders)
        self._order_history.extend([order.order_id for order in orders])

        return orders

    def validate_signal(self, signal: StrategySignal) -> bool:
        """
        Валидирует сигнал перед исполнением

        Args:
            signal: Сигнал для валидации

        Returns:
            bool: True если сигнал валиден
        """
        # Базовая валидация
        if signal.confidence < Decimal('0.6'):
            return False

        if signal.price_level <= Decimal('0'):
            return False

        # Проверяем лимиты стратегии
        if len(self._signal_history) >= self.config.max_open_orders:
            return False

        # Проверяем, не было ли недавно похожего сигнала
        recent_signals = [s for s in self._signal_history
                          if s.symbol == signal.symbol and
                          (datetime.utcnow() - s.timestamp).total_seconds() < 3600]  # 1 hour

        if len(recent_signals) >= 3:  # Максимум 3 сигнала в час на символ
            return False

        return True

    def update_performance_metrics(self, pnl: Decimal, is_win: bool) -> None:
        """
        Обновляет метрики производительности

        Args:
            pnl: Прибыль/убыток от сделки
            is_win: Была ли сделка прибыльной
        """
        if 'total_trades' not in self._performance_metrics:
            self._performance_metrics = {
                'total_trades': 0,
                'winning_trades': 0,
                'losing_trades': 0,
                'total_pnl': Decimal('0'),
                'win_rate': Decimal('0'),
                'avg_win': Decimal('0'),
                'avg_loss': Decimal('0')
            }

        self._performance_metrics['total_trades'] += 1
        self._performance_metrics['total_pnl'] += pnl

        if is_win:
            self._performance_metrics['winning_trades'] += 1
        else:
            self._performance_metrics['losing_trades'] += 1

        # Пересчитываем производные метрики
        total_trades = self._performance_metrics['total_trades']
        if total_trades > 0:
            self._performance_metrics['win_rate'] = Decimal(
                str(self._performance_metrics['winning_trades'] / total_trades)
            )

    def get_strategy_report(self) -> Dict[str, Any]:
        """
        Возвращает отчет о работе стратегии
        """
        return {
            'name': self.name,
            'status': self.status.value,
            'config': self.config.model_dump(),
            'performance': self.performance_metrics,
            'signals_generated': self._signals_generated,
            'orders_created': self._orders_created,
            'active_signals': len(self._signal_history),
            'last_analysis': self._last_analysis_time
        }

    def pause(self) -> None:
        """Приостанавливает стратегию"""
        self.status = StrategyStatus.PAUSED

    def resume(self) -> None:
        """Возобновляет стратегию"""
        if self.status == StrategyStatus.PAUSED:
            self.status = StrategyStatus.ACTIVE

    def stop(self) -> None:
        """Останавливает стратегию"""
        self.status = StrategyStatus.STOPPED

    def _add_signal_to_history(self, signal: StrategySignal) -> None:
        """Добавляет сигнал в историю"""
        self._signal_history.append(signal)
        self._signals_generated += 1

        # Поддерживаем разумный размер истории
        if len(self._signal_history) > 100:
            self._signal_history.pop(0)