"""
Level Hunter Strategy - основная стратегия бота
Охота за ценовыми уровнями с использованием лимитных ордеров
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import List, Dict, Any, Optional
import numpy as np

from domain.models.candle import Candle
from domain.models.signal import Signal, SignalType, SignalStrength
from domain.indicators.ema import MultiEMA
from domain.indicators.rsi import RSI
from domain.indicators.atr import ATR
from domain.indicators.bollinger_bands import BollingerBands
from domain.indicators.macd import MACD
from domain.indicators.volatility import VolatilityIndicator

from .base import BaseStrategy, StrategyConfig, StrategySignal


class LevelHunterConfig(StrategyConfig):
    """Конфигурация Level Hunter стратегии"""

    # Параметры определения уровней
    support_resistance_lookback: int = 20
    ema_periods: List[int] = [9, 21, 50, 200]
    volatility_lookback: int = 14

    # Параметры сигналов
    min_confidence: Decimal = Decimal('0.7')
    min_level_strength: Decimal = Decimal('0.6')
    max_distance_from_level: Decimal = Decimal('2.0')  # в %

    # Risk параметры
    atr_stop_multiplier: Decimal = Decimal('2.0')
    atr_take_profit_multiplier: Decimal = Decimal('3.0')
    risk_reward_ratio: Decimal = Decimal('2.0')

    # Фильтры рынка
    min_volume: Decimal = Decimal('100000')  # минимальный объем
    max_spread: Decimal = Decimal('0.1')  # максимальный спред в %


class LevelHunterStrategy(BaseStrategy):
    """
    Level Hunter Strategy
    Основная стратегия - охота за ключевыми ценовыми уровнями
    Выставляет лимитные ордера на уровнях поддержки/сопротивления
    """

    def __init__(self, config: LevelHunterConfig):
        super().__init__(config)
        self.config = config

        # Инициализация индикаторов
        self.multi_ema = MultiEMA(config.ema_periods)
        self.rsi = RSI(period=14)
        self.atr = ATR(period=14)
        self.bb = BollingerBands(period=20)
        self.macd = MACD()
        self.volatility = VolatilityIndicator(config.volatility_lookback)

        # Состояние стратегии
        self._detected_levels: Dict[str, List[Dict]] = {}
        self._level_strengths: Dict[str, Dict[Decimal, Decimal]] = {}
        self._market_states: Dict[str, Dict[str, Any]] = {}

    async def analyze_market(self, symbol: str, candles: List[Candle]) -> List[StrategySignal]:
        """
        Анализирует рынок и ищет ключевые уровни для выставления ордеров
        """
        if not candles:
            return []

        self._last_analysis_time = datetime.utcnow()
        current_candle = candles[-1]
        current_price = current_candle.close

        # Обновляем все индикаторы
        for candle in candles[-10:]:  # Обновляем последние 10 свечей
            self._update_indicators(candle)

        # Анализируем рыночное состояние
        market_state = await self._analyze_market_state(symbol, candles, current_price)
        self._market_states[symbol] = market_state

        # Обнаружение уровней
        levels = await self._detect_trading_levels(symbol, candles, current_price, market_state)
        self._detected_levels[symbol] = levels

        # Генерация сигналов
        signals = await self._generate_trading_signals(symbol, levels, current_price, market_state)

        # Фильтрация сигналов
        filtered_signals = [signal for signal in signals if self.validate_signal(signal)]

        # Добавляем в историю
        for signal in filtered_signals:
            self._add_signal_to_history(signal)

        return filtered_signals

    def _update_indicators(self, candle: Candle) -> None:
        """Обновляет все индикаторы новой свечой"""
        self.multi_ema.update_from_candle(candle)
        self.rsi.update_from_candle(candle)
        self.atr.update(candle)
        self.bb.update(candle)
        self.macd.update(candle)
        self.volatility.update(candle)

    async def _analyze_market_state(self, symbol: str, candles: List[Candle], current_price: Decimal) -> Dict[str, Any]:
        """Анализирует общее состояние рынка"""
        market_state = {
            'symbol': symbol,
            'current_price': current_price,
            'trend': 'SIDEWAYS',
            'volatility_regime': 'NORMAL',
            'momentum': 'NEUTRAL',
            'is_trending': False,
            'is_ranging': False,
            'is_volatile': False,
            'trading_conditions': 'NORMAL'
        }

        # Анализ тренда
        trend_analysis = self._analyze_trend(candles)
        market_state.update(trend_analysis)

        # Анализ волатильности
        volatility_analysis = self.volatility.get_trading_recommendations()
        market_state.update(volatility_analysis)

        # Анализ моментума
        momentum_analysis = self._analyze_momentum()
        market_state.update(momentum_analysis)

        # Общие торговые условия
        market_state['trading_conditions'] = self._assess_trading_conditions(market_state)

        return market_state

    def _analyze_trend(self, candles: List[Candle]) -> Dict[str, Any]:
        """Анализирует тренд на основе multiple timeframe анализа"""
        analysis = {
            'trend': 'SIDEWAYS',
            'trend_strength': Decimal('0'),
            'ema_alignment': 'MIXED',
            'key_emas': {}
        }

        # Анализ выстраивания EMA
        ema_alignment = self.multi_ema.get_alignment()
        analysis['ema_alignment'] = ema_alignment

        # Значения ключевых EMA
        for period in self.config.ema_periods:
            ema = self.multi_ema.get_ema(period)
            if ema and ema.value:
                analysis['key_emas'][f'ema_{period}'] = float(ema.value)

        # Определение тренда
        if ema_alignment == "BULLISH":
            analysis['trend'] = "BULLISH"
            analysis['trend_strength'] = Decimal('0.7')
        elif ema_alignment == "BEARISH":
            analysis['trend'] = "BEARISH"
            analysis['trend_strength'] = Decimal('0.7')

        # Подтверждение тренда MACD
        macd_signals = self.macd.get_trading_signals()
        if macd_signals['trend'] == 'BULLISH' and analysis['trend'] == 'BULLISH':
            analysis['trend_strength'] += Decimal('0.2')
        elif macd_signals['trend'] == 'BEARISH' and analysis['trend'] == 'BEARISH':
            analysis['trend_strength'] += Decimal('0.2')

        analysis['trend_strength'] = min(analysis['trend_strength'], Decimal('1'))

        return analysis

    def _analyze_momentum(self) -> Dict[str, Any]:
        """Анализирует моментум рынка"""
        analysis = {
            'momentum': 'NEUTRAL',
            'rsi_state': 'NEUTRAL',
            'macd_momentum': 'NEUTRAL',
            'overbought_oversold': 'NEUTRAL'
        }

        # RSI анализ
        rsi_signals = self.rsi.get_trading_signal()
        analysis['rsi_state'] = rsi_signals['trend']

        # MACD моментум
        macd_momentum = self.macd.get_momentum_analysis()
        analysis['macd_momentum'] = macd_momentum['momentum']

        # Определение общего моментума
        if (rsi_signals['signal'] in ['STRONG_BUY', 'BUY'] and
                'BULLISH' in str(macd_momentum['momentum'])):
            analysis['momentum'] = 'BULLISH'
        elif (rsi_signals['signal'] in ['STRONG_SELL', 'SELL'] and
              'BEARISH' in str(macd_momentum['momentum'])):
            analysis['momentum'] = 'BEARISH'

        # Перекупленность/перепроданность
        if self.rsi.is_strongly_overbought:
            analysis['overbought_oversold'] = 'STRONG_OVERBOUGHT'
        elif self.rsi.is_overbought:
            analysis['overbought_oversold'] = 'OVERBOUGHT'
        elif self.rsi.is_strongly_oversold:
            analysis['overbought_oversold'] = 'STRONG_OVERSOLD'
        elif self.rsi.is_oversold:
            analysis['overbought_oversold'] = 'OVERSOLD'

        return analysis

    def _assess_trading_conditions(self, market_state: Dict[str, Any]) -> str:
        """Оценивает торговые условия"""
        # Избегаем торговли при экстремальных условиях
        if market_state['volatility_regime'] == 'VOLATILITY_BREAKOUT':
            return 'AVOID_TRADING'

        if market_state['overbought_oversold'] in ['STRONG_OVERBOUGHT', 'STRONG_OVERSOLD']:
            return 'CAUTION'

        if market_state['trend_strength'] < Decimal('0.3'):
            return 'LOW_CONVICTION'

        return 'GOOD'

    async def _detect_trading_levels(self, symbol: str, candles: List[Candle],
                                     current_price: Decimal, market_state: Dict[str, Any]) -> List[Dict]:
        """Обнаружение ключевых торговых уровней"""
        levels = []

        # 1. Уровни на основе EMA
        ema_levels = self._detect_ema_levels(current_price, market_state)
        levels.extend(ema_levels)

        # 2. Уровни поддержки/сопротивления
        sr_levels = self._detect_support_resistance(candles, current_price)
        levels.extend(sr_levels)

        # 3. Уровни Bollinger Bands
        bb_levels = self._detect_bollinger_bands_levels(current_price)
        levels.extend(bb_levels)

        # 4. Психологические уровни (круглые числа)
        psych_levels = self._detect_psychological_levels(current_price)
        levels.extend(psych_levels)

        # Фильтрация и ранжирование уровней
        filtered_levels = self._filter_and_rank_levels(levels, current_price, market_state)

        return filtered_levels

    def _detect_ema_levels(self, current_price: Decimal, market_state: Dict[str, Any]) -> List[Dict]:
        """Обнаружение уровней на основе EMA"""
        levels = []

        for period in self.config.ema_periods:
            ema = self.multi_ema.get_ema(period)
            if ema and ema.value:
                # Рассчитываем силу уровня
                distance_pct = abs(float(ema.distance_from_price(current_price)))
                strength = max(0, 1 - distance_pct / 5)  # Сила уменьшается с расстоянием

                level_type = "DYNAMIC_SUPPORT" if current_price > ema.value else "DYNAMIC_RESISTANCE"

                levels.append({
                    'price': ema.value,
                    'type': level_type,
                    'strength': Decimal(str(strength)),
                    'source': f'EMA_{period}',
                    'metadata': {
                        'ema_period': period,
                        'distance_pct': Decimal(str(distance_pct)),
                        'trend': ema.trend
                    }
                })

        return levels

    def _detect_support_resistance(self, candles: List[Candle], current_price: Decimal) -> List[Dict]:
        """Обнаружение статических уровней поддержки/сопротивления"""
        if len(candles) < 20:
            return []

        levels = []

        # Простой алгоритм обнаружения локальных экстремумов
        for i in range(10, len(candles) - 10):
            window = candles[i - 10:i + 11]  # Окно 21 свеча
            center_candle = window[10]

            # Проверяем является ли центр локальным максимумом
            if (all(candle.high <= center_candle.high for candle in window) and
                    center_candle.high != current_price):
                levels.append({
                    'price': center_candle.high,
                    'type': 'RESISTANCE',
                    'strength': Decimal('0.7'),
                    'source': 'LOCAL_HIGH',
                    'metadata': {'touch_count': 1, 'timeframe': 'MEDIUM'}
                })

            # Проверяем является ли центр локальным минимумом
            if (all(candle.low >= center_candle.low for candle in window) and
                    center_candle.low != current_price):
                levels.append({
                    'price': center_candle.low,
                    'type': 'SUPPORT',
                    'strength': Decimal('0.7'),
                    'source': 'LOCAL_LOW',
                    'metadata': {'touch_count': 1, 'timeframe': 'MEDIUM'}
                })

        return levels

    def _detect_bollinger_bands_levels(self, current_price: Decimal) -> List[Dict]:
        """Обнаружение уровней на основе Bollinger Bands"""
        levels = []

        if self.bb.upper_band and self.bb.lower_band:
            # Верхняя полоса как сопротивление
            levels.append({
                'price': self.bb.upper_band,
                'type': 'DYNAMIC_RESISTANCE',
                'strength': Decimal('0.8'),
                'source': 'BOLLINGER_UPPER',
                'metadata': {'band_width': self.bb.band_width}
            })

            # Нижняя полоса как поддержка
            levels.append({
                'price': self.bb.lower_band,
                'type': 'DYNAMIC_SUPPORT',
                'strength': Decimal('0.8'),
                'source': 'BOLLINGER_LOWER',
                'metadata': {'band_width': self.bb.band_width}
            })

            # Средняя полоса
            if self.bb.middle_band:
                levels.append({
                    'price': self.bb.middle_band,
                    'type': 'DYNAMIC_SUPPORT_RESISTANCE',
                    'strength': Decimal('0.6'),
                    'source': 'BOLLINGER_MIDDLE',
                    'metadata': {'band_width': self.bb.band_width}
                })

        return levels

    def _detect_psychological_levels(self, current_price: Decimal) -> List[Dict]:
        """Обнаружение психологических уровней (круглые числа)"""
        levels = []

        # Округляем до ближайших круглых чисел
        rounded_price = Decimal(str(round(float(current_price), -1 if current_price > 100 else 0)))

        # Создаем уровни вокруг текущей цены
        for offset in [-2, -1, 1, 2]:
            level_price = rounded_price + Decimal(str(offset * 10))
            distance_pct = abs(float((level_price - current_price) / current_price * 100))

            if distance_pct < 5:  # Только близкие уровни
                level_type = "SUPPORT" if level_price < current_price else "RESISTANCE"

                levels.append({
                    'price': level_price,
                    'type': level_type,
                    'strength': Decimal('0.5'),
                    'source': 'PSYCHOLOGICAL',
                    'metadata': {'distance_pct': Decimal(str(distance_pct))}
                })

        return levels

    def _filter_and_rank_levels(self, levels: List[Dict], current_price: Decimal,
                                market_state: Dict[str, Any]) -> List[Dict]:
        """Фильтрация и ранжирование уровней"""
        filtered_levels = []

        for level in levels:
            # Фильтруем по расстоянию
            distance_pct = abs(float((level['price'] - current_price) / current_price * 100))
            if distance_pct > float(self.config.max_distance_from_level):
                continue

            # Фильтруем по силе уровня
            if level['strength'] < self.config.min_level_strength:
                continue

            # Увеличиваем силу уровня если он согласуется с трендом
            if (market_state['trend'] == 'BULLISH' and level['type'] == 'SUPPORT'):
                level['strength'] *= Decimal('1.2')
            elif (market_state['trend'] == 'BEARISH' and level['type'] == 'RESISTANCE'):
                level['strength'] *= Decimal('1.2')

            # Ограничиваем силу
            level['strength'] = min(level['strength'], Decimal('1'))

            filtered_levels.append(level)

        # Сортируем по силе уровня
        filtered_levels.sort(key=lambda x: x['strength'], reverse=True)

        return filtered_levels[:10]  # Возвращаем топ-10 уровней

    async def _generate_trading_signals(self, symbol: str, levels: List[Dict],
                                        current_price: Decimal, market_state: Dict[str, Any]) -> List[StrategySignal]:
        """Генерация торговых сигналов на основе обнаруженных уровней"""
        signals = []

        for level in levels:
            signal = await self._create_signal_from_level(symbol, level, current_price, market_state)
            if signal:
                signals.append(signal)

        return signals

    async def _create_signal_from_level(self, symbol: str, level: Dict,
                                        current_price: Decimal, market_state: Dict[str, Any]) -> Optional[
        StrategySignal]:
        """Создает торговый сигнал из уровня"""
        level_price = level['price']
        level_type = level['type']
        level_strength = level['strength']

        # Определяем тип сигнала на основе уровня и тренда
        if level_type in ['SUPPORT', 'DYNAMIC_SUPPORT']:
            if market_state['trend'] == 'BULLISH':
                signal_type = SignalType.LEVEL_BOUNCE
            else:
                signal_type = SignalType.SUPPORT_HOLD
        elif level_type in ['RESISTANCE', 'DYNAMIC_RESISTANCE']:
            if market_state['trend'] == 'BEARISH':
                signal_type = SignalType.LEVEL_BOUNCE
            else:
                signal_type = SignalType.RESISTANCE_HOLD
        else:
            signal_type = SignalType.LEVEL_BREAKOUT

        # Рассчитываем уверенность
        confidence = self._calculate_signal_confidence(level, market_state)

        if confidence < self.config.min_confidence:
            return None

        # Рассчитываем стоп-лосс и тейк-профит
        stop_loss, take_profit = self._calculate_risk_levels(
            level_price, level_type, current_price, market_state
        )

        # Определяем силу сигнала
        if confidence >= Decimal('0.9'):
            strength = SignalStrength.VERY_STRONG
        elif confidence >= Decimal('0.8'):
            strength = SignalStrength.STRONG
        elif confidence >= Decimal('0.7'):
            strength = SignalStrength.MEDIUM
        else:
            strength = SignalStrength.WEAK

        return StrategySignal(
            symbol=symbol,
            signal_type=signal_type,
            strength=strength,
            price_level=level_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            confidence=confidence,
            metadata={
                'level_type': level_type,
                'level_strength': level_strength,
                'level_source': level['source'],
                'market_trend': market_state['trend'],
                'volatility_regime': market_state['volatility_regime'],
                'rsi_state': market_state.get('rsi_state', 'NEUTRAL')
            }
        )

    def _calculate_signal_confidence(self, level: Dict, market_state: Dict[str, Any]) -> Decimal:
        """Рассчитывает уверенность в сигнале"""
        confidence = level['strength']

        # Увеличиваем уверенность при согласовании с трендом
        if (market_state['trend'] == 'BULLISH' and level['type'] in ['SUPPORT', 'DYNAMIC_SUPPORT']):
            confidence *= Decimal('1.2')
        elif (market_state['trend'] == 'BEARISH' and level['type'] in ['RESISTANCE', 'DYNAMIC_RESISTANCE']):
            confidence *= Decimal('1.2')

        # Учитываем силу тренда
        confidence *= market_state.get('trend_strength', Decimal('0.5'))

        # Учитываем моментум
        if market_state['momentum'] == 'BULLISH' and 'BUY' in level['type']:
            confidence *= Decimal('1.1')
        elif market_state['momentum'] == 'BEARISH' and 'SELL' in level['type']:
            confidence *= Decimal('1.1')

        return min(confidence, Decimal('1'))

    def _calculate_risk_levels(self, level_price: Decimal, level_type: str,
                               current_price: Decimal, market_state: Dict[str, Any]) -> Tuple[
        Optional[Decimal], Optional[Decimal]]:
        """Рассчитывает уровни стоп-лосса и тейк-профита"""
        if not self.atr.value:
            return None, None

        atr_distance = self.atr.value * self.config.atr_stop_multiplier

        if level_type in ['SUPPORT', 'DYNAMIC_SUPPORT']:
            # Для поддержки - стоп ниже уровня, тейк выше
            stop_loss = level_price - atr_distance
            take_profit = level_price + (atr_distance * self.config.risk_reward_ratio)
        elif level_type in ['RESISTANCE', 'DYNAMIC_RESISTANCE']:
            # Для сопротивления - стоп выше уровня, тейк ниже
            stop_loss = level_price + atr_distance
            take_profit = level_price - (atr_distance * self.config.risk_reward_ratio)
        else:
            return None, None

        return stop_loss, take_profit

    def calculate_position_size(self, signal: StrategySignal, portfolio_balance: Decimal) -> Decimal:
        """
        Рассчитывает размер позиции для Level Hunter стратегии
        """
        base_size = portfolio_balance * (self.config.max_position_size / Decimal('100'))

        # Корректируем на основе уверенности
        confidence_multiplier = signal.confidence
        adjusted_size = base_size * confidence_multiplier

        # Корректируем на основе волатильности
        volatility_multiplier = self.volatility.get_trading_recommendations().get('position_size_multiplier', 1.0)
        adjusted_size *= Decimal(str(volatility_multiplier))

        # Минимальный и максимальный размер
        min_size = portfolio_balance * Decimal('0.01')  # 1% минимум
        max_size = portfolio_balance * Decimal('0.05')  # 5% максимум

        return max(min_size, min(adjusted_size, max_size))

    def get_strategy_insights(self, symbol: str) -> Dict[str, Any]:
        """Возвращает аналитические инсайты стратегии"""
        if symbol not in self._market_states:
            return {}

        market_state = self._market_states[symbol]
        levels = self._detected_levels.get(symbol, [])

        return {
            'market_state': market_state,
            'detected_levels': levels,
            'active_indicators': {
                'ema_alignment': self.multi_ema.get_alignment(),
                'rsi_value': float(self.rsi.value) if self.rsi.value else 0,
                'atr_value': float(self.atr.value) if self.atr.value else 0,
                'bb_squeeze': self.bb.is_squeeze,
                'macd_trend': self.macd.get_trend_strength()
            },
            'trading_recommendation': market_state.get('trading_conditions', 'UNKNOWN')
        }