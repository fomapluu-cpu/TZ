"""
Mean Reversion Strategy - стратегия возврата к среднему
Дополнительная стратегия для диверсификации
"""

from datetime import datetime
from decimal import Decimal
from typing import List, Dict, Any, Optional
import numpy as np

from domain.models.candle import Candle
from domain.models.signal import Signal, SignalType, SignalStrength
from domain.indicators.bollinger_bands import BollingerBands
from domain.indicators.rsi import RSI
from domain.indicators.atr import ATR

from .base import BaseStrategy, StrategyConfig, StrategySignal


class MeanReversionConfig(StrategyConfig):
    """Конфигурация Mean Reversion стратегии"""

    # Параметры возврата к среднему
    bb_period: int = 20
    bb_std_dev: Decimal = Decimal('2.0')
    rsi_period: int = 14
    atr_period: int = 14

    # Условия входа
    rsi_oversold: Decimal = Decimal('30')
    rsi_overbought: Decimal = Decimal('70')
    bb_percent_b_entry: Decimal = Decimal('0.1')  # Вход при %B < 0.1 или > 0.9

    # Risk параметры
    atr_stop_multiplier: Decimal = Decimal('1.5')
    risk_reward_ratio: Decimal = Decimal('1.5')
    max_hold_period: int = 24  # часов

    # Фильтры
    min_volume_ratio: Decimal = Decimal('1.2')  # Минимальное отношение объема к среднему
    require_volume_confirmation: bool = True


class MeanReversionStrategy(BaseStrategy):
    """
    Mean Reversion Strategy
    Стратегия возврата к среднему - ловим экстремумы и играем на возврат к среднему
    """

    def __init__(self, config: MeanReversionConfig):
        super().__init__(config)
        self.config = config

        # Инициализация индикаторов
        self.bb = BollingerBands(period=config.bb_period, std_dev=config.bb_std_dev)
        self.rsi = RSI(period=config.rsi_period)
        self.atr = ATR(period=config.atr_period)

        # Состояние стратегии
        self._volume_profile: Dict[str, List[Decimal]] = {}
        self._price_extremes: Dict[str, Dict[str, Decimal]] = {}

    async def analyze_market(self, symbol: str, candles: List[Candle]) -> List[StrategySignal]:
        """
        Анализирует рынок на возможности возврата к среднему
        """
        if len(candles) < max(self.config.bb_period, self.config.rsi_period, self.config.atr_period):
            return []

        self._last_analysis_time = datetime.utcnow()
        current_candle = candles[-1]
        current_price = current_candle.close

        # Обновляем индикаторы
        for candle in candles[-5:]:  # Обновляем последние 5 свечей
            self._update_indicators(candle)

        # Проверяем условия входа
        signals = []

        # Сигнал на покупку (перепроданность + нижняя полоса BB)
        buy_signal = await self._check_buy_conditions(symbol, current_candle, current_price)
        if buy_signal:
            signals.append(buy_signal)

        # Сигнал на продажу (перекупленность + верхняя полоса BB)
        sell_signal = await self._check_sell_conditions(symbol, current_candle, current_price)
        if sell_signal:
            signals.append(sell_signal)

        # Фильтрация сигналов
        filtered_signals = [signal for signal in signals if self.validate_signal(signal)]

        # Добавляем в историю
        for signal in filtered_signals:
            self._add_signal_to_history(signal)

        return filtered_signals

    def _update_indicators(self, candle: Candle) -> None:
        """Обновляет индикаторы новой свечой"""
        self.bb.update(candle)
        self.rsi.update_from_candle(candle)
        self.atr.update(candle)

    async def _check_buy_conditions(self, symbol: str, candle: Candle, current_price: Decimal) -> Optional[
        StrategySignal]:
        """
        Проверяет условия для сигнала на покупку
        """
        # Базовые условия
        if not all([self.bb.lower_band, self.rsi.value, self.atr.value]):
            return None

        # Условие 1: Цена около нижней полосы Боллинджера
        near_lower_band = current_price <= self.bb.lower_band * Decimal('1.01')  # В пределах 1%

        # Условие 2: RSI в зоне перепроданности
        rsi_oversold = self.rsi.value <= self.config.rsi_oversold

        # Условие 3: %B индикатор показывает экстремальные значения
        percent_b_oversold = self.bb.percent_b and self.bb.percent_b <= self.config.bb_percent_b_entry

        # Условие 4: Подтверждение объемом (опционально)
        volume_ok = not self.config.require_volume_confirmation or self._check_volume_confirmation(symbol, candle)

        if near_lower_band and (rsi_oversold or percent_b_oversold) and volume_ok:
            return await self._create_buy_signal(symbol, candle, current_price)

        return None

    async def _check_sell_conditions(self, symbol: str, candle: Candle, current_price: Decimal) -> Optional[
        StrategySignal]:
        """
        Проверяет условия для сигнала на продажу
        """
        if not all([self.bb.upper_band, self.rsi.value, self.atr.value]):
            return None

        # Условие 1: Цена около верхней полосы Боллинджера
        near_upper_band = current_price >= self.bb.upper_band * Decimal('0.99')  # В пределах 1%

        # Условие 2: RSI в зоне перекупленности
        rsi_overbought = self.rsi.value >= self.config.rsi_overbought

        # Условие 3: %B индикатор показывает экстремальные значения
        percent_b_overbought = self.bb.percent_b and self.bb.percent_b >= Decimal('1') - self.config.bb_percent_b_entry

        # Условие 4: Подтверждение объемом (опционально)
        volume_ok = not self.config.require_volume_confirmation or self._check_volume_confirmation(symbol, candle)

        if near_upper_band and (rsi_overbought or percent_b_overbought) and volume_ok:
            return await self._create_sell_signal(symbol, candle, current_price)

        return None

    def _check_volume_confirmation(self, symbol: str, candle: Candle) -> bool:
        """
        Проверяет подтверждение объемом
        """
        if symbol not in self._volume_profile:
            self._volume_profile[symbol] = []

        # Добавляем текущий объем
        self._volume_profile[symbol].append(candle.volume)

        # Поддерживаем историю объемов
        if len(self._volume_profile[symbol]) > 20:
            self._volume_profile[symbol].pop(0)

        # Проверяем достаточную историю
        if len(self._volume_profile[symbol]) < 10:
            return True  # Недостаточно данных, пропускаем проверку

        # Рассчитываем средний объем
        avg_volume = sum(self._volume_profile[symbol][-10:]) / Decimal('10')

        # Текущий объем должен быть выше среднего
        return candle.volume >= avg_volume * self.config.min_volume_ratio

    async def _create_buy_signal(self, symbol: str, candle: Candle, current_price: Decimal) -> StrategySignal:
        """
        Создает сигнал на покупку для mean reversion
        """
        # Цена входа - текущая цена или немного выше для лимитного ордера
        entry_price = current_price * Decimal('1.002') + 0.2 % для
        лимитного
        ордера

        # Рассчитываем стоп-лосс и тейк-профит
        stop_loss, take_profit = self._calculate_buy_risk_levels(entry_price)

        # Рассчитываем уверенность
        confidence = self._calculate_buy_confidence(candle)

        # Определяем силу сигнала
        if confidence >= Decimal('0.85'):
            strength = SignalStrength.VERY_STRONG
        elif confidence >= Decimal('0.75'):
            strength = SignalStrength.STRONG
        elif confidence >= Decimal('0.65'):
            strength = SignalStrength.MEDIUM
        else:
            strength = SignalStrength.WEAK

        return StrategySignal(
            symbol=symbol,
            signal_type=SignalType.LEVEL_BOUNCE,
            strength=strength,
            price_level=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            confidence=confidence,
            metadata={
                'strategy': 'MEAN_REVERSION',
                'entry_type': 'BOUNCE_FROM_LOWER_BB',
                'rsi_value': float(self.rsi.value) if self.rsi.value else 0,
                'bb_percent_b': float(self.bb.percent_b) if self.bb.percent_b else 0,
                'atr_value': float(self.atr.value) if self.atr.value else 0,
                'volume_confirm': self._check_volume_confirmation(symbol, candle)
            }
        )

    async def _create_sell_signal(self, symbol: str, candle: Candle, current_price: Decimal) -> StrategySignal:
        """
        Создает сигнал на продажу для mean reversion
        """
        # Цена входа - текущая цена или немного ниже для лимитного ордера
        entry_price = current_price * Decimal('0.998')  # -0.2% для лимитного ордера

        # Рассчитываем стоп-лосс и тейк-профит
        stop_loss, take_profit = self._calculate_sell_risk_levels(entry_price)

        # Рассчитываем уверенность
        confidence = self._calculate_sell_confidence(candle)

        # Определяем силу сигнала
        if confidence >= Decimal('0.85'):
            strength = SignalStrength.VERY_STRONG
        elif confidence >= Decimal('0.75'):
            strength = SignalStrength.STRONG
        elif confidence >= Decimal('0.65'):
            strength = SignalStrength.MEDIUM
        else:
            strength = SignalStrength.WEAK

        return StrategySignal(
            symbol=symbol,
            signal_type=SignalType.LEVEL_BOUNCE,
            strength=strength,
            price_level=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            confidence=confidence,
            metadata={
                'strategy': 'MEAN_REVERSION',
                'entry_type': 'BOUNCE_FROM_UPPER_BB',
                'rsi_value': float(self.rsi.value) if self.rsi.value else 0,
                'bb_percent_b': float(self.bb.percent_b) if self.bb.percent_b else 0,
                'atr_value': float(self.atr.value) if self.atr.value else 0,
                'volume_confirm': self._check_volume_confirmation(symbol, candle)
            }
        )

    def _calculate_buy_risk_levels(self, entry_price: Decimal) -> Tuple[Decimal, Decimal]:
        """Рассчитывает стоп-лосс и тейк-профит для покупки"""
        if not self.atr.value:
            return entry_price * Decimal('0.98'), entry_price * Decimal('1.04')

        atr_distance = self.atr.value * self.config.atr_stop_multiplier

        stop_loss = entry_price - atr_distance
        take_profit = entry_price + (atr_distance * self.config.risk_reward_ratio)

        return stop_loss, take_profit

    def _calculate_sell_risk_levels(self, entry_price: Decimal) -> Tuple[Decimal, Decimal]:
        """Рассчитывает стоп-лосс и тейк-профит для продажи"""
        if not self.atr.value:
            return entry_price * Decimal('1.02'), entry_price * Decimal('0.96')

        atr_distance = self.atr.value * self.config.atr_stop_multiplier

        stop_loss = entry_price + atr_distance
        take_profit = entry_price - (atr_distance * self.config.risk_reward_ratio)

        return stop_loss, take_profit

    def _calculate_buy_confidence(self, candle: Candle) -> Decimal:
        """Рассчитывает уверенность для сигнала покупки"""
        confidence = Decimal('0.7')  # Базовая уверенность

        # RSI фактор
        if self.rsi.value:
            rsi_factor = max(Decimal('0'), (self.config.rsi_oversold - self.rsi.value) / self.config.rsi_oversold)
            confidence += rsi_factor * Decimal('0.2')

        # Bollinger Bands фактор
        if self.bb.percent_b:
            bb_factor = max(Decimal('0'),
                            (self.config.bb_percent_b_entry - self.bb.percent_b) / self.config.bb_percent_b_entry)
            confidence += bb_factor * Decimal('0.2')

        # Объемный фактор
        volume_factor = Decimal('1.0') if self._check_volume_confirmation(candle.symbol, candle) else Decimal('0.5')
        confidence *= volume_factor

        return min(confidence, Decimal('1'))

    def _calculate_sell_confidence(self, candle: Candle) -> Decimal:
        """Рассчитывает уверенность для сигнала продажи"""
        confidence = Decimal('0.7')  # Базовая уверенность

        # RSI фактор
        if self.rsi.value:
            rsi_factor = max(Decimal('0'), (self.rsi.value - self.config.rsi_overbought) / (
                        Decimal('100') - self.config.rsi_overbought))
            confidence += rsi_factor * Decimal('0.2')

        # Bollinger Bands фактор
        if self.bb.percent_b:
            bb_factor = max(Decimal('0'), (self.bb.percent_b - (
                        Decimal('1') - self.config.bb_percent_b_entry)) / self.config.bb_percent_b_entry)
            confidence += bb_factor * Decimal('0.2')

        # Объемный фактор
        volume_factor = Decimal('1.0') if self._check_volume_confirmation(candle.symbol, candle) else Decimal('0.5')
        confidence *= volume_factor

        return min(confidence, Decimal('1'))

    def calculate_position_size(self, signal: StrategySignal, portfolio_balance: Decimal) -> Decimal:
        """
        Рассчитывает размер позиции для Mean Reversion стратегии
        """
        # Базовый размер - 2% от портфеля
        base_size = portfolio_balance * Decimal('0.02')

        # Корректируем на основе уверенности
        confidence_multiplier = signal.confidence
        adjusted_size = base_size * confidence_multiplier

        # Корректируем на основе волатильности (меньшие позиции при высокой волатильности)
        if self.atr.value and self.bb.middle_band:
            atr_ratio = self.atr.value / self.bb.middle_band
            volatility_multiplier = max(Decimal('0.5'), Decimal('1') - atr_ratio * Decimal('2'))
            adjusted_size *= volatility_multiplier

        # Минимальный и максимальный размер
        min_size = portfolio_balance * Decimal('0.005')  # 0.5% минимум
        max_size = portfolio_balance * Decimal('0.03')  # 3% максимум

        return max(min_size, min(adjusted_size, max_size))

    def get_mean_reversion_metrics(self, symbol: str) -> Dict[str, Any]:
        """Возвращает метрики mean reversion для символа"""
        return {
            'bollinger_bands': {
                'upper': float(self.bb.upper_band) if self.bb.upper_band else 0,
                'middle': float(self.bb.middle_band) if self.bb.middle_band else 0,
                'lower': float(self.bb.lower_band) if self.bb.lower_band else 0,
                'percent_b': float(self.bb.percent_b) if self.bb.percent_b else 0.5,
                'width': float(self.bb.band_width) if self.bb.band_width else 0,
                'squeeze': self.bb.is_squeeze
            },
            'rsi': {
                'value': float(self.rsi.value) if self.rsi.value else 0,
                'trend': self.rsi.trend,
                'is_overbought': self.rsi.is_overbought,
                'is_oversold': self.rsi.is_oversold
            },
            'atr': {
                'value': float(self.atr.value) if self.atr.value else 0,
                'volatility_level': self.atr.volatility_level
            },
            'trading_conditions': {
                'buy_signal_ready': await self._check_buy_conditions(symbol, Candle(), Decimal('0')) is not None,
                'sell_signal_ready': await self._check_sell_conditions(symbol, Candle(), Decimal('0')) is not None
            }
        }