"""
Bollinger Bands индикатор
Для определения ценовых каналов, экстремумов и волатильности
"""

from decimal import Decimal
from typing import List, Optional, Dict, Any, Tuple
import numpy as np

from domain.models.candle import Candle
from domain.indicators.ema import EMA
from domain.indicators.volatility import VolatilityIndicator


class BollingerBands:
    """
    Bollinger Bands индикатор
    Критически важен для Level Hunter стратегии:
    - Определение ценовых каналов
    - Обнаружение экстремумов (перекупленности/перепроданности)
    - Анализ волатильности через ширину полос
    - Сигналы сжатия и расширения
    """

    def __init__(self, period: int = 20, std_dev: Decimal = Decimal('2.0')):
        self.period = period
        self.std_dev = std_dev
        self._candles: List[Candle] = []
        self._sma_values: List[Decimal] = []  # Simple Moving Average
        self._upper_bands: List[Decimal] = []
        self._lower_bands: List[Decimal] = []
        self._band_widths: List[Decimal] = []
        self._percent_bs: List[Decimal] = []  # %B indicator

        # Вспомогательные индикаторы
        self.ema = EMA(period)
        self.volatility = VolatilityIndicator(period)

    @property
    def middle_band(self) -> Optional[Decimal]:
        """Средняя полоса (SMA)"""
        if not self._sma_values:
            return None
        return self._sma_values[-1]

    @property
    def upper_band(self) -> Optional[Decimal]:
        """Верхняя полоса"""
        if not self._upper_bands:
            return None
        return self._upper_bands[-1]

    @property
    def lower_band(self) -> Optional[Decimal]:
        """Нижняя полоса"""
        if not self._lower_bands:
            return None
        return self._lower_bands[-1]

    @property
    def band_width(self) -> Optional[Decimal]:
        """Ширина полос (Upper - Lower)"""
        if not self._band_widths:
            return None
        return self._band_widths[-1]

    @property
    def percent_b(self) -> Optional[Decimal]:
        """Индикатор %B (позиция цены относительно полос)"""
        if not self._percent_bs:
            return None
        return self._percent_bs[-1]

    @property
    def is_squeeze(self) -> bool:
        """Находится ли рынок в состоянии сжатия (низкая волатильность)"""
        if not self.band_width or len(self._band_widths) < 10:
            return False

        # Сравниваем текущую ширину с исторической
        recent_widths = self._band_widths[-10:]
        avg_width = sum(recent_widths) / Decimal('10')

        # Сжатие если текущая ширина меньше 70% от средней
        return self.band_width < avg_width * Decimal('0.7')

    @property
    def is_expansion(self) -> bool:
        """Находится ли рынок в состоянии расширения (высокая волатильность)"""
        if not self.band_width or len(self._band_widths) < 10:
            return False

        recent_widths = self._band_widths[-10:]
        avg_width = sum(recent_widths) / Decimal('10')

        # Расширение если текущая ширина больше 130% от средней
        return self.band_width > avg_width * Decimal('1.3')

    def _calculate_sma(self, prices: List[Decimal]) -> Decimal:
        """Рассчитывает Simple Moving Average"""
        return sum(prices) / Decimal(str(len(prices)))

    def _calculate_standard_deviation(self, prices: List[Decimal], sma: Decimal) -> Decimal:
        """Рассчитывает стандартное отклонение"""
        if len(prices) < 2:
            return Decimal('0')

        squared_diffs = [(price - sma) ** Decimal('2') for price in prices]
        variance = sum(squared_diffs) / Decimal(str(len(prices)))
        return variance.sqrt()

    def update(self, candle: Candle) -> Dict[str, Decimal]:
        """
        Обновляет Bollinger Bands новой свечой

        Args:
            candle: Новая свеча для расчета

        Returns:
            Dict с текущими значениями полос
        """
        self._candles.append(candle)
        current_price = candle.close

        # Обновляем вспомогательные индикаторы
        self.ema.update_from_candle(candle)
        self.volatility.update(candle)

        # Нужно достаточно данных для расчета
        if len(self._candles) < self.period:
            return {}

        # Берем последние period цен закрытия
        recent_prices = [c.close for c in self._candles[-self.period:]]

        # Рассчитываем SMA (среднюю полосу)
        sma = self._calculate_sma(recent_prices)
        self._sma_values.append(sma)

        # Рассчитываем стандартное отклонение
        std_dev = self._calculate_standard_deviation(recent_prices, sma)

        # Рассчитываем верхнюю и нижнюю полосы
        upper_band = sma + (std_dev * self.std_dev)
        lower_band = sma - (std_dev * self.std_dev)

        self._upper_bands.append(upper_band)
        self._lower_bands.append(lower_band)

        # Рассчитываем ширину полос
        width = upper_band - lower_band
        self._band_widths.append(width)

        # Рассчитываем %B
        if upper_band != lower_band:
            percent_b = (current_price - lower_band) / (upper_band - lower_band)
        else:
            percent_b = Decimal('0.5')
        self._percent_bs.append(percent_b)

        # Поддерживаем разумный размер истории
        max_history = self.period * 3
        if len(self._candles) > max_history:
            self._candles.pop(0)
        if len(self._sma_values) > max_history:
            self._sma_values.pop(0)
        if len(self._upper_bands) > max_history:
            self._upper_bands.pop(0)
        if len(self._lower_bands) > max_history:
            self._lower_bands.pop(0)
        if len(self._band_widths) > max_history:
            self._band_widths.pop(0)
        if len(self._percent_bs) > max_history:
            self._percent_bs.pop(0)

        return {
            'upper': upper_band,
            'middle': sma,
            'lower': lower_band,
            'width': width,
            'percent_b': percent_b
        }

    def get_price_position(self, price: Decimal) -> str:
        """
        Определяет позицию цены относительно полос

        Returns:
            str: "ABOVE_UPPER", "BELOW_LOWER", "UPPER_HALF", "LOWER_HALF", "MIDDLE"
        """
        if not self.upper_band or not self.lower_band:
            return "UNKNOWN"

        if price > self.upper_band:
            return "ABOVE_UPPER"
        elif price < self.lower_band:
            return "BELOW_LOWER"
        elif self.percent_b and self.percent_b > Decimal('0.5'):
            return "UPPER_HALF"
        elif self.percent_b and self.percent_b < Decimal('0.5'):
            return "LOWER_HALF"
        else:
            return "MIDDLE"

    def is_overbought(self, price: Decimal) -> bool:
        """Перекупленность (цена выше верхней полосы)"""
        return self.get_price_position(price) == "ABOVE_UPPER"

    def is_oversold(self, price: Decimal) -> bool:
        """Перепроданность (цена ниже нижней полосы)"""
        return self.get_price_position(price) == "BELOW_LOWER"

    def get_trading_signals(self, price: Decimal) -> Dict[str, Any]:
        """
        Генерирует торговые сигналы на основе Bollinger Bands

        Returns:
            Dict с сигналами и метриками
        """
        signals = {
            'signals': [],
            'confidence': 0.0,
            'price_position': self.get_price_position(price),
            'percent_b': float(self.percent_b) if self.percent_b else 0.5,
            'band_width': float(self.band_width) if self.band_width else 0.0,
            'is_squeeze': self.is_squeeze,
            'is_expansion': self.is_expansion
        }

        # Сигналы отскока от полос
        if self.is_overbought(price):
            signals['signals'].append({
                'type': 'REVERSAL_SELL',
                'reason': 'Price above upper band - overbought',
                'confidence': 0.7
            })

        if self.is_oversold(price):
            signals['signals'].append({
                'type': 'REVERSAL_BUY',
                'reason': 'Price below lower band - oversold',
                'confidence': 0.7
            })

        # Сигналы пробоя полос (требуют подтверждения)
        if len(self._candles) >= 2:
            prev_candle = self._candles[-2]
            prev_position = self.get_price_position(prev_candle.close)
            current_position = self.get_price_position(price)

            # Пробой верхней полосы снизу вверх
            if (prev_position in ["UPPER_HALF", "MIDDLE"] and
                    current_position == "ABOVE_UPPER"):
                signals['signals'].append({
                    'type': 'BREAKOUT_BUY',
                    'reason': 'Breakout above upper band',
                    'confidence': 0.6
                })

            # Пробой нижней полосы сверху вниз
            if (prev_position in ["LOWER_HALF", "MIDDLE"] and
                    current_position == "BELOW_LOWER"):
                signals['signals'].append({
                    'type': 'BREAKOUT_SELL',
                    'reason': 'Breakout below lower band',
                    'confidence': 0.6
                })

        # Сигналы сжатия (предвестник большого движения)
        if self.is_squeeze:
            signals['signals'].append({
                'type': 'SQUEEZE_ALERT',
                'reason': 'Bollinger Bands squeeze detected - expect volatility expansion',
                'confidence': 0.8
            })

        # Сигналы на основе %B
        if self.percent_b:
            if self.percent_b < Decimal('0.2'):
                signals['signals'].append({
                    'type': 'STRONG_BUY',
                    'reason': 'Extreme oversold based on %B',
                    'confidence': 0.8
                })
            elif self.percent_b > Decimal('0.8'):
                signals['signals'].append({
                    'type': 'STRONG_SELL',
                    'reason': 'Extreme overbought based on %B',
                    'confidence': 0.8
                })

        # Общая уверенность (максимальная уверенность из сигналов)
        if signals['signals']:
            signals['confidence'] = max(s['confidence'] for s in signals['signals'])

        return signals

    def calculate_dynamic_levels(self, price: Decimal) -> Dict[str, List[Decimal]]:
        """
        Рассчитывает динамические уровни поддержки/сопротивления

        Returns:
            Dict с уровнями поддержки и сопротивления
        """
        if not self.upper_band or not self.lower_band:
            return {'support': [], 'resistance': []}

        support_levels = []
        resistance_levels = []

        # Основные уровни - полосы Боллинджера
        support_levels.append(self.lower_band)
        resistance_levels.append(self.upper_band)

        # Дополнительные уровни внутри канала
        if self.middle_band:
            support_levels.append(self.middle_band)
            resistance_levels.append(self.middle_band)

        # Уровни на основе %B
        if self.percent_b and self.upper_band and self.lower_band:
            band_range = self.upper_band - self.lower_band

            # Уровни на 25% и 75% канала
            support_25 = self.lower_band + (band_range * Decimal('0.25'))
            resistance_75 = self.lower_band + (band_range * Decimal('0.75'))

            support_levels.append(support_25)
            resistance_levels.append(resistance_75)

        return {
            'support': sorted(support_levels),
            'resistance': sorted(resistance_levels)
        }

    def get_band_width_analysis(self) -> Dict[str, Any]:
        """
        Анализ ширины полос для определения волатильности
        """
        if not self.band_width or len(self._band_widths) < 10:
            return {'analysis': 'INSUFFICIENT_DATA'}

        analysis = {
            'current_width': float(self.band_width),
            'width_trend': 'STABLE',
            'volatility_regime': 'NORMAL',
            'recommendation': 'TRADE_NORMAL'
        }

        # Анализ тренда ширины
        recent_widths = self._band_widths[-5:]
        if all(recent_widths[i] < recent_widths[i + 1] for i in range(len(recent_widths) - 1)):
            analysis['width_trend'] = 'EXPANDING'
        elif all(recent_widths[i] > recent_widths[i + 1] for i in range(len(recent_widths) - 1)):
            analysis['width_trend'] = 'CONTRACTING'

        # Определение режима волатильности
        avg_width = sum(self._band_widths[-10:]) / Decimal('10')
        width_ratio = self.band_width / avg_width

        if width_ratio > Decimal('1.3'):
            analysis.update({
                'volatility_regime': 'HIGH',
                'recommendation': 'REDUCE_POSITION_SIZE'
            })
        elif width_ratio < Decimal('0.7'):
            analysis.update({
                'volatility_regime': 'LOW',
                'recommendation': 'EXPECT_BREAKOUT'
            })

        return analysis


class BollingerBandsStrategy:
    """
    Стратегия торговли на основе Bollinger Bands для Level Hunter
    """

    def __init__(self):
        self.bb = BollingerBands()
        self.last_squeeze_state = False

    def analyze_candle(self, candle: Candle) -> Dict[str, Any]:
        """
        Анализирует свечу и возвращает торговые решения
        """
        # Обновляем индикатор
        bb_data = self.bb.update(candle)

        if not bb_data:
            return {'action': 'HOLD', 'reason': 'Insufficient data'}

        analysis = {
            'action': 'HOLD',
            'confidence': 0.0,
            'signals': [],
            'levels': self.bb.calculate_dynamic_levels(candle.close),
            'band_analysis': self.bb.get_band_width_analysis()
        }

        # Получаем торговые сигналы
        signals = self.bb.get_trading_signals(candle.close)
        analysis['signals'] = signals['signals']
        analysis['confidence'] = signals['confidence']

        # Определяем действие на основе сигналов
        if signals['signals']:
            # Приоритет сигналов
            signal_priority = {
                'STRONG_BUY': 100, 'STRONG_SELL': 100,
                'REVERSAL_BUY': 80, 'REVERSAL_SELL': 80,
                'BREAKOUT_BUY': 70, 'BREAKOUT_SELL': 70,
                'SQUEEZE_ALERT': 50
            }

            best_signal = max(signals['signals'],
                              key=lambda s: signal_priority.get(s['type'], 0))

            if 'BUY' in best_signal['type']:
                analysis['action'] = 'BUY'
            elif 'SELL' in best_signal['type']:
                analysis['action'] = 'SELL'
            elif 'ALERT' in best_signal['type']:
                analysis['action'] = 'ALERT'

        # Проверка сжатия/расширения
        if self.bb.is_squeeze and not self.last_squeeze_state:
            analysis['action'] = 'ALERT'
            analysis['signals'].append({
                'type': 'SQUEEZE_START',
                'reason': 'Bollinger Bands squeeze started',
                'confidence': 0.9
            })

        self.last_squeeze_state = self.bb.is_squeeze

        return analysis