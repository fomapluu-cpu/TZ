# volatility.py
"""
Индикаторы волатильности для анализа рыночных условий
"""

from decimal import Decimal
from typing import List, Optional, Dict, Any
import numpy as np
import pandas as pd

from domain.models.candle import Candle


class VolatilityIndicator:
    """
    Комплексный индикатор волатильности
    Для Level Hunter стратегии:
    - Анализ рыночных условий
    - Определение периодов сжатия/расширения
    - Фильтрация торговых сигналов
    - Настройка параметров стратегии
    """

    def __init__(self, lookback_period: int = 20):
        self.lookback_period = lookback_period
        self._candles: List[Candle] = []
        self._volatility_values: List[Decimal] = []

        # Исторические уровни волатильности
        self._historical_highs: List[Decimal] = []
        self._historical_lows: List[Decimal] = []

    @property
    def current_volatility(self) -> Optional[Decimal]:
        """Текущее значение волатильности"""
        if not self._volatility_values:
            return None
        return self._volatility_values[-1]

    @property
    def volatility_regime(self) -> str:
        """Режим волатильности"""
        if not self.current_volatility:
            return "UNKNOWN"

        # Анализируем исторические данные для определения режима
        if len(self._historical_highs) < 10 or len(self._historical_lows) < 10:
            return "NORMAL"

        # Вычисляем перцентили исторической волатильности
        recent_highs = self._historical_highs[-50:]  # Последние 50 периодов
        recent_lows = self._historical_lows[-50:]

        if not recent_highs or not recent_lows:
            return "NORMAL"

        high_percentile_80 = np.percentile([float(h) for h in recent_highs], 80)
        low_percentile_20 = np.percentile([float(l) for l in recent_lows], 20)

        current_vol = float(self.current_volatility)

        if current_vol >= high_percentile_80:
            return "HIGH_VOLATILITY"
        elif current_vol <= low_percentile_20:
            return "LOW_VOLATILITY"
        else:
            return "NORMAL_VOLATILITY"

    @property
    def is_high_volatility_regime(self) -> bool:
        """Высоковолатильный режим?"""
        return self.volatility_regime == "HIGH_VOLATILITY"

    @property
    def is_low_volatility_regime(self) -> bool:
        """Низковолатильный режим?"""
        return self.volatility_regime == "LOW_VOLATILITY"

    @property
    def volatility_trend(self) -> str:
        """Тренд волатильности"""
        if len(self._volatility_values) < 3:
            return "UNKNOWN"

        recent_vol = self._volatility_values[-3:]

        # Проверяем возрастающий тренд
        if all(recent_vol[i] < recent_vol[i + 1] for i in range(len(recent_vol) - 1)):
            return "INCREASING"
        # Проверяем убывающий тренд
        elif all(recent_vol[i] > recent_vol[i + 1] for i in range(len(recent_vol) - 1)):
            return "DECREASING"
        else:
            return "SIDEWAYS"

    def _calculate_price_range(self, candle: Candle) -> Decimal:
        """Рассчитывает диапазон цены свечи"""
        return candle.high - candle.low

    def _calculate_percentage_range(self, candle: Candle) -> Decimal:
        """Рассчитывает диапазон в процентах от цены закрытия"""
        if candle.close == Decimal('0'):
            return Decimal('0')
        price_range = self._calculate_price_range(candle)
        return (price_range / candle.close) * Decimal('100')

    def update(self, candle: Candle) -> Decimal:
        """
        Обновляет волатильность новой свечой

        Args:
            candle: Новая свеча для расчета

        Returns:
            Decimal: Значение волатильности
        """
        self._candles.append(candle)

        # Рассчитываем процентный диапазон для текущей свечи
        current_range = self._calculate_percentage_range(candle)

        # Обновляем исторические экстремумы
        self._update_historical_extremes(current_range)

        # Нужно достаточно данных для расчета
        if len(self._candles) < self.lookback_period:
            self._volatility_values.append(current_range)
            return current_range

        # Рассчитываем волатильность как стандартное отклонение диапазонов
        recent_ranges = []
        for i in range(max(0, len(self._candles) - self.lookback_period), len(self._candles)):
            range_pct = self._calculate_percentage_range(self._candles[i])
            recent_ranges.append(float(range_pct))

        volatility = Decimal(str(np.std(recent_ranges)))
        self._volatility_values.append(volatility)

        # Поддерживаем разумный размер истории
        max_history = self.lookback_period * 3
        if len(self._candles) > max_history:
            self._candles.pop(0)
        if len(self._volatility_values) > max_history:
            self._volatility_values.pop(0)

        return volatility

    def _update_historical_extremes(self, current_range: Decimal):
        """Обновляет исторические экстремумы волатильности"""
        self._historical_highs.append(current_range)
        self._historical_lows.append(current_range)

        # Поддерживаем историю за последние 200 периодов
        if len(self._historical_highs) > 200:
            self._historical_highs.pop(0)
            self._historical_lows.pop(0)

    def get_volatility_zones(self) -> Dict[str, Decimal]:
        """
        Возвращает зоны волатильности на основе исторических данных
        """
        if len(self._historical_highs) < 50:
            return {}

        highs_float = [float(h) for h in self._historical_highs]
        lows_float = [float(l) for l in self._historical_lows]

        return {
            "very_low": Decimal(str(np.percentile(lows_float, 20))),
            "low": Decimal(str(np.percentile(lows_float, 40))),
            "normal": Decimal(str(np.percentile(highs_float, 50))),
            "high": Decimal(str(np.percentile(highs_float, 70))),
            "very_high": Decimal(str(np.percentile(highs_float, 90)))
        }

    def is_volatility_breakout(self, threshold: Decimal = Decimal('2.0')) -> bool:
        """
        Определяет пробой волатильности

        Args:
            threshold: Порог в стандартных отклонениях

        Returns:
            bool: True если есть пробой волатильности
        """
        if len(self._volatility_values) < 20:
            return False

        recent_vol = self._volatility_values[-20:]
        mean_vol = sum(recent_vol) / Decimal(str(len(recent_vol)))

        # Рассчитываем стандартное отклонение
        vol_float = [float(v) for v in recent_vol]
        std_vol = Decimal(str(np.std(vol_float)))

        if std_vol == Decimal('0'):
            return False

        # Проверяем пробой
        current_z_score = (self.current_volatility - mean_vol) / std_vol
        return abs(current_z_score) > threshold

    def get_trading_recommendations(self) -> Dict[str, Any]:
        """
        Генерирует торговые рекомендации на основе волатильности
        """
        if not self.current_volatility:
            return {"recommendation": "NO_DATA", "confidence": 0.0}

        recommendations = {
            "volatility_regime": self.volatility_regime,
            "volatility_trend": self.volatility_trend,
            "current_volatility": float(self.current_volatility),
            "recommendation": "TRADE_NORMAL",
            "position_size_multiplier": 1.0,
            "stop_loss_multiplier": 1.0,
            "take_profit_multiplier": 1.0,
            "reason": "Normal volatility conditions"
        }

        # Рекомендации для разных режимов волатильности
        if self.is_high_volatility_regime:
            recommendations.update({
                "recommendation": "REDUCE_RISK",
                "position_size_multiplier": 0.5,
                "stop_loss_multiplier": 1.5,
                "take_profit_multiplier": 2.0,
                "reason": "High volatility regime - reduce position size and widen stops"
            })
        elif self.is_low_volatility_regime:
            recommendations.update({
                "recommendation": "INCREASE_EXPOSURE",
                "position_size_multiplier": 1.5,
                "stop_loss_multiplier": 0.8,
                "take_profit_multiplier": 1.5,
                "reason": "Low volatility regime - opportunity for larger positions with tighter stops"
            })

        # Дополнительные рекомендации по тренду волатильности
        if self.volatility_trend == "INCREASING":
            recommendations["reason"] += " with increasing volatility"
        elif self.volatility_trend == "DECREASING":
            recommendations["reason"] += " with decreasing volatility"

        # Проверка на пробой волатильности
        if self.is_volatility_breakout():
            recommendations.update({
                "recommendation": "VOLATILITY_BREAKOUT",
                "position_size_multiplier": 0.3,
                "stop_loss_multiplier": 2.0,
                "reason": "Volatility breakout detected - extreme caution required"
            })

        return recommendations

    def calculate_optimal_position_size(self,
                                        base_position_size: Decimal,
                                        account_balance: Decimal) -> Decimal:
        """
        Рассчитывает оптимальный размер позиции с учетом волатильности

        Args:
            base_position_size: Базовый размер позиции
            account_balance: Баланс счета

        Returns:
            Decimal: Оптимальный размер позиции
        """
        if not self.current_volatility:
            return base_position_size

        rec = self.get_trading_recommendations()
        multiplier = Decimal(str(rec["position_size_multiplier"]))

        # Максимальный риск 2% от счета
        max_risk = account_balance * Decimal('0.02')
        volatility_adjusted_size = base_position_size * multiplier

        # Не превышаем максимальный риск
        if volatility_adjusted_size > max_risk:
            return max_risk

        return volatility_adjusted_size

    def should_avoid_trading(self) -> bool:
        """
        Следует ли избегать торговли в текущих условиях
        """
        if not self.current_volatility:
            return False

        # Избегаем торговли при экстремальной волатильности
        if self.is_volatility_breakout(threshold=Decimal('3.0')):
            return True

        # Избегаем торговли при очень высокой волатильности
        zones = self.get_volatility_zones()
        if zones and self.current_volatility > zones.get("very_high", Decimal('100')):
            return True

        return False


class VolatilityClusterDetector:
    """
    Детектор кластеров волатильности
    Для определения периодов сжатия перед большими движениями
    """

    def __init__(self, window_size: int = 10, threshold: Decimal = Decimal('0.5')):
        self.window_size = window_size
        self.threshold = threshold
        self._volatility_history: List[Decimal] = []

    def update(self, volatility: Decimal) -> bool:
        """
        Обновляет детектор и проверяет наличие кластера низкой волатильности

        Returns:
            bool: True если обнаружен кластер низкой волатильности
        """
        self._volatility_history.append(volatility)

        if len(self._volatility_history) > self.window_size:
            self._volatility_history.pop(0)

        if len(self._volatility_history) < self.window_size:
            return False

        # Проверяем, все ли значения ниже порога
        return all(v < self.threshold for v in self._volatility_history)

    def get_compression_strength(self) -> Decimal:
        """
        Возвращает силу сжатия (чем ниже волатильность, тем сильнее сжатие)
        """
        if not self._volatility_history:
            return Decimal('0')

        avg_volatility = sum(self._volatility_history) / Decimal(str(len(self._volatility_history)))
        return Decimal('1') - min(avg_volatility / self.threshold, Decimal('1'))