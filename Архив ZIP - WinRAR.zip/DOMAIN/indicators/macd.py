# macd.py
"""
MACD (Moving Average Convergence Divergence) индикатор
Для определения тренда, моментума и разворотных сигналов
"""

from decimal import Decimal
from typing import List, Optional, Dict, Any, Tuple
import numpy as np

from domain.models.candle import Candle
from domain.indicators.ema import EMA


class MACD:
    """
    MACD индикатор
    Критически важен для Level Hunter стратегии:
    - Определение направления и силы тренда
    - Сигналы пересечения линии MACD и сигнальной линии
    - Обнаружение дивергенций для разворота тренда
    - Анализ моментума через гистограмму
    """

    def __init__(self, fast_period: int = 12, slow_period: int = 26, signal_period: int = 9):
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.signal_period = signal_period

        # Вспомогательные EMA
        self.fast_ema = EMA(fast_period)
        self.slow_ema = EMA(slow_period)
        self.signal_ema = EMA(signal_period)

        # Значения индикатора
        self._macd_line: List[Decimal] = []
        self._signal_line: List[Decimal] = []
        self._histogram: List[Decimal] = []
        self._candles: List[Candle] = []

        # Исторические данные для анализа
        self._macd_values: List[Decimal] = []
        self._signal_values: List[Decimal] = []

    @property
    def macd_line(self) -> Optional[Decimal]:
        """Текущее значение линии MACD"""
        if not self._macd_line:
            return None
        return self._macd_line[-1]

    @property
    def signal_line(self) -> Optional[Decimal]:
        """Текущее значение сигнальной линии"""
        if not self._signal_line:
            return None
        return self._signal_line[-1]

    @property
    def histogram(self) -> Optional[Decimal]:
        """Текущее значение гистограммы (MACD - Signal)"""
        if not self._histogram:
            return None
        return self._histogram[-1]

    @property
    def is_bullish(self) -> bool:
        """Бычий ли MACD (MACD > Signal)"""
        if not self.macd_line or not self.signal_line:
            return False
        return self.macd_line > self.signal_line

    @property
    def is_bearish(self) -> bool:
        """Медвежий ли MACD (MACD < Signal)"""
        if not self.macd_line or not self.signal_line:
            return False
        return self.macd_line < self.signal_line

    @property
    def trend_strength(self) -> Decimal:
        """Сила тренда (абсолютное значение гистограммы)"""
        if not self.histogram:
            return Decimal('0')
        return abs(self.histogram)

    @property
    def momentum(self) -> str:
        """Моментум на основе гистограммы"""
        if len(self._histogram) < 2:
            return "NEUTRAL"

        current_hist = self._histogram[-1]
        previous_hist = self._histogram[-2]

        if current_hist > previous_hist:
            return "ACCELERATING"
        elif current_hist < previous_hist:
            return "DECELERATING"
        else:
            return "STABLE"

    def update(self, candle: Candle) -> Dict[str, Decimal]:
        """
        Обновляет MACD новой свечой

        Args:
            candle: Новая свеча для расчета

        Returns:
            Dict с текущими значениями MACD
        """
        self._candles.append(candle)
        current_price = candle.close

        # Обновляем EMA
        self.fast_ema.update(current_price)
        self.slow_ema.update(current_price)

        # Нужно достаточно данных для расчета
        if (self.fast_ema.value is None or
                self.slow_ema.value is None):
            return {}

        # Рассчитываем линию MACD
        macd_value = self.fast_ema.value - self.slow_ema.value
        self._macd_line.append(macd_value)
        self._macd_values.append(macd_value)

        # Обновляем сигнальную линию (EMA от MACD)
        self.signal_ema.update(macd_value)

        if self.signal_ema.value is None:
            return {}

        signal_value = self.signal_ema.value
        self._signal_line.append(signal_value)
        self._signal_values.append(signal_value)

        # Рассчитываем гистограмму
        histogram_value = macd_value - signal_value
        self._histogram.append(histogram_value)

        # Поддерживаем разумный размер истории
        max_history = max(self.fast_period, self.slow_period, self.signal_period) * 3
        if len(self._candles) > max_history:
            self._candles.pop(0)
        if len(self._macd_line) > max_history:
            self._macd_line.pop(0)
        if len(self._signal_line) > max_history:
            self._signal_line.pop(0)
        if len(self._histogram) > max_history:
            self._histogram.pop(0)
        if len(self._macd_values) > max_history:
            self._macd_values.pop(0)
        if len(self._signal_values) > max_history:
            self._signal_values.pop(0)

        return {
            'macd': macd_value,
            'signal': signal_value,
            'histogram': histogram_value
        }

    def get_crossover_signal(self) -> Optional[str]:
        """
        Определяет сигнал пересечения MACD и сигнальной линии

        Returns:
            Optional[str]: "BULLISH_CROSS" или "BEARISH_CROSS"
        """
        if len(self._macd_line) < 2 or len(self._signal_line) < 2:
            return None

        current_macd = self._macd_line[-1]
        current_signal = self._signal_line[-1]
        previous_macd = self._macd_line[-2]
        previous_signal = self._signal_line[-2]

        # Бычье пересечение (MACD пересекает сигнальную линию снизу вверх)
        if (previous_macd <= previous_signal and
                current_macd > current_signal):
            return "BULLISH_CROSS"

        # Медвежье пересечение (MACD пересекает сигнальную линию сверху вниз)
        if (previous_macd >= previous_signal and
                current_macd < current_signal):
            return "BEARISH_CROSS"

        return None

    def get_histogram_signal(self) -> Optional[str]:
        """
        Определяет сигналы на основе гистограммы
        """
        if len(self._histogram) < 3:
            return None

        current_hist = self._histogram[-1]
        previous_hist = self._histogram[-2]
        second_previous_hist = self._histogram[-3]

        # Разворот гистограммы снизу вверх
        if (second_previous_hist > previous_hist and
                previous_hist < current_hist and
                current_hist > Decimal('0')):
            return "HISTOGRAM_BULLISH_REVERSAL"

        # Разворот гистограммы сверху вниз
        if (second_previous_hist < previous_hist and
                previous_hist > current_hist and
                current_hist < Decimal('0')):
            return "HISTOGRAM_BEARISH_REVERSAL"

        return None

    def get_trend_strength(self) -> Dict[str, Any]:
        """
        Анализирует силу тренда на основе MACD
        """
        if not self.macd_line or not self.signal_line:
            return {'strength': 'UNKNOWN', 'level': 0.0}

        # Относительная сила на основе расстояния между линиями
        distance = abs(self.macd_line - self.signal_line)

        # Нормализуем силу (0-1)
        if len(self._macd_values) < 10:
            strength_level = float(min(distance / Decimal('0.01'), Decimal('1')))
        else:
            # Используем исторические данные для нормализации
            recent_macd = self._macd_values[-10:]
            macd_range = max(recent_macd) - min(recent_macd)
            if macd_range > Decimal('0'):
                strength_level = float(min(distance / macd_range, Decimal('1')))
            else:
                strength_level = 0.0

        # Определяем уровень силы
        if strength_level > 0.7:
            strength_desc = "VERY_STRONG"
        elif strength_level > 0.5:
            strength_desc = "STRONG"
        elif strength_level > 0.3:
            strength_desc = "MODERATE"
        elif strength_level > 0.1:
            strength_desc = "WEAK"
        else:
            strength_desc = "VERY_WEAK"

        return {
            'strength': strength_desc,
            'level': strength_level,
            'distance': float(distance),
            'is_bullish': self.is_bullish,
            'is_bearish': self.is_bearish
        }

    def get_trading_signals(self) -> Dict[str, Any]:
        """
        Генерирует комплексные торговые сигналы на основе MACD
        """
        signals = {
            'signals': [],
            'confidence': 0.0,
            'trend': 'BULLISH' if self.is_bullish else 'BEARISH',
            'momentum': self.momentum,
            'trend_strength': self.get_trend_strength()
        }

        # Сигнал пересечения
        crossover = self.get_crossover_signal()
        if crossover:
            if crossover == "BULLISH_CROSS":
                signals['signals'].append({
                    'type': 'MACD_BULLISH_CROSS',
                    'reason': 'MACD crossed above signal line',
                    'confidence': 0.8
                })
            else:
                signals['signals'].append({
                    'type': 'MACD_BEARISH_CROSS',
                    'reason': 'MACD crossed below signal line',
                    'confidence': 0.8
                })

        # Сигнал гистограммы
        hist_signal = self.get_histogram_signal()
        if hist_signal:
            if hist_signal == "HISTOGRAM_BULLISH_REVERSAL":
                signals['signals'].append({
                    'type': 'HISTOGRAM_BULLISH_REVERSAL',
                    'reason': 'Histogram reversal from bottom',
                    'confidence': 0.7
                })
            else:
                signals['signals'].append({
                    'type': 'HISTOGRAM_BEARISH_REVERSAL',
                    'reason': 'Histogram reversal from top',
                    'confidence': 0.7
                })

        # Сигналы на основе положения относительно нуля
        if self.macd_line and self.macd_line > Decimal('0') and self.is_bullish:
            signals['signals'].append({
                'type': 'BULLISH_ABOVE_ZERO',
                'reason': 'MACD above zero and bullish',
                'confidence': 0.6
            })

        if self.macd_line and self.macd_line < Decimal('0') and self.is_bearish:
            signals['signals'].append({
                'type': 'BEARISH_BELOW_ZERO',
                'reason': 'MACD below zero and bearish',
                'confidence': 0.6
            })

        # Сигналы силы тренда
        trend_strength = signals['trend_strength']
        if trend_strength['strength'] in ["STRONG", "VERY_STRONG"]:
            if self.is_bullish:
                signals['signals'].append({
                    'type': 'STRONG_BULLISH_TREND',
                    'reason': 'Strong bullish MACD trend',
                    'confidence': 0.9
                })
            else:
                signals['signals'].append({
                    'type': 'STRONG_BEARISH_TREND',
                    'reason': 'Strong bearish MACD trend',
                    'confidence': 0.9
                })

        # Общая уверенность
        if signals['signals']:
            signals['confidence'] = max(s['confidence'] for s in signals['signals'])

        return signals

    def has_bullish_divergence(self, prices: List[Decimal]) -> bool:
        """
        Проверяет наличие бычьей дивергенции
        Цена делает更低 минимумы, а MACD - более высокие
        """
        if len(prices) < 4 or len(self._macd_line) < 4:
            return False

        # Берем последние 4 точки
        recent_prices = prices[-4:]
        recent_macd = self._macd_line[-4:]

        # Цена делает更低 минимумы
        price_lows_decreasing = all(recent_prices[i] > recent_prices[i + 1]
                                    for i in range(len(recent_prices) - 1))

        # MACD делает более высокие минимумы
        macd_lows_increasing = all(recent_macd[i] < recent_macd[i + 1]
                                   for i in range(len(recent_macd) - 1))

        return price_lows_decreasing and macd_lows_increasing

    def has_bearish_divergence(self, prices: List[Decimal]) -> bool:
        """
        Проверяет наличие медвежьей дивергенции
        Цена делает более высокие максимумы, а MACD - более низкие
        """
        if len(prices) < 4 or len(self._macd_line) < 4:
            return False

        recent_prices = prices[-4:]
        recent_macd = self._macd_line[-4:]

        # Цена делает более высокие максимумы
        price_highs_increasing = all(recent_prices[i] < recent_prices[i + 1]
                                     for i in range(len(recent_prices) - 1))

        # MACD делает более низкие максимумы
        macd_highs_decreasing = all(recent_macd[i] > recent_macd[i + 1]
                                    for i in range(len(recent_macd) - 1))

        return price_highs_increasing and macd_highs_decreasing

    def get_momentum_analysis(self) -> Dict[str, Any]:
        """
        Анализ моментума на основе MACD
        """
        if len(self._histogram) < 5:
            return {'momentum': 'UNKNOWN', 'acceleration': 0.0}

        recent_hist = self._histogram[-5:]

        # Рассчитываем ускорение (вторая производная)
        changes = [recent_hist[i + 1] - recent_hist[i] for i in range(len(recent_hist) - 1)]
        accelerations = [changes[i + 1] - changes[i] for i in range(len(changes) - 1)]

        avg_acceleration = sum(accelerations) / Decimal(str(len(accelerations))) if accelerations else Decimal('0')

        # Анализ моментума
        if avg_acceleration > Decimal('0.001'):
            momentum_desc = "ACCELERATING_BULLISH"
        elif avg_acceleration < Decimal('-0.001'):
            momentum_desc = "ACCELERATING_BEARISH"
        elif self.momentum == "ACCELERATING":
            momentum_desc = "BULLISH" if self.is_bullish else "BEARISH"
        else:
            momentum_desc = "NEUTRAL"

        return {
            'momentum': momentum_desc,
            'acceleration': float(avg_acceleration),
            'histogram_trend': self.momentum
        }


class MACDStrategy:
    """
    Стратегия торговли на основе MACD для Level Hunter
    """

    def __init__(self):
        self.macd = MACD()
        self.last_signal = None

    def analyze_candle(self, candle: Candle) -> Dict[str, Any]:
        """
        Анализирует свечу и возвращает торговые решения
        """
        # Обновляем MACD
        macd_data = self.macd.update(candle)

        if not macd_data:
            return {'action': 'HOLD', 'reason': 'Insufficient data'}

        analysis = {
            'action': 'HOLD',
            'confidence': 0.0,
            'signals': [],
            'trend': 'BULLISH' if self.macd.is_bullish else 'BEARISH',
            'momentum': self.macd.momentum,
            'trend_strength': self.macd.get_trend_strength(),
            'momentum_analysis': self.macd.get_momentum_analysis()
        }

        # Получаем торговые сигналы
        signals = self.macd.get_trading_signals()
        analysis['signals'] = signals['signals']
        analysis['confidence'] = signals['confidence']

        # Определяем действие на основе сигналов
        buy_signals = ['MACD_BULLISH_CROSS', 'HISTOGRAM_BULLISH_REVERSAL',
                       'BULLISH_ABOVE_ZERO', 'STRONG_BULLISH_TREND']
        sell_signals = ['MACD_BEARISH_CROSS', 'HISTOGRAM_BEARISH_REVERSAL',
                        'BEARISH_BELOW_ZERO', 'STRONG_BEARISH_TREND']

        for signal in signals['signals']:
            if signal['type'] in buy_signals and signal['confidence'] > analysis['confidence']:
                analysis['action'] = 'BUY'
                analysis['confidence'] = signal['confidence']
            elif signal['type'] in sell_signals and signal['confidence'] > analysis['confidence']:
                analysis['action'] = 'SELL'
                analysis['confidence'] = signal['confidence']

        # Проверка дивергенций
        prices = [c.close for c in self.macd._candles]
        if self.macd.has_bullish_divergence(prices):
            analysis['signals'].append({
                'type': 'BULLISH_DIVERGENCE',
                'reason': 'Bullish divergence detected',
                'confidence': 0.85
            })
            if analysis['action'] == 'HOLD':
                analysis['action'] = 'STRONG_BUY'
                analysis['confidence'] = 0.85

        if self.macd.has_bearish_divergence(prices):
            analysis['signals'].append({
                'type': 'BEARISH_DIVERGENCE',
                'reason': 'Bearish divergence detected',
                'confidence': 0.85
            })
            if analysis['action'] == 'HOLD':
                analysis['action'] = 'STRONG_SELL'
                analysis['confidence'] = 0.85

        return analysis