"""
Average True Range (ATR) индикатор
Для измерения волатильности и расчета стоп-лоссов
"""

from decimal import Decimal
from typing import List, Optional, Dict, Any
import numpy as np

from domain.models.candle import Candle


class ATR:
    """
    Average True Range индикатор
    Критически важен для Level Hunter стратегии:
    - Измерение волатильности рынка
    - Расчет динамических стоп-лоссов
    - Определение размера позиции
    - Фильтрация низковолатильных рынков
    """

    def __init__(self, period: int = 14):
        self.period = period
        self._candles: List[Candle] = []
        self._true_ranges: List[Decimal] = []
        self._values: List[Decimal] = []

        # Множители для стоп-лоссов
        self.stop_loss_multiplier = Decimal('2.0')  # 2 ATR для стоп-лосса
        self.take_profit_multiplier = Decimal('3.0')  # 3 ATR для тейк-профита

    @property
    def value(self) -> Optional[Decimal]:
        """Текущее значение ATR"""
        if not self._values:
            return None
        return self._values[-1]

    @property
    def volatility_level(self) -> str:
        """Уровень волатильности на основе ATR"""
        if not self.value:
            return "UNKNOWN"

        # Относительная оценка волатильности
        if len(self._values) < 10:
            return "NORMAL"

        # Берем среднее ATR за последние 10 периодов
        recent_atr = self._values[-10:]
        avg_atr = sum(recent_atr) / Decimal('10')

        current_vs_avg = self.value / avg_atr

        if current_vs_avg > Decimal('1.5'):
            return "HIGH"
        elif current_vs_avg > Decimal('2.0'):
            return "VERY_HIGH"
        elif current_vs_avg < Decimal('0.5'):
            return "LOW"
        elif current_vs_avg < Decimal('0.3'):
            return "VERY_LOW"
        else:
            return "NORMAL"

    @property
    def is_high_volatility(self) -> bool:
        """Высокая ли волатильность?"""
        return self.volatility_level in ["HIGH", "VERY_HIGH"]

    @property
    def is_low_volatility(self) -> bool:
        """Низкая ли волатильность?"""
        return self.volatility_level in ["LOW", "VERY_LOW"]

    def _calculate_true_range(self, current_candle: Candle, previous_candle: Candle) -> Decimal:
        """
        Рассчитывает True Range для двух свечей

        True Range = max(
            high - low,
            abs(high - previous_close),
            abs(low - previous_close)
        )
        """
        # Method 1: Current high - current low
        method1 = current_candle.high - current_candle.low

        # Method 2: |Current high - previous close|
        method2 = abs(current_candle.high - previous_candle.close)

        # Method 3: |Current low - previous close|
        method3 = abs(current_candle.low - previous_candle.close)

        # True Range - максимальное из трех значений
        true_range = max(method1, method2, method3)
        return true_range

    def update(self, candle: Candle) -> Optional[Decimal]:
        """
        Обновляет ATR новой свечой

        Args:
            candle: Новая свеча для расчета

        Returns:
            Optional[Decimal]: Новое значение ATR или None если недостаточно данных
        """
        self._candles.append(candle)

        # Нужно как минимум 2 свечи для расчета TR
        if len(self._candles) < 2:
            return None

        # Рассчитываем True Range
        current_candle = self._candles[-1]
        previous_candle = self._candles[-2]
        true_range = self._calculate_true_range(current_candle, previous_candle)

        self._true_ranges.append(true_range)

        # Нужно period TR для расчета ATR
        if len(self._true_ranges) < self.period:
            return None

        # Берем последние period TR
        recent_tr = self._true_ranges[-self.period:]

        if len(self._values) == 0:
            # Первое значение ATR - простая средняя TR
            atr_value = sum(recent_tr) / Decimal(str(self.period))
        else:
            # Последующие значения: ATR = (Previous ATR * (period-1) + Current TR) / period
            previous_atr = self._values[-1]
            atr_value = (previous_atr * Decimal(str(self.period - 1)) + true_range) / Decimal(str(self.period))

        self._values.append(atr_value)

        # Поддерживаем разумный размер истории
        max_history = self.period * 3
        if len(self._candles) > max_history:
            self._candles.pop(0)
        if len(self._true_ranges) > max_history:
            self._true_ranges.pop(0)
        if len(self._values) > max_history:
            self._values.pop(0)

        return atr_value

    def calculate_from_candles(self, candles: List[Candle]) -> List[Decimal]:
        """
        Рассчитывает ATR для списка свечей

        Args:
            candles: Список свечей (должен быть длиннее period)

        Returns:
            List[Decimal]: Список значений ATR
        """
        if len(candles) <= self.period:
            return []

        atr_values = []
        true_ranges = []

        # Рассчитываем TR для всех пар свечей
        for i in range(1, len(candles)):
            tr = self._calculate_true_range(candles[i], candles[i - 1])
            true_ranges.append(tr)

        # Первое значение ATR - SMA TR
        first_atr = sum(true_ranges[:self.period]) / Decimal(str(self.period))
        atr_values.append(first_atr)

        # Последующие значения ATR
        for i in range(self.period, len(true_ranges)):
            atr = (atr_values[-1] * Decimal(str(self.period - 1)) + true_ranges[i]) / Decimal(str(self.period))
            atr_values.append(atr)

        return atr_values

    def calculate_stop_loss(self, entry_price: Decimal, is_long: bool = True) -> Decimal:
        """
        Рассчитывает стоп-лосс на основе ATR

        Args:
            entry_price: Цена входа
            is_long: Длинная ли позиция

        Returns:
            Decimal: Цена стоп-лосса
        """
        if not self.value:
            return entry_price

        atr_distance = self.value * self.stop_loss_multiplier

        if is_long:
            stop_loss = entry_price - atr_distance
        else:
            stop_loss = entry_price + atr_distance

        return stop_loss

    def calculate_take_profit(self, entry_price: Decimal, is_long: bool = True) -> Decimal:
        """
        Рассчитывает тейк-профит на основе ATR

        Args:
            entry_price: Цена входа
            is_long: Длинная ли позиция

        Returns:
            Decimal: Цена тейк-профита
        """
        if not self.value:
            return entry_price

        atr_distance = self.value * self.take_profit_multiplier

        if is_long:
            take_profit = entry_price + atr_distance
        else:
            take_profit = entry_price - atr_distance

        return take_profit

    def calculate_position_size(self, account_balance: Decimal, risk_per_trade: Decimal = Decimal('1.0')) -> Decimal:
        """
        Рассчитывает размер позиции на основе ATR и риска

        Args:
            account_balance: Баланс счета
            risk_per_trade: Риск на сделку в % (по умолчанию 1%)

        Returns:
            Decimal: Размер позиции в базовой валюте
        """
        if not self.value:
            return Decimal('0')

        # Риск в деньгах
        risk_amount = account_balance * (risk_per_trade / Decimal('100'))

        # Расстояние стоп-лосса в ATR
        stop_loss_atr = self.value * self.stop_loss_multiplier

        # Размер позиции = риск / расстояние стоп-лосса
        if stop_loss_atr > Decimal('0'):
            position_size = risk_amount / stop_loss_atr
        else:
            position_size = Decimal('0')

        return position_size

    def get_volatility_analysis(self) -> Dict[str, Any]:
        """
        Анализ волатильности для принятия торговых решений
        """
        if not self.value:
            return {"volatility": "UNKNOWN", "recommendation": "NO_DATA"}

        analysis = {
            "atr_value": float(self.value),
            "volatility_level": self.volatility_level,
            "is_high_volatility": self.is_high_volatility,
            "is_low_volatility": self.is_low_volatility,
            "recommendation": "TRADE_NORMAL",
            "risk_multiplier": 1.0
        }

        # Рекомендации на основе волатильности
        if self.is_high_volatility:
            analysis.update({
                "recommendation": "REDUCE_POSITION_SIZE",
                "risk_multiplier": 0.5,
                "reason": "High volatility market - reduce risk"
            })
        elif self.is_low_volatility:
            analysis.update({
                "recommendation": "INCREASE_POSITION_SIZE",
                "risk_multiplier": 1.5,
                "reason": "Low volatility market - opportunity for larger positions"
            })

        # Анализ тренда волатильности
        if len(self._values) >= 5:
            recent_atr = self._values[-5:]
            volatility_trend = "STABLE"

            if all(recent_atr[i] < recent_atr[i + 1] for i in range(len(recent_atr) - 1)):
                volatility_trend = "INCREASING"
            elif all(recent_atr[i] > recent_atr[i + 1] for i in range(len(recent_atr) - 1)):
                volatility_trend = "DECREASING"

            analysis["volatility_trend"] = volatility_trend

        return analysis

    def get_support_resistance_levels(self, current_price: Decimal, num_levels: int = 3) -> Dict[str, List[Decimal]]:
        """
        Генерирует уровни поддержки/сопротивления на основе ATR

        Args:
            current_price: Текущая цена
            num_levels: Количество уровней

        Returns:
            Dict с уровнями поддержки и сопротивления
        """
        if not self.value:
            return {"support": [], "resistance": []}

        support_levels = []
        resistance_levels = []

        atr_distance = self.value

        for i in range(1, num_levels + 1):
            # Уровни поддержки
            support = current_price - (atr_distance * Decimal(str(i)))
            support_levels.append(support)

            # Уровни сопротивления
            resistance = current_price + (atr_distance * Decimal(str(i)))
            resistance_levels.append(resistance)

        return {
            "support": support_levels,
            "resistance": resistance_levels
        }