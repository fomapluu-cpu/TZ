"""
Exponential Moving Average (EMA) индикатор
Для определения трендов и динамических уровней поддержки/сопротивления
"""

from decimal import Decimal
from typing import List, Optional
import numpy as np

from domain.models.candle import Candle


class EMA:
    """
    Exponential Moving Average индикатор
    Критически важен для Level Hunter стратегии:
    - Определение тренда
    - Динамические уровни поддержки/сопротивления
    - Сигналы пересечения
    """

    def __init__(self, period: int = 20):
        self.period = period
        self.multiplier = Decimal('2') / Decimal(str(period + 1))
        self._values: List[Decimal] = []
        self._prices: List[Decimal] = []

    @property
    def value(self) -> Optional[Decimal]:
        """Текущее значение EMA"""
        if not self._values:
            return None
        return self._values[-1]

    @property
    def trend(self) -> str:
        """Определяет тренд на основе EMA"""
        if len(self._values) < 2:
            return "SIDEWAYS"

        current = self._values[-1]
        previous = self._values[-2]

        if current > previous:
            return "BULLISH"
        elif current < previous:
            return "BEARISH"
        else:
            return "SIDEWAYS"

    @property
    def slope(self) -> Decimal:
        """Наклон EMA в процентах"""
        if len(self._values) < 2:
            return Decimal('0')

        current = self._values[-1]
        previous = self._values[-2]

        if previous == Decimal('0'):
            return Decimal('0')

        return ((current - previous) / previous) * Decimal('100')

    def update(self, price: Decimal) -> Decimal:
        """
        Обновляет EMA новым значением цены

        Args:
            price: Новая цена для расчета

        Returns:
            Decimal: Новое значение EMA
        """
        self._prices.append(price)

        if len(self._prices) == 1:
            # Первое значение - простая средняя
            ema_value = price
        else:
            # EMA = (Price * multiplier) + (Previous EMA * (1 - multiplier))
            previous_ema = self._values[-1]
            ema_value = (price * self.multiplier) + (previous_ema * (Decimal('1') - self.multiplier))

        self._values.append(ema_value)

        # Поддерживаем только необходимую историю
        if len(self._prices) > self.period * 2:
            self._prices.pop(0)
            self._values.pop(0)

        return ema_value

    def update_from_candle(self, candle: Candle) -> Decimal:
        """Обновляет EMA из свечи (использует цену закрытия)"""
        return self.update(candle.close)

    def calculate_from_prices(self, prices: List[Decimal]) -> List[Decimal]:
        """
        Рассчитывает EMA для списка цен

        Args:
            prices: Список цен

        Returns:
            List[Decimal]: Список значений EMA
        """
        if not prices:
            return []

        # Начинаем с SMA для первого значения
        sma = sum(prices[:self.period]) / Decimal(str(self.period))
        ema_values = [sma]

        # Рассчитываем EMA для остальных цен
        for price in prices[self.period:]:
            ema = (price * self.multiplier) + (ema_values[-1] * (Decimal('1') - self.multiplier))
            ema_values.append(ema)

        return ema_values

    def is_price_above(self, price: Decimal) -> bool:
        """Проверяет, находится ли цена выше EMA"""
        if not self.value:
            return False
        return price > self.value

    def is_price_below(self, price: Decimal) -> bool:
        """Проверяет, находится ли цена ниже EMA"""
        if not self.value:
            return False
        return price < self.value

    def distance_from_price(self, price: Decimal) -> Decimal:
        """Расстояние от цены до EMA в процентах"""
        if not self.value or self.value == Decimal('0'):
            return Decimal('0')
        return ((price - self.value) / self.value) * Decimal('100')

    def crossover_signal(self, price: Decimal) -> Optional[str]:
        """
        Определяет сигнал пересечения цены и EMA

        Returns:
            Optional[str]: "BUY" если цена пересекла EMA снизу вверх,
                          "SELL" если сверху вниз, None если нет сигнала
        """
        if len(self._prices) < 2 or len(self._values) < 2:
            return None

        current_price = price
        previous_price = self._prices[-2] if len(self._prices) > 1 else self._prices[-1]
        current_ema = self._values[-1]
        previous_ema = self._values[-2] if len(self._values) > 1 else self._values[-1]

        # Проверяем пересечение снизу вверх (бычий сигнал)
        if (previous_price <= previous_ema and
                current_price > current_ema):
            return "BUY"

        # Проверяем пересечение сверху вниз (медвежий сигнал)
        if (previous_price >= previous_ema and
                current_price < current_ema):
            return "SELL"

        return None

    def get_support_resistance_level(self) -> Optional[Decimal]:
        """
        Возвращает EMA как динамический уровень поддержки/сопротивления
        """
        return self.value


class MultiEMA:
    """
    Мульти-EMA система для анализа нескольких периодов
    Используется для определения выстраивания тренда
    """

    def __init__(self, periods: List[int] = [9, 21, 50, 200]):
        self.periods = periods
        self.emas = {period: EMA(period) for period in periods}

    def update(self, price: Decimal) -> None:
        """Обновляет все EMA новым значением цены"""
        for ema in self.emas.values():
            ema.update(price)

    def update_from_candle(self, candle: Candle) -> None:
        """Обновляет все EMA из свечи"""
        self.update(candle.close)

    def get_alignment(self) -> str:
        """
        Определяет выстраивание EMA

        Returns:
            str: "BULLISH" - бычье выстраивание (короткие > длинных),
                 "BEARISH" - медвежье выстраивание (короткие < длинных),
                 "MIXED" - смешанное выстраивание
        """
        values = []
        for period in sorted(self.periods):
            ema_value = self.emas[period].value
            if ema_value is None:
                return "MIXED"
            values.append(ema_value)

        # Проверяем бычье выстраивание (убывающие значения)
        is_bullish = all(values[i] >= values[i + 1] for i in range(len(values) - 1))
        # Проверяем медвежье выстраивание (возрастающие значения)
        is_bearish = all(values[i] <= values[i + 1] for i in range(len(values) - 1))

        if is_bullish:
            return "BULLISH"
        elif is_bearish:
            return "BEARISH"
        else:
            return "MIXED"

    def get_ema(self, period: int) -> Optional[EMA]:
        """Возвращает EMA для указанного периода"""
        return self.emas.get(period)

    def get_current_prices_distance(self) -> Dict[int, Decimal]:
        """Возвращает расстояния цены от каждой EMA"""
        if not any(ema.value for ema in self.emas.values()):
            return {}

        # Берем последнюю цену из любого EMA
        sample_ema = next(iter(self.emas.values()))
        if not sample_ema._prices:
            return {}

        current_price = sample_ema._prices[-1]
        distances = {}

        for period, ema in self.emas.items():
            if ema.value:
                distances[period] = ema.distance_from_price(current_price)

        return distances