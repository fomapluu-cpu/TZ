"""
Relative Strength Index (RSI) индикатор
Для определения перекупленности и перепроданности рынка
"""

from decimal import Decimal
from typing import List, Optional, Dict, Any
import numpy as np

from domain.models.candle import Candle


class RSI:
    """
    Relative Strength Index индикатор
    Критически важен для Level Hunter стратегии:
    - Определение перекупленности (overbought)
    - Определение перепроданности (oversold)
    - Дивергенции для разворота тренда
    - Подтверждение силы движения
    """

    def __init__(self, period: int = 14):
        self.period = period
        self._prices: List[Decimal] = []
        self._values: List[Decimal] = []
        self._gains: List[Decimal] = []
        self._losses: List[Decimal] = []

        # Уровни для торговых сигналов
        self.overbought_level = Decimal('70')
        self.oversold_level = Decimal('30')
        self.strong_trend_level = Decimal('80')  # Сильная перекупленность
        self.strong_oversold_level = Decimal('20')  # Сильная перепроданность

    @property
    def value(self) -> Optional[Decimal]:
        """Текущее значение RSI"""
        if not self._values:
            return None
        return self._values[-1]

    @property
    def is_overbought(self) -> bool:
        """Находится ли рынок в зоне перекупленности"""
        if not self.value:
            return False
        return self.value >= self.overbought_level

    @property
    def is_oversold(self) -> bool:
        """Находится ли рынок в зоне перепроданности"""
        if not self.value:
            return False
        return self.value <= self.oversold_level

    @property
    def is_strongly_overbought(self) -> bool:
        """Сильная перекупленность"""
        if not self.value:
            return False
        return self.value >= self.strong_trend_level

    @property
    def is_strongly_oversold(self) -> bool:
        """Сильная перепроданность"""
        if not self.value:
            return False
        return self.value <= self.strong_oversold_level

    @property
    def trend(self) -> str:
        """Определяет тренд на основе RSI"""
        if not self.value:
            return "NEUTRAL"

        if self.is_overbought:
            return "OVERBOUGHT"
        elif self.is_oversold:
            return "OVERSOLD"
        else:
            return "NEUTRAL"

    @property
    def momentum(self) -> str:
        """Моментум на основе последних значений RSI"""
        if len(self._values) < 2:
            return "NEUTRAL"

        current = self._values[-1]
        previous = self._values[-2]

        if current > previous:
            return "BULLISH"
        elif current < previous:
            return "BEARISH"
        else:
            return "NEUTRAL"

    def update(self, price: Decimal) -> Optional[Decimal]:
        """
        Обновляет RSI новым значением цены

        Args:
            price: Новая цена для расчета

        Returns:
            Optional[Decimal]: Новое значение RSI или None если недостаточно данных
        """
        self._prices.append(price)

        # Нужно как минимум period + 1 цен для расчета
        if len(self._prices) < self.period + 1:
            return None

        # Рассчитываем изменения
        changes = []
        for i in range(1, len(self._prices)):
            change = self._prices[i] - self._prices[i - 1]
            changes.append(change)

        # Берем только последние period изменений
        recent_changes = changes[-self.period:]

        # Разделяем на gains и losses
        gains = [max(change, Decimal('0')) for change in recent_changes]
        losses = [max(-change, Decimal('0')) for change in recent_changes]

        # Рассчитываем средние gain и loss
        avg_gain = sum(gains) / Decimal(str(self.period))
        avg_loss = sum(losses) / Decimal(str(self.period))

        # Сохраняем для истории
        self._gains.append(avg_gain)
        self._losses.append(avg_loss)

        # Рассчитываем RS и RSI
        if avg_loss == Decimal('0'):
            rsi = Decimal('100')
        else:
            rs = avg_gain / avg_loss
            rsi = Decimal('100') - (Decimal('100') / (Decimal('1') + rs))

        self._values.append(rsi)

        # Поддерживаем разумный размер истории
        max_history = self.period * 3
        if len(self._values) > max_history:
            self._values.pop(0)
            self._gains.pop(0)
            self._losses.pop(0)
        if len(self._prices) > max_history + 1:
            self._prices.pop(0)

        return rsi

    def update_from_candle(self, candle: Candle) -> Optional[Decimal]:
        """Обновляет RSI из свечи (использует цену закрытия)"""
        return self.update(candle.close)

    def calculate_from_prices(self, prices: List[Decimal]) -> List[Decimal]:
        """
        Рассчитывает RSI для списка цен

        Args:
            prices: Список цен (должен быть длиннее period)

        Returns:
            List[Decimal]: Список значений RSI
        """
        if len(prices) <= self.period:
            return []

        rsi_values = []

        for i in range(self.period, len(prices)):
            # Берем окно из period цен
            window = prices[i - self.period:i + 1]
            changes = [window[j] - window[j - 1] for j in range(1, len(window))]

            gains = [max(change, Decimal('0')) for change in changes]
            losses = [max(-change, Decimal('0')) for change in changes]

            avg_gain = sum(gains) / Decimal(str(self.period))
            avg_loss = sum(losses) / Decimal(str(self.period))

            if avg_loss == Decimal('0'):
                rsi = Decimal('100')
            else:
                rs = avg_gain / avg_loss
                rsi = Decimal('100') - (Decimal('100') / (Decimal('1') + rs))

            rsi_values.append(rsi)

        return rsi_values

    def get_trading_signal(self) -> Dict[str, Any]:
        """
        Генерирует торговые сигналы на основе RSI

        Returns:
            Dict с сигналами и уверенностью
        """
        if not self.value:
            return {"signal": "HOLD", "confidence": 0.0}

        signal_info = {
            "signal": "HOLD",
            "confidence": 0.0,
            "rsi_value": float(self.value),
            "trend": self.trend,
            "momentum": self.momentum
        }

        # Сильные сигналы перепроданности
        if self.is_strongly_oversold:
            signal_info.update({
                "signal": "STRONG_BUY",
                "confidence": 0.9,
                "reason": "RSI in strong oversold territory"
            })
        elif self.is_oversold and self.momentum == "BULLISH":
            signal_info.update({
                "signal": "BUY",
                "confidence": 0.7,
                "reason": "RSI oversold with bullish momentum"
            })
        elif self.is_oversold:
            signal_info.update({
                "signal": "WEAK_BUY",
                "confidence": 0.5,
                "reason": "RSI oversold but no bullish momentum"
            })

        # Сильные сигналы перекупленности
        elif self.is_strongly_overbought:
            signal_info.update({
                "signal": "STRONG_SELL",
                "confidence": 0.9,
                "reason": "RSI in strong overbought territory"
            })
        elif self.is_overbought and self.momentum == "BEARISH":
            signal_info.update({
                "signal": "SELL",
                "confidence": 0.7,
                "reason": "RSI overbought with bearish momentum"
            })
        elif self.is_overbought:
            signal_info.update({
                "signal": "WEAK_SELL",
                "confidence": 0.5,
                "reason": "RSI overbought but no bearish momentum"
            })

        # Сигналы из нейтральной зоны
        elif self.momentum == "BULLISH" and self.value > Decimal('50'):
            signal_info.update({
                "signal": "BULLISH_HOLD",
                "confidence": 0.6,
                "reason": "RSI above 50 with bullish momentum"
            })
        elif self.momentum == "BEARISH" and self.value < Decimal('50'):
            signal_info.update({
                "signal": "BEARISH_HOLD",
                "confidence": 0.6,
                "reason": "RSI below 50 with bearish momentum"
            })

        return signal_info

    def has_bullish_divergence(self, prices: List[Decimal]) -> bool:
        """
        Проверяет наличие бычьей дивергенции
        Цена делает更低 минимумы, а RSI - более высокие
        """
        if len(self._values) < 4 or len(prices) < 4:
            return False

        # Берем последние 4 точки
        recent_prices = prices[-4:]
        recent_rsi = self._values[-4:]

        # Проверяем дивергенцию
        price_lows_decreasing = (recent_prices[0] > recent_prices[1] and
                                 recent_prices[1] > recent_prices[2] and
                                 recent_prices[2] > recent_prices[3])

        rsi_lows_increasing = (recent_rsi[0] < recent_rsi[1] and
                               recent_rsi[1] < recent_rsi[2] and
                               recent_rsi[2] < recent_rsi[3])

        return price_lows_decreasing and rsi_lows_increasing

    def has_bearish_divergence(self, prices: List[Decimal]) -> bool:
        """
        Проверяет наличие медвежьей дивергенции
        Цена делает более высокие максимумы, а RSI - более низкие
        """
        if len(self._values) < 4 or len(prices) < 4:
            return False

        # Берем последние 4 точки
        recent_prices = prices[-4:]
        recent_rsi = self._values[-4:]

        # Проверяем дивергенцию
        price_highs_increasing = (recent_prices[0] < recent_prices[1] and
                                  recent_prices[1] < recent_prices[2] and
                                  recent_prices[2] < recent_prices[3])

        rsi_highs_decreasing = (recent_rsi[0] > recent_rsi[1] and
                                recent_rsi[1] > recent_rsi[2] and
                                recent_rsi[2] > recent_rsi[3])

        return price_highs_increasing and rsi_highs_decreasing

    def get_volatility(self) -> Decimal:
        """Волатильность RSI (стандартное отклонение)"""
        if len(self._values) < 2:
            return Decimal('0')

        values_float = [float(v) for v in self._values]
        return Decimal(str(np.std(values_float)))