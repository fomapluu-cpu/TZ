"""
Production-ready Kill Switch для экстренной остановки торговли
Полная интеграция с Telegram для управления
"""

from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Any
from enum import Enum
import asyncio

from domain.models.order import Order
from domain.models.position import Position
from execution.order_manager import OrderManager
from execution.trade_executor import TradeExecutor
from api.telegram.bot import TelegramBot


class KillSwitchStatus(Enum):
    """Статусы Kill Switch"""
    ACTIVE = "ACTIVE"
    TRIGGERED = "TRIGGERED"
    RESET = "RESET"
    DISABLED = "DISABLED"


class KillSwitchReason(Enum):
    """Причины активации Kill Switch"""
    MANUAL = "MANUAL"
    MAX_DRAWDOWN = "MAX_DRAWDOWN"
    DAILY_LOSS_LIMIT = "DAILY_LOSS_LIMIT"
    SYSTEM_ERROR = "SYSTEM_ERROR"
    MARKET_CRASH = "MARKET_CRASH"
    VOLATILITY_SPIKE = "VOLATILITY_SPIKE"


class KillSwitch:
    """
    Production-ready Kill Switch с полной Telegram интеграцией
    Экстренная остановка всей торговой активности
    """

    def __init__(
            self,
            order_manager: OrderManager,
            trade_executor: TradeExecutor,
            telegram_bot: Optional[TelegramBot] = None,
            logger=None
    ):
        self.order_manager = order_manager
        self.trade_executor = trade_executor
        self.telegram_bot = telegram_bot
        self.logger = logger

        # Состояние Kill Switch
        self.status = KillSwitchStatus.ACTIVE
        self.triggered_time: Optional[datetime] = None
        self.trigger_reason: Optional[KillSwitchReason] = None
        self.trigger_details: Dict[str, Any] = {}

        # Статистика
        self.activation_count = 0
        self.last_reset_time: Optional[datetime] = None

    async def activate(
            self,
            reason: KillSwitchReason,
            details: Dict[str, Any] = None,
            notify_telegram: bool = True
    ) -> bool:
        """
        Активирует Kill Switch - экстренная остановка торговли

        Args:
            reason: Причина активации
            details: Детали активации
            notify_telegram: Отправлять уведомление в Telegram

        Returns:
            bool: True если активация успешна
        """
        try:
            if self.status == KillSwitchStatus.TRIGGERED:
                self.logger.warning("Kill Switch already activated")
                return False

            self.logger.critical(
                "ACTIVATING KILL SWITCH",
                reason=reason.value,
                details=details
            )

            # Обновляем состояние
            self.status = KillSwitchStatus.TRIGGERED
            self.triggered_time = datetime.utcnow()
            self.trigger_reason = reason
            self.trigger_details = details or {}
            self.activation_count += 1

            # 1. Отменяем все активные ордера
            cancelled_orders = await self._cancel_all_orders()

            # 2. Закрываем все позиции
            closed_positions = await self._close_all_positions()

            # 3. Уведомляем в Telegram
            if notify_telegram and self.telegram_bot:
                await self._send_telegram_alert(cancelled_orders, closed_positions)

            self.logger.critical(
                "KILL SWITCH ACTIVATED SUCCESSFULLY",
                reason=reason.value,
                cancelled_orders=len(cancelled_orders),
                closed_positions=len(closed_positions)
            )

            return True

        except Exception as e:
            self.logger.error("Kill Switch activation failed", error=str(e))

            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(
                    f"💥 *ОШИБКА АКТИВАЦИИ KILL SWITCH*\n\n"
                    f"Причина: {reason.value}\n"
                    f"Ошибка: {str(e)}"
                )

            return False

    async def deactivate(self, reason: str = "manual_reset") -> bool:
        """
        Деактивирует Kill Switch (только manual)

        Args:
            reason: Причина деактивации

        Returns:
            bool: True если деактивация успешна
        """
        try:
            if self.status != KillSwitchStatus.TRIGGERED:
                self.logger.warning("Kill Switch not active, cannot deactivate")
                return False

            self.logger.info("Deactivating Kill Switch", reason=reason)

            # Обновляем состояние
            self.status = KillSwitchStatus.RESET
            self.last_reset_time = datetime.utcnow()

            # Уведомляем в Telegram
            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(
                    f"🟢 *KILL SWITCH ДЕАКТИВИРОВАН*\n\n"
                    f"Причина: {reason}\n"
                    f"Был активен: {self._get_activation_duration()}\n"
                    f"Всего активаций: {self.activation_count}"
                )

            self.logger.info("Kill Switch deactivated successfully")
            return True

        except Exception as e:
            self.logger.error("Kill Switch deactivation failed", error=str(e))
            return False

    async def _cancel_all_orders(self) -> List[str]:
        """Отменяет все активные ордера"""
        cancelled_order_ids = []

        try:
            # Получаем все символы из конфигурации
            # В реальной реализации нужно получить из конфига
            symbols = ["BTCUSDT", "ETHUSDT", "ADAUSDT", "DOTUSDT"]

            for symbol in symbols:
                try:
                    # Отменяем все ордера для символа
                    cancelled_count = await self.order_manager.cancel_all_orders(symbol)
                    if cancelled_count > 0:
                        cancelled_order_ids.append(f"{symbol}:{cancelled_count}")

                    self.logger.info(
                        "Cancelled orders for symbol",
                        symbol=symbol,
                        count=cancelled_count
                    )

                except Exception as e:
                    self.logger.error(
                        "Failed to cancel orders for symbol",
                        symbol=symbol,
                        error=str(e)
                    )

        except Exception as e:
            self.logger.error("Failed to cancel all orders", error=str(e))

        return cancelled_order_ids

    async def _close_all_positions(self) -> List[str]:
        """Закрывает все активные позиции"""
        closed_positions = []

        try:
            # Получаем активные позиции
            positions = await self.trade_executor.get_active_positions()

            for symbol, position in positions.items():
                try:
                    # Закрываем позицию
                    success = await self.trade_executor.close_position(
                        symbol,
                        reason="kill_switch_activation"
                    )

                    if success:
                        closed_positions.append(symbol)

                    self.logger.info(
                        "Closed position",
                        symbol=symbol,
                        success=success
                    )

                except Exception as e:
                    self.logger.error(
                        "Failed to close position",
                        symbol=symbol,
                        error=str(e)
                    )

        except Exception as e:
            self.logger.error("Failed to close all positions", error=str(e))

        return closed_positions

    async def _send_telegram_alert(self, cancelled_orders: List[str], closed_positions: List[str]) -> None:
        """Отправляет уведомление в Telegram об активации Kill Switch"""
        try:
            message = (
                f"🔴 *KILL SWITCH АКТИВИРОВАН!*\n\n"
                f"*Причина:* {self.trigger_reason.value}\n"
                f"*Время:* {self.triggered_time.strftime('%H:%M:%S')}\n"
                f"*Детали:* {self._format_trigger_details()}\n\n"
                f"*Действия:*\n"
                f"• Отменено ордеров: {len(cancelled_orders)}\n"
                f"• Закрыто позиций: {len(closed_positions)}\n\n"
                f"⚠️ *Торговля остановлена!*"
            )

            await self.telegram_bot.broadcast_to_all_users(message)

        except Exception as e:
            self.logger.error("Failed to send Telegram alert", error=str(e))

    def _format_trigger_details(self) -> str:
        """Форматирует детали активации для Telegram"""
        if not self.trigger_details:
            return "Нет дополнительных деталей"

        details = []
        for key, value in self.trigger_details.items():
            if isinstance(value, (int, float, Decimal)):
                details.append(f"{key}: {value}")
            else:
                details.append(f"{key}: {str(value)}")

        return ", ".join(details)

    def _get_activation_duration(self) -> str:
        """Возвращает продолжительность активации"""
        if not self.triggered_time:
            return "N/A"

        duration = datetime.utcnow() - self.triggered_time
        hours = duration.total_seconds() / 3600

        if hours < 1:
            minutes = duration.total_seconds() / 60
            return f"{minutes:.1f} мин"
        else:
            return f"{hours:.1f} ч"

    async def get_status(self) -> Dict[str, Any]:
        """Возвращает статус Kill Switch"""
        return {
            "status": self.status.value,
            "triggered_time": self.triggered_time.isoformat() if self.triggered_time else None,
            "trigger_reason": self.trigger_reason.value if self.trigger_reason else None,
            "trigger_details": self.trigger_details,
            "activation_count": self.activation_count,
            "last_reset_time": self.last_reset_time.isoformat() if self.last_reset_time else None,
            "activation_duration": self._get_activation_duration() if self.triggered_time else None
        }

    async def health_check(self) -> Dict[str, Any]:
        """Проверяет состояние Kill Switch"""
        try:
            return {
                "status": "healthy",
                "kill_switch_status": self.status.value,
                "ready": True,
                "telegram_connected": self.telegram_bot is not None
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }

    # Telegram команды
    async def handle_telegram_command(self, command: str, user_id: int) -> str:
        """
        Обрабатывает команды Telegram для управления Kill Switch

        Args:
            command: Команда (activate, deactivate, status)
            user_id: ID пользователя

        Returns:
            str: Ответ для пользователя
        """
        try:
            if command == "status":
                status = await self.get_status()
                return (
                    f"🔴 *KILL SWITCH STATUS*\n\n"
                    f"• Статус: {status['status']}\n"
                    f"• Причина: {status['trigger_reason'] or 'N/A'}\n"
                    f"• Активаций: {status['activation_count']}\n"
                    f"• Длительность: {status['activation_duration'] or 'N/A'}\n"
                    f"• Последний сброс: {status['last_reset_time'] or 'N/A'}"
                )

            elif command == "activate_manual":
                success = await self.activate(
                    KillSwitchReason.MANUAL,
                    {"initiated_by": f"telegram_user_{user_id}"}
                )
                return "✅ Kill Switch активирован" if success else "❌ Ошибка активации"

            elif command == "deactivate":
                success = await self.deactivate(f"telegram_user_{user_id}")
                return "✅ Kill Switch деактивирован" if success else "❌ Ошибка деактивации"

            else:
                return "❌ Неизвестная команда"

        except Exception as e:
            self.logger.error("Telegram command handling failed", command=command, error=str(e))
            return f"❌ Ошибка обработки команды: {str(e)}"

    # Automatic triggers
    async def check_auto_triggers(
            self,
            risk_metrics: Dict[str, Any],
            market_conditions: Dict[str, Any]
    ) -> bool:
        """
        Проверяет автоматические триггеры для Kill Switch

        Args:
            risk_metrics: Метрики рисков
            market_conditions: Рыночные условия

        Returns:
            bool: True если Kill Switch был активирован
        """
        try:
            if self.status == KillSwitchStatus.TRIGGERED:
                return False

            # Проверка максимальной просадки
            if await self._check_drawdown_trigger(risk_metrics):
                return True

            # Проверка дневного лимита убытков
            if await self._check_daily_loss_trigger(risk_metrics):
                return True

            # Проверка рыночных условий
            if await self._check_market_conditions_trigger(market_conditions):
                return True

            return False

        except Exception as e:
            self.logger.error("Auto trigger check failed", error=str(e))
            return False

    async def _check_drawdown_trigger(self, risk_metrics: Dict[str, Any]) -> bool:
        """Проверяет триггер по максимальной просадке"""
        max_drawdown = risk_metrics.get('max_drawdown', 0)
        drawdown_limit = risk_metrics.get('drawdown_limit', 10)

        if max_drawdown >= drawdown_limit:
            await self.activate(
                KillSwitchReason.MAX_DRAWDOWN,
                {
                    "current_drawdown": max_drawdown,
                    "limit": drawdown_limit,
                    "type": "auto_trigger"
                }
            )
            return True
        return False

    async def _check_daily_loss_trigger(self, risk_metrics: Dict[str, Any]) -> bool:
        """Проверяет триггер по дневному лимиту убытков"""
        daily_pnl = risk_metrics.get('daily_pnl', 0)
        daily_loss_limit = risk_metrics.get('daily_loss_limit', 5)

        if daily_pnl <= -daily_loss_limit:
            await self.activate(
                KillSwitchReason.DAILY_LOSS_LIMIT,
                {
                    "daily_pnl": daily_pnl,
                    "limit": daily_loss_limit,
                    "type": "auto_trigger"
                }
            )
            return True
        return False

    async def _check_market_conditions_trigger(self, market_conditions: Dict[str, Any]) -> bool:
        """Проверяет триггер по рыночным условиям"""
        # В реальной реализации здесь будет анализ волатильности,
        # ликвидности и других рыночных условий

        volatility = market_conditions.get('volatility', 0)
        if volatility > 50:  # Пример порога
            await self.activate(
                KillSwitchReason.VOLATILITY_SPIKE,
                {
                    "volatility": volatility,
                    "threshold": 50,
                    "type": "auto_trigger"
                }
            )
            return True
        return False