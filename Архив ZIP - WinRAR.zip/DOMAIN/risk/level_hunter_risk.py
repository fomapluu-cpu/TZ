# level_hunter_risk.py
"""
Production-ready Risk Management для Level Hunter стратегии
Специфичные правила рисков для стратегии охоты за уровнями
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import Dict, List, Optional, Tuple
import asyncio

from domain.models.signal import Signal, SignalType
from domain.models.order import Order, OrderSide
from domain.models.position import Position
from domain.risk.risk_engine import RiskEngine, RiskViolationError
from utils.config_loader import LevelHunterRiskConfig


class LevelHunterRiskManager:
    """
    Risk Management специфичный для Level Hunter стратегии
    Дополнительные проверки и лимиты для стратегии охоты за уровнями
    """

    def __init__(self, risk_engine: RiskEngine, config: LevelHunterRiskConfig, logger):
        self.risk_engine = risk_engine
        self.config = config
        self.logger = logger

        # Состояние для Level Hunter специфичных рисков
        self._level_attempts: Dict[str, List[datetime]] = {}  # symbol -> list of attempt times
        self._failed_levels: Dict[str, int] = {}  # symbol -> failed level attempts
        self._consecutive_losses: int = 0
        self._last_profit_time: Optional[datetime] = None

        # Лимиты специфичные для Level Hunter
        self.max_level_attempts_per_hour = 5
        self.max_consecutive_losses = 3
        self.cooldown_after_loss_minutes = 30

    async def validate_level_hunter_signal(self, signal: Signal) -> Tuple[bool, str]:
        """
        Валидирует сигнал Level Hunter стратегии с учетом специфичных рисков

        Returns:
            Tuple[bool, str]: (is_valid, reason)
        """
        try:
            symbol = signal.symbol

            # 1. Проверка частоты попыток на уровне
            if not await self._check_level_attempt_frequency(symbol):
                return False, "Too many level attempts recently"

            # 2. Проверка последовательных убытков
            if not await self._check_consecutive_losses():
                return False, "Too many consecutive losses"

            # 3. Проверка cooldown периода после убытка
            if not await self._check_cooldown_period():
                return False, "In cooldown period after loss"

            # 4. Проверка типа сигнала и его параметров
            if not await self._check_signal_specific_risks(signal):
                return False, "Signal specific risk check failed"

            # 5. Проверка расстояния до уровня
            if not await self._check_level_distance(signal):
                return False, "Level distance risk too high"

            # 6. Проверка волатильности вокруг уровня
            if not await self._check_level_volatility(signal):
                return False, "High volatility around level"

            return True, "OK"

        except Exception as e:
            self.logger.error("Level hunter risk validation error", error=str(e))
            return False, f"Risk validation error: {e}"

    async def _check_level_attempt_frequency(self, symbol: str) -> bool:
        """Проверяет частоту попыток торговли на уровнях"""
        now = datetime.utcnow()
        hour_ago = now - timedelta(hours=1)

        # Получаем попытки за последний час
        attempts = self._level_attempts.get(symbol, [])
        recent_attempts = [attempt for attempt in attempts if attempt > hour_ago]

        if len(recent_attempts) >= self.max_level_attempts_per_hour:
            self.logger.warning(
                "Level attempt frequency limit reached",
                symbol=symbol,
                attempts=len(recent_attempts),
                limit=self.max_level_attempts_per_hour
            )
            return False

        # Обновляем историю попыток
        recent_attempts.append(now)
        self._level_attempts[symbol] = recent_attempts

        return True

    async def _check_consecutive_losses(self) -> bool:
        """Проверяет количество последовательных убытков"""
        if self._consecutive_losses >= self.max_consecutive_losses:
            self.logger.warning(
                "Max consecutive losses reached",
                consecutive_losses=self._consecutive_losses,
                limit=self.max_consecutive_losses
            )
            return False
        return True

    async def _check_cooldown_period(self) -> bool:
        """Проверяет cooldown период после убытка"""
        if self._consecutive_losses > 0 and self._last_profit_time:
            time_since_last_profit = datetime.utcnow() - self._last_profit_time
            cooldown_period = timedelta(minutes=self.cooldown_after_loss_minutes)

            if time_since_last_profit < cooldown_period:
                remaining = cooldown_period - time_since_last_profit
                self.logger.debug(
                    "In cooldown period after loss",
                    remaining_minutes=remaining.total_seconds() / 60
                )
                return False
        return True

    async def _check_signal_specific_risks(self, signal: Signal) -> bool:
        """Проверяет риски специфичные для типа сигнала"""

        if signal.signal_type == SignalType.LEVEL_BREAKOUT:
            # Для пробоев требуем высокую уверенность
            if signal.confidence < Decimal('0.8'):
                return False

        elif signal.signal_type == SignalType.LEVEL_BOUNCE:
            # Для отскоков проверяем силу уровня
            if signal.level_strength < Decimal('0.7'):
                return False

        elif signal.signal_type == SignalType.SUPPORT_HOLD:
            # Для удержания поддержки проверяем объем
            if not signal.volume_confirmation:
                return False

        # Проверяем соотношение риск/прибыль
        if signal.risk_reward_ratio and signal.risk_reward_ratio < Decimal('1.5'):
            self.logger.warning(
                "Risk/reward ratio too low",
                ratio=float(signal.risk_reward_ratio),
                minimum=1.5
            )
            return False

        return True

    async def _check_level_distance(self, signal: Signal) -> bool:
        """Проверяет расстояние до уровня и его качество"""
        # В реальной реализации здесь будет анализ исторических данных
        # о качестве данного уровня и расстоянии до него

        # Заглушка - всегда возвращаем True
        return True

    async def _check_level_volatility(self, signal: Signal) -> bool:
        """Проверяет волатильность вокруг уровня"""
        # В реальной реализации здесь будет анализ волатильности
        # вокруг уровня на основе ATR или других индикаторов

        # Заглушка - всегда возвращаем True
        return True

    async def on_trade_result(self, symbol: str, pnl: Decimal, is_profit: bool) -> None:
        """Обновляет состояние рисков на основе результата торговли"""
        try:
            if is_profit:
                # Сбрасываем счетчик убытков при прибыли
                self._consecutive_losses = 0
                self._last_profit_time = datetime.utcnow()

                # Очищаем счетчик неудачных попыток для символа
                if symbol in self._failed_levels:
                    del self._failed_levels[symbol]

            else:
                # Увеличиваем счетчик убытков
                self._consecutive_losses += 1

                # Увеличиваем счетчик неудачных попыток для уровня
                if symbol in self._failed_levels:
                    self._failed_levels[symbol] += 1
                else:
                    self._failed_levels[symbol] = 1

                self.logger.info(
                    "Trade loss recorded",
                    symbol=symbol,
                    pnl=float(pnl),
                    consecutive_losses=self._consecutive_losses
                )

        except Exception as e:
            self.logger.error("Error updating trade result", error=str(e))

    async def on_level_failure(self, symbol: str, level_price: Decimal) -> None:
        """Обрабатывает неудачную попытку на уровне"""
        try:
            level_key = f"{symbol}_{level_price}"

            # В реальной реализации здесь будет логика обработки
            # неудачных попыток на конкретных уровнях
            # Например, временное исключение уровня из торговли

            self.logger.info(
                "Level failure recorded",
                symbol=symbol,
                level_price=float(level_price)
            )

        except Exception as e:
            self.logger.error("Error recording level failure", error=str(e))

    async def get_level_hunter_risk_metrics(self) -> Dict[str, Any]:
        """Возвращает метрики рисков специфичные для Level Hunter"""
        return {
            "consecutive_losses": self._consecutive_losses,
            "level_attempts": {
                symbol: len(attempts)
                for symbol, attempts in self._level_attempts.items()
            },
            "failed_levels": self._failed_levels,
            "last_profit_time": self._last_profit_time.isoformat() if self._last_profit_time else None,
            "in_cooldown": self._consecutive_losses > 0 and await self._check_cooldown_period() is False
        }

    async def reset_cooldown(self) -> None:
        """Сбрасывает cooldown период (для manual override)"""
        self._consecutive_losses = 0
        self._last_profit_time = datetime.utcnow()
        self.logger.info("Level hunter cooldown reset")

    async def should_reduce_position_size(self) -> bool:
        """Определяет нужно ли уменьшать размер позиции"""
        return (self._consecutive_losses >= 2 or
                await self._check_cooldown_period() is False)

    async def get_position_size_multiplier(self) -> Decimal:
        """Возвращает множитель для размера позиции на основе рисков"""
        base_multiplier = Decimal('1.0')

        # Уменьшаем размер при последовательных убытках
        if self._consecutive_losses == 1:
            base_multiplier *= Decimal('0.8')
        elif self._consecutive_losses >= 2:
            base_multiplier *= Decimal('0.5')

        # Дополнительное уменьшение в cooldown периоде
        if not await self._check_cooldown_period():
            base_multiplier *= Decimal('0.7')

        return base_multiplier