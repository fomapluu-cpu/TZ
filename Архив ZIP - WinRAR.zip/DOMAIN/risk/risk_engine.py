"""
Production-ready Risk Management Engine для Level Hunter стратегии
Управление рисками, лимитами и защита от больших потерь
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import Dict, List, Optional, Tuple
import asyncio

from domain.models.order import Order, OrderSide
from domain.models.position import Position
from domain.models.signal import Signal
from utils.config_loader import LevelHunterRiskConfig


class RiskViolationError(Exception):
    """Исключение при нарушении risk limits"""
    pass


class RiskEngine:
    """
    Production-ready Risk Management Engine
    Контролирует все аспекты управления рисками для Level Hunter стратегии
    """

    def __init__(self, config: LevelHunterRiskConfig, logger):
        self.config = config
        self.logger = logger

        # Состояние рисков
        self._daily_pnl: Decimal = Decimal('0')
        self._max_drawdown: Decimal = Decimal('0')
        self._open_positions: Dict[str, Position] = {}
        self._today_orders: List[Order] = []

        # Временные метрики
        self._last_reset_time = datetime.utcnow()
        self._peak_balance: Decimal = Decimal('100000')  # Начальный баланс

    async def validate_signal(self, signal: Signal, portfolio_balance: Decimal) -> Tuple[bool, str]:
        """
        Валидирует торговый сигнал с точки зрения рисков

        Returns:
            Tuple[bool, str]: (is_valid, reason)
        """
        try:
            # 1. Проверка дневного лимита убытков
            if not await self._check_daily_loss_limit():
                return False, "Daily loss limit exceeded"

            # 2. Проверка максимальной просадки
            if not await self._check_max_drawdown(portfolio_balance):
                return False, "Max drawdown exceeded"

            # 3. Проверка размера позиции
            if not await self._check_position_size(signal, portfolio_balance):
                return False, "Position size too large"

            # 4. Проверка волатильности
            if not await self._check_volatility_conditions(signal):
                return False, "High volatility conditions"

            # 5. Проверка концентрации
            if not await self._check_portfolio_concentration(signal, portfolio_balance):
                return False, "Portfolio concentration too high"

            return True, "OK"

        except Exception as e:
            self.logger.error("Risk validation error", error=str(e), signal=signal.dict())
            return False, f"Risk validation error: {e}"

    async def validate_order(self, order: Order, portfolio_balance: Decimal) -> Tuple[bool, str]:
        """
        Валидирует ордер перед отправкой на биржу
        """
        try:
            # 1. Проверка лимита открытых ордеров
            if not await self._check_open_orders_limit():
                return False, "Too many open orders"

            # 2. Проверка размера ордера
            if not await self._check_order_size(order, portfolio_balance):
                return False, "Order size exceeds limits"

            # 3. Проверка ценовых уровней (для лимитных ордеров)
            if order.price and not await self._check_price_levels(order):
                return False, "Price level risk too high"

            # 4. Проверка экспирации ордеров
            if not await self._check_order_expiry():
                return False, "Too many expired orders"

            return True, "OK"

        except Exception as e:
            self.logger.error("Order risk validation error", error=str(e), order=order.dict())
            return False, f"Order risk error: {e}"

    async def update_pnl(self, pnl_change: Decimal, portfolio_balance: Decimal) -> None:
        """
        Обновляет PnL и проверяет лимиты
        """
        self._daily_pnl += pnl_change

        # Обновляем максимальную просадку
        if portfolio_balance < self._peak_balance:
            drawdown = (self._peak_balance - portfolio_balance) / self._peak_balance * Decimal('100')
            self._max_drawdown = max(self._max_drawdown, drawdown)
        else:
            self._peak_balance = portfolio_balance

        # Проверяем лимиты после обновления
        await self._check_limits_after_pnl_update()

    async def _check_daily_loss_limit(self) -> bool:
        """Проверка дневного лимита убытков"""
        if self._daily_pnl < Decimal('0'):  # Убыток
            loss_percentage = abs(self._daily_pnl) / self._peak_balance * Decimal('100')
            if loss_percentage >= self.config.daily_loss_limit:
                self.logger.warning(
                    "Daily loss limit reached",
                    loss_percentage=float(loss_percentage),
                    limit=float(self.config.daily_loss_limit)
                )
                return False
        return True

    async def _check_max_drawdown(self, portfolio_balance: Decimal) -> bool:
        """Проверка максимальной просадки"""
        if self._max_drawdown >= self.config.max_drawdown:
            self.logger.warning(
                "Max drawdown reached",
                drawdown=float(self._max_drawdown),
                limit=float(self.config.max_drawdown)
            )
            return False
        return True

    async def _check_position_size(self, signal: Signal, portfolio_balance: Decimal) -> bool:
        """Проверка размера позиции"""
        position_size = signal.suggested_position_size * portfolio_balance
        max_position_size = portfolio_balance * (self.config.max_position_per_trade / Decimal('100'))

        if position_size > max_position_size:
            self.logger.warning(
                "Position size exceeds limit",
                position_size=float(position_size),
                max_size=float(max_position_size)
            )
            return False
        return True

    async def _check_volatility_conditions(self, signal: Signal) -> bool:
        """
        Проверка условий волатильности
        В реальной реализации здесь будет анализ ATR, VIX и других индикаторов
        """
        # TODO: Реализовать проверку волатильности на основе market data
        return True

    async def _check_portfolio_concentration(self, signal: Signal, portfolio_balance: Decimal) -> bool:
        """Проверка концентрации портфеля"""
        # TODO: Реализовать проверку концентрации по символам и секторам
        return True

    async def _check_open_orders_limit(self) -> bool:
        """Проверка лимита открытых ордеров"""
        active_orders = [o for o in self._today_orders if o.is_active]
        if len(active_orders) >= self.config.max_open_orders:
            self.logger.warning(
                "Open orders limit reached",
                current_orders=len(active_orders),
                limit=self.config.max_open_orders
            )
            return False
        return True

    async def _check_order_size(self, order: Order, portfolio_balance: Decimal) -> bool:
        """Проверка размера ордера"""
        order_value = order.quantity * (order.price or Decimal('0'))
        max_order_value = portfolio_balance * (self.config.max_position_per_trade / Decimal('100'))

        if order_value > max_order_value:
            self.logger.warning(
                "Order size exceeds limit",
                order_value=float(order_value),
                max_value=float(max_order_value)
            )
            return False
        return True

    async def _check_price_levels(self, order: Order) -> bool:
        """Проверка ценовых уровней для risk management"""
        # TODO: Реализовать проверку расстояния до ключевых уровней
        return True

    async def _check_order_expiry(self) -> bool:
        """Проверка экспирации ордеров"""
        now = datetime.utcnow()
        expired_orders = [
            o for o in self._today_orders
            if o.expiry_time and o.expiry_time < now and o.is_active
        ]

        if len(expired_orders) > 5:  # Максимум 5 просроченных ордеров
            self.logger.warning("Too many expired orders", count=len(expired_orders))
            return False
        return True

    async def _check_limits_after_pnl_update(self) -> None:
        """Проверка лимитов после обновления PnL"""
        # Автоматически сбрасываем дневные метрики в 00:00
        now = datetime.utcnow()
        if now.date() > self._last_reset_time.date():
            self._daily_pnl = Decimal('0')
            self._last_reset_time = now
            self.logger.info("Daily risk metrics reset")

    async def get_risk_metrics(self) -> Dict[str, Any]:
        """Возвращает текущие метрики рисков"""
        return {
            "daily_pnl": float(self._daily_pnl),
            "max_drawdown": float(self._max_drawdown),
            "open_positions_count": len(self._open_positions),
            "open_orders_count": len([o for o in self._today_orders if o.is_active]),
            "peak_balance": float(self._peak_balance),
            "last_reset": self._last_reset_time.isoformat()
        }

    async def emergency_stop(self, reason: str) -> None:
        """
        Аварийная остановка торговли
        """
        self.logger.critical("EMERGENCY STOP ACTIVATED", reason=reason)

        # Здесь будет логика закрытия всех позиций и отмены ордеров
        # В реальной реализации это интегрируется с execution engine

        # Записываем в метрики
        self._daily_pnl = Decimal('-1000')  # Помечаем как остановлено

    async def calculate_position_size(
            self,
            signal: Signal,
            portfolio_balance: Decimal,
            symbol_volatility: Decimal
    ) -> Decimal:
        """
        Рассчитывает размер позиции на основе рисков
        """
        # Базовый размер на основе confidence
        base_size = portfolio_balance * signal.suggested_position_size

        # Корректировка на волатильность
        volatility_multiplier = Decimal('1.0')
        if symbol_volatility > Decimal('0.05'):  # Высокая волатильность
            volatility_multiplier = Decimal('0.5')
        elif symbol_volatility < Decimal('0.01'):  # Низкая волатильность
            volatility_multiplier = Decimal('1.5')

        adjusted_size = base_size * volatility_multiplier

        # Применяем лимиты
        max_size = portfolio_balance * (self.config.max_position_per_trade / Decimal('100'))
        final_size = min(adjusted_size, max_size)

        self.logger.info(
            "Position size calculated",
            base_size=float(base_size),
            adjusted_size=float(adjusted_size),
            final_size=float(final_size),
            volatility=float(symbol_volatility)
        )

        return final_size