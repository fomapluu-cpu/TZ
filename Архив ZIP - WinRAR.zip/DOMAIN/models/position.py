# position.py
"""
Модели позиций для отслеживания состояния торговли
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, validator


class PositionSide(str, Enum):
    """Сторона позиции"""
    LONG = "LONG"
    SHORT = "SHORT"


class PositionStatus(str, Enum):
    """Статус позиции"""
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    PENDING = "PENDING"


class Position(BaseModel):
    """
    Позиция в Level Hunter стратегии
    Формируется из исполненных ордеров
    """

    id: Optional[int] = Field(None, description="Внутренний ID")
    symbol: str = Field(..., description="Торговая пара")
    side: PositionSide = Field(..., description="Сторона позиции")
    status: PositionStatus = Field(default=PositionStatus.PENDING, description="Статус")

    # Размеры и цены
    quantity: Decimal = Field(..., gt=0, description="Количество")
    entry_price: Decimal = Field(..., gt=0, description="Средняя цена входа")
    current_price: Decimal = Field(..., gt=0, description="Текущая цена")

    # Стоп-лосс и тейк-профит
    stop_loss: Optional[Decimal] = Field(None, description="Цена стоп-лосса")
    take_profit: Optional[Decimal] = Field(None, description="Цена тейк-профита")

    # Временные метки
    opened_at: datetime = Field(default_factory=datetime.utcnow, description="Время открытия")
    closed_at: Optional[datetime] = Field(None, description="Время закрытия")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Время обновления")

    # PnL расчеты
    unrealized_pnl: Decimal = Field(default=Decimal('0'), description="Нереализованный PnL")
    realized_pnl: Decimal = Field(default=Decimal('0'), description="Реализованный PnL")
    total_pnl: Decimal = Field(default=Decimal('0'), description="Общий PnL")

    # Комиссии
    total_commission: Decimal = Field(default=Decimal('0'), description="Суммарная комиссия")

    # Связанные ордера
    entry_orders: List[str] = Field(default_factory=list, description="ID ордеров входа")
    exit_orders: List[str] = Field(default_factory=list, description="ID ордеров выхода")

    # Для Level Hunter стратегии
    source_signal: Optional[str] = Field(None, description="ID исходного сигнала")
    strategy: str = Field(..., description="Стратегия создания позиции")
    risk_score: Decimal = Field(default=Decimal('0'), ge=0, le=1, description="Оценка риска")

    # Метаданные
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Дополнительные данные")

    class Config:
        json_encoders = {
            Decimal: str,
            datetime: lambda v: v.isoformat()
        }
        validate_assignment = True

    @validator('quantity', 'entry_price', 'current_price', 'stop_loss', 'take_profit',
               'unrealized_pnl', 'realized_pnl', 'total_pnl', 'total_commission', 'risk_score', pre=True)
    def validate_decimal(cls, v):
        if v is None:
            return v
        if isinstance(v, (int, float)):
            return Decimal(str(v))
        if isinstance(v, str):
            return Decimal(v)
        return v

    @property
    def is_open(self) -> bool:
        """Проверяет, открыта ли позиция"""
        return self.status == PositionStatus.OPEN

    @property
    def is_closed(self) -> bool:
        """Проверяет, закрыта ли позиция"""
        return self.status == PositionStatus.CLOSED

    @property
    def market_value(self) -> Decimal:
        """Текущая рыночная стоимость позиции"""
        return self.quantity * self.current_price

    @property
    def entry_value(self) -> Decimal:
        """Стоимость позиции при входе"""
        return self.quantity * self.entry_price

    @property
    def pnl_percentage(self) -> Decimal:
        """PnL в процентах"""
        if self.entry_value == 0:
            return Decimal('0')
        return (self.total_pnl / self.entry_value) * Decimal('100')

    @property
    def distance_to_stop_loss(self) -> Optional[Decimal]:
        """Расстояние до стоп-лосса в процентах"""
        if not self.stop_loss:
            return None

        if self.side == PositionSide.LONG:
            distance = (self.current_price - self.stop_loss) / self.current_price * Decimal('100')
        else:  # SHORT
            distance = (self.stop_loss - self.current_price) / self.current_price * Decimal('100')

        return distance

    @property
    def distance_to_take_profit(self) -> Optional[Decimal]:
        """Расстояние до тейк-профита в процентах"""
        if not self.take_profit:
            return None

        if self.side == PositionSide.LONG:
            distance = (self.take_profit - self.current_price) / self.current_price * Decimal('100')
        else:  # SHORT
            distance = (self.current_price - self.take_profit) / self.current_price * Decimal('100')

        return distance

    def update_price(self, new_price: Decimal) -> None:
        """Обновляет текущую цену и пересчитывает PnL"""
        self.current_price = new_price
        self.updated_at = datetime.utcnow()

        if self.side == PositionSide.LONG:
            self.unrealized_pnl = (self.current_price - self.entry_price) * self.quantity
        else:  # SHORT
            self.unrealized_pnl = (self.entry_price - self.current_price) * self.quantity

        self.total_pnl = self.realized_pnl + self.unrealized_pnl

    def add_entry_order(self, order_id: str, quantity: Decimal, price: Decimal, commission: Decimal) -> None:
        """Добавляет ордер входа и обновляет среднюю цену"""
        self.entry_orders.append(order_id)

        # Пересчитываем среднюю цену входа
        total_quantity = self.quantity + quantity
        total_value = self.entry_price * self.quantity + price * quantity

        self.quantity = total_quantity
        self.entry_price = total_value / total_quantity if total_quantity > 0 else Decimal('0')
        self.total_commission += commission

        # Если это первый ордер, открываем позицию
        if self.status == PositionStatus.PENDING:
            self.status = PositionStatus.OPEN
            self.opened_at = datetime.utcnow()

    def add_exit_order(self, order_id: str, quantity: Decimal, price: Decimal, commission: Decimal) -> None:
        """Добавляет ордер выхода и обновляет PnL"""
        self.exit_orders.append(order_id)

        # Расчет реализованного PnL
        if self.side == PositionSide.LONG:
            pnl = (price - self.entry_price) * quantity
        else:  # SHORT
            pnl = (self.entry_price - price) * quantity

        self.realized_pnl += pnl
        self.total_commission += commission
        self.quantity -= quantity

        # Если позиция полностью закрыта
        if self.quantity <= Decimal('0'):
            self.status = PositionStatus.CLOSED
            self.closed_at = datetime.utcnow()
            self.quantity = Decimal('0')

    def should_close_by_stop_loss(self) -> bool:
        """Проверяет, нужно ли закрыть позицию по стоп-лоссу"""
        if not self.stop_loss or not self.is_open:
            return False

        if self.side == PositionSide.LONG:
            return self.current_price <= self.stop_loss
        else:  # SHORT
            return self.current_price >= self.stop_loss

    def should_close_by_take_profit(self) -> bool:
        """Проверяет, нужно ли закрыть позицию по тейк-профиту"""
        if not self.take_profit or not self.is_open:
            return False

        if self.side == PositionSide.LONG:
            return self.current_price >= self.take_profit
        else:  # SHORT
            return self.current_price <= self.take_profit