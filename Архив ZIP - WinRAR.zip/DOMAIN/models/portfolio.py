# portfolio.py
"""
Модель портфеля для управления активами и рисками
"""

from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional
from pydantic import BaseModel, Field, validator


class AssetBalance(BaseModel):
    """Баланс актива"""

    asset: str = Field(..., description="Актив")
    free: Decimal = Field(..., ge=0, description="Свободный баланс")
    locked: Decimal = Field(..., ge=0, description="Заблокированный баланс")
    total: Decimal = Field(..., ge=0, description="Общий баланс")

    @validator('free', 'locked', 'total', pre=True)
    def validate_decimal(cls, v):
        if v is None:
            return Decimal('0')
        if isinstance(v, (int, float)):
            return Decimal(str(v))
        if isinstance(v, str):
            return Decimal(v)
        return v

    @property
    def available(self) -> Decimal:
        """Доступный баланс для торговли"""
        return self.free


class Portfolio(BaseModel):
    """
    Портфель для управления активами и рисками в Level Hunter стратегии
    """

    # Балансы
    balances: Dict[str, AssetBalance] = Field(default_factory=dict, description="Балансы активов")

    # PnL метрики
    total_balance: Decimal = Field(default=Decimal('0'), description="Общий баланс")
    available_balance: Decimal = Field(default=Decimal('0'), description="Доступный баланс")
    locked_balance: Decimal = Field(default=Decimal('0'), description="Заблокированный баланс")

    # PnL история
    daily_pnl: Decimal = Field(default=Decimal('0'), description="Дневной PnL")
    weekly_pnl: Decimal = Field(default=Decimal('0'), description="Недельный PnL")
    monthly_pnl: Decimal = Field(default=Decimal('0'), description="Месячный PnL")
    total_pnl: Decimal = Field(default=Decimal('0'), description="Общий PnL")

    # Риск метрики
    max_drawdown: Decimal = Field(default=Decimal('0'), description="Максимальная просадка")
    sharpe_ratio: Optional[Decimal] = Field(None, description="Коэффициент Шарпа")
    volatility: Decimal = Field(default=Decimal('0'), description="Волатильность портфеля")

    # Статистика торговли
    total_trades: int = Field(default=0, description="Общее количество сделок")
    winning_trades: int = Field(default=0, description="Количество прибыльных сделок")
    losing_trades: int = Field(default=0, description="Количество убыточных сделок")
    win_rate: Decimal = Field(default=Decimal('0'), description="Процент прибыльных сделок")

    # Активные позиции
    active_positions: List[str] = Field(default_factory=list, description="ID активных позиций")
    open_orders: List[str] = Field(default_factory=list, description="ID открытых ордеров")

    # Временные метки
    last_updated: datetime = Field(default_factory=datetime.utcnow, description="Время последнего обновления")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Время создания")

    # Для Level Hunter стратегии
    risk_limit: Decimal = Field(default=Decimal('1000'), description="Дневной лимит риска")
    position_size_limit: Decimal = Field(default=Decimal('2'), description="Лимит размера позиции (%)")
    daily_loss_limit: Decimal = Field(default=Decimal('5'), description="Дневной лимит убытков (%)")

    class Config:
        json_encoders = {
            Decimal: str,
            datetime: lambda v: v.isoformat()
        }

    @validator('total_balance', 'available_balance', 'locked_balance', 'daily_pnl',
               'weekly_pnl', 'monthly_pnl', 'total_pnl', 'max_drawdown', 'volatility',
               'win_rate', 'risk_limit', 'position_size_limit', 'daily_loss_limit', pre=True)
    def validate_decimal(cls, v):
        if v is None:
            return Decimal('0')
        if isinstance(v, (int, float)):
            return Decimal(str(v))
        if isinstance(v, str):
            return Decimal(v)
        return v

    @property
    def total_equity(self) -> Decimal:
        """Общая equity (баланс + нереализованный PnL)"""
        return self.total_balance

    @property
    def used_margin(self) -> Decimal:
        """Использованная маржа"""
        return self.locked_balance

    @property
    def free_margin(self) -> Decimal:
        """Свободная маржа"""
        return self.available_balance

    @property
    def margin_level(self) -> Decimal:
        """Уровень маржи"""
        if self.used_margin == 0:
            return Decimal('0')
        return self.total_equity / self.used_margin

    @property
    def is_over_risk_limit(self) -> bool:
        """Превышен ли дневной лимит риска"""
        return self.daily_pnl < -self.risk_limit

    @property
    def is_over_daily_loss_limit(self) -> bool:
        """Превышен ли дневной лимит убытков"""
        if self.total_balance == 0:
            return False
        loss_percentage = (abs(self.daily_pnl) / self.total_balance) * Decimal('100')
        return loss_percentage > self.daily_loss_limit

    def update_balance(self, asset: str, free: Decimal, locked: Decimal) -> None:
        """Обновляет баланс актива"""
        total = free + locked
        self.balances[asset] = AssetBalance(
            asset=asset,
            free=free,
            locked=locked,
            total=total
        )

        self._recalculate_totals()
        self.last_updated = datetime.utcnow()

    def _recalculate_totals(self) -> None:
        """Пересчитывает общие балансы"""
        self.total_balance = Decimal('0')
        self.available_balance = Decimal('0')
        self.locked_balance = Decimal('0')

        for balance in self.balances.values():
            self.total_balance += balance.total
            self.available_balance += balance.free
            self.locked_balance += balance.locked

    def add_trade_result(self, pnl: Decimal, is_win: bool) -> None:
        """Добавляет результат сделки в статистику"""
        self.total_pnl += pnl
        self.daily_pnl += pnl

        self.total_trades += 1
        if is_win:
            self.winning_trades += 1
        else:
            self.losing_trades += 1

        if self.total_trades > 0:
            self.win_rate = Decimal(str(self.winning_trades / self.total_trades))

        self.last_updated = datetime.utcnow()

    def can_open_position(self, required_margin: Decimal) -> bool:
        """Проверяет, можно ли открыть новую позицию"""
        return (self.free_margin >= required_margin and
                not self.is_over_risk_limit and
                not self.is_over_daily_loss_limit)

    def get_position_size_limit(self, symbol: str) -> Decimal:
        """Возвращает максимальный размер позиции для символа"""
        return (self.total_balance * self.position_size_limit) / Decimal('100')

    def reset_daily_metrics(self) -> None:
        """Сбрасывает дневные метрики"""
        self.daily_pnl = Decimal('0')
        self.last_updated = datetime.utcnow()