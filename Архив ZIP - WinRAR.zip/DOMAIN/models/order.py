"""
Модели ордеров для Level Hunter стратегии
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, validator


class OrderSide(str, Enum):
    """Сторона ордера"""
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    """Тип ордера"""
    LIMIT = "LIMIT"
    MARKET = "MARKET"
    STOP_LOSS = "STOP_LOSS"
    STOP_LOSS_LIMIT = "STOP_LOSS_LIMIT"
    TAKE_PROFIT = "TAKE_PROFIT"
    TAKE_PROFIT_LIMIT = "TAKE_PROFIT_LIMIT"


class OrderStatus(str, Enum):
    """Статус ордера"""
    NEW = "NEW"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"
    PENDING_CANCEL = "PENDING_CANCEL"


class OrderExecution(BaseModel):
    """Исполнение части ордера"""
    price: Decimal = Field(..., gt=0, description="Цена исполнения")
    quantity: Decimal = Field(..., gt=0, description="Количество")
    commission: Decimal = Field(..., ge=0, description="Комиссия")
    commission_asset: str = Field(..., description="Актив комиссии")
    trade_id: int = Field(..., description="ID сделки")
    timestamp: datetime = Field(..., description="Время исполнения")


class Order(BaseModel):
    """
    Ордер для Level Hunter стратегии
    Основная сущность - мы выставляем ордера на уровнях, а не открываем позиции напрямую
    """

    # Идентификаторы
    id: Optional[int] = Field(None, description="Внутренний ID")
    order_id: str = Field(..., description="ID ордера на бирже")
    client_order_id: str = Field(..., description="Клиентский ID ордера")

    # Основные параметры
    symbol: str = Field(..., description="Торговая пара")
    side: OrderSide = Field(..., description="Сторона")
    order_type: OrderType = Field(..., description="Тип ордера")
    quantity: Decimal = Field(..., gt=0, description="Количество")
    price: Optional[Decimal] = Field(None, gt=0, description="Цена для лимитных ордеров")
    stop_price: Optional[Decimal] = Field(None, gt=0, description="Стоп цена")

    # Статус и исполнение
    status: OrderStatus = Field(default=OrderStatus.NEW, description="Текущий статус")
    filled_quantity: Decimal = Field(default=Decimal('0'), ge=0, description="Исполненное количество")
    fills: List[OrderExecution] = Field(default_factory=list, description="Исполнения")

    # Временные метки
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Время создания")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Время обновления")

    # Дополнительные параметры
    time_in_force: str = Field(default="GTC", description="Время действия")
    iceberg_qty: Optional[Decimal] = Field(None, ge=0, description="Айсберг количество")

    # Для Level Hunter стратегии
    level_price: Optional[Decimal] = Field(None, description="Цена уровня, на котором выставили ордер")
    level_type: Optional[str] = Field(None, description="Тип уровня (support/resistance/ema/etc)")
    strategy: str = Field(..., description="Стратегия, создавшая ордер")
    expiry_time: Optional[datetime] = Field(None, description="Время истечения ордера")

    # Метаданные
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Дополнительные данные")

    class Config:
        json_encoders = {
            Decimal: str,
            datetime: lambda v: v.isoformat()
        }
        validate_assignment = True

    @validator('quantity', 'price', 'stop_price', 'filled_quantity', 'iceberg_qty', pre=True)
    def validate_decimal(cls, v):
        """Валидирует и преобразует в Decimal"""
        if v is None:
            return v
        if isinstance(v, (int, float)):
            return Decimal(str(v))
        if isinstance(v, str):
            return Decimal(v)
        return v

    @validator('filled_quantity')
    def validate_filled_quantity(cls, v, values):
        """Проверяет, что исполненное количество не превышает общее"""
        if 'quantity' in values and v > values['quantity']:
            raise ValueError('Filled quantity cannot exceed total quantity')
        return v

    @property
    def is_active(self) -> bool:
        """Проверяет, активен ли ордер"""
        active_statuses = {OrderStatus.NEW, OrderStatus.PARTIALLY_FILLED, OrderStatus.PENDING_CANCEL}
        return self.status in active_statuses

    @property
    def is_filled(self) -> bool:
        """Проверяет, полностью ли исполнен ордер"""
        return self.status == OrderStatus.FILLED

    @property
    def remaining_quantity(self) -> Decimal:
        """Возвращает оставшееся количество для исполнения"""
        return self.quantity - self.filled_quantity

    @property
    def average_fill_price(self) -> Optional[Decimal]:
        """Рассчитывает среднюю цену исполнения"""
        if not self.fills:
            return None

        total_quantity = sum(fill.quantity for fill in self.fills)
        if total_quantity == 0:
            return None

        total_value = sum(fill.price * fill.quantity for fill in self.fills)
        return total_value / total_quantity

    @property
    def total_commission(self) -> Decimal:
        """Суммарная комиссия по всем исполнениям"""
        return sum(fill.commission for fill in self.fills)

    def update_from_execution(self, execution: OrderExecution) -> None:
        """Обновляет ордер на основе нового исполнения"""
        self.fills.append(execution)
        self.filled_quantity += execution.quantity
        self.updated_at = datetime.utcnow()

        if self.filled_quantity == self.quantity:
            self.status = OrderStatus.FILLED
        elif self.filled_quantity > 0:
            self.status = OrderStatus.PARTIALLY_FILLED

    def to_exchange_format(self) -> Dict[str, Any]:
        """Конвертирует ордер в формат для отправки на биржу"""
        base_params = {
            'symbol': self.symbol,
            'side': self.side.value,
            'type': self.order_type.value,
            'quantity': float(self.quantity),
            'newClientOrderId': self.client_order_id,
        }

        if self.price is not None:
            base_params['price'] = float(self.price)

        if self.stop_price is not None and self.order_type in [
            OrderType.STOP_LOSS, OrderType.STOP_LOSS_LIMIT,
            OrderType.TAKE_PROFIT, OrderType.TAKE_PROFIT_LIMIT
        ]:
            base_params['stopPrice'] = float(self.stop_price)

        if self.order_type in [OrderType.LIMIT, OrderType.STOP_LOSS_LIMIT, OrderType.TAKE_PROFIT_LIMIT]:
            base_params['timeInForce'] = self.time_in_force

        if self.iceberg_qty is not None:
            base_params['icebergQty'] = float(self.iceberg_qty)

        return base_params

    @classmethod
    def from_exchange_data(cls, data: Dict[str, Any], strategy: str = "level_hunter") -> 'Order':
        """Создает ордер из данных биржи"""
        return cls(
            order_id=str(data['orderId']),
            client_order_id=data.get('clientOrderId', ''),
            symbol=data['symbol'],
            side=OrderSide(data['side']),
            order_type=OrderType(data['type']),
            quantity=Decimal(str(data['origQty'])),
            price=Decimal(str(data['price'])) if data.get('price') else None,
            stop_price=Decimal(str(data['stopPrice'])) if data.get('stopPrice') else None,
            status=OrderStatus(data['status']),
            filled_quantity=Decimal(str(data['executedQty'])),
            time_in_force=data.get('timeInForce', 'GTC'),
            iceberg_qty=Decimal(str(data['icebergQty'])) if data.get('icebergQty') else None,
            strategy=strategy,
            created_at=datetime.utcfromtimestamp(data['time'] / 1000),
            updated_at=datetime.utcfromtimestamp(data['updateTime'] / 1000),
        )