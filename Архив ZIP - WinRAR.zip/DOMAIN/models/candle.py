# candle.py
"""
Модель свечи для технического анализа
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional
from pydantic import BaseModel, Field, validator


class Candle(BaseModel):
    """
    Свеча для технического анализа
    Используется для определения уровней и трендов в Level Hunter стратегии
    """

    symbol: str = Field(..., description="Торговая пара")
    interval: str = Field(..., description="Интервал (1m, 5m, 1h, etc)")

    # Временные метки
    open_time: datetime = Field(..., description="Время открытия свечи")
    close_time: datetime = Field(..., description="Время закрытия свечи")

    # Цены OHLC
    open: Decimal = Field(..., gt=0, description="Цена открытия")
    high: Decimal = Field(..., gt=0, description="Максимальная цена")
    low: Decimal = Field(..., gt=0, description="Минимальная цена")
    close: Decimal = Field(..., gt=0, description="Цена закрытия")

    # Объемы
    volume: Decimal = Field(..., ge=0, description="Объем базового актива")
    quote_volume: Decimal = Field(..., ge=0, description="Объем котируемого актива")

    # Дополнительные метрики
    number_of_trades: int = Field(default=0, ge=0, description="Количество сделок")
    taker_buy_volume: Decimal = Field(default=0, ge=0, description="Объем покупок тейкеров")
    taker_quote_volume: Decimal = Field(default=0, ge=0, description="Объем покупок тейкеров в котировке")

    # Вычисляемые поля
    is_bullish: bool = Field(default=False, description="Бычья свеча")
    is_bearish: bool = Field(default=False, description="Медвежья свеча")
    body_size: Decimal = Field(default=0, description="Размер тела свечи")
    upper_shadow: Decimal = Field(default=0, description="Верхняя тень")
    lower_shadow: Decimal = Field(default=0, description="Нижняя тень")

    class Config:
        json_encoders = {
            Decimal: str,
            datetime: lambda v: v.isoformat()
        }

    @validator('open', 'high', 'low', 'close', 'volume', 'quote_volume',
               'taker_buy_volume', 'taker_quote_volume', pre=True)
    def validate_decimal(cls, v):
        if v is None:
            return Decimal('0')
        if isinstance(v, (int, float)):
            return Decimal(str(v))
        if isinstance(v, str):
            return Decimal(v)
        return v

    def __init__(self, **data):
        super().__init__(**data)
        self._calculate_derived_fields()

    def _calculate_derived_fields(self) -> None:
        """Вычисляет производные поля свечи"""
        # Определяем тип свечи
        self.is_bullish = self.close > self.open
        self.is_bearish = self.close < self.open

        # Размер тела
        self.body_size = abs(self.close - self.open)

        # Тени
        if self.is_bullish:
            self.upper_shadow = self.high - self.close
            self.lower_shadow = self.open - self.low
        else:
            self.upper_shadow = self.high - self.open
            self.lower_shadow = self.close - self.low

    @property
    def typical_price(self) -> Decimal:
        """Типичная цена (high + low + close) / 3"""
        return (self.high + self.low + self.close) / Decimal('3')

    @property
    def body_percentage(self) -> Decimal:
        """Процент тела от общего диапазона"""
        if self.high == self.low:
            return Decimal('0')
        return (self.body_size / (self.high - self.low)) * Decimal('100')

    @property
    def has_long_upper_shadow(self) -> bool:
        """Имеет ли длинную верхнюю тень"""
        return self.upper_shadow > self.body_size * Decimal('2')

    @property
    def has_long_lower_shadow(self) -> bool:
        """Имеет ли длинную нижнюю тень"""
        return self.lower_shadow > self.body_size * Decimal('2')

    @property
    def is_doji(self) -> bool:
        """Является ли свеча дожи"""
        return self.body_percentage < Decimal('5')  # Тело меньше 5% от диапазона

    @property
    def is_hammer(self) -> bool:
        """Является ли свеча молотом"""
        return (self.has_long_lower_shadow and
                self.body_percentage < Decimal('30') and
                self.lower_shadow > self.body_size * Decimal('2'))

    @property
    def is_shooting_star(self) -> bool:
        """Является ли свеча падающей звездой"""
        return (self.has_long_upper_shadow and
                self.body_percentage < Decimal('30') and
                self.upper_shadow > self.body_size * Decimal('2'))

    def is_inside_bar(self, previous_candle: 'Candle') -> bool:
        """Является ли внутренней свечой относительно предыдущей"""
        return (self.high <= previous_candle.high and
                self.low >= previous_candle.low)

    def is_outside_bar(self, previous_candle: 'Candle') -> bool:
        """Является ли внешней свечой относительно предыдущей"""
        return (self.high > previous_candle.high and
                self.low < previous_candle.low)

    @classmethod
    def from_binance_data(cls, symbol: str, interval: str, data: list) -> 'Candle':
        """Создает свечу из данных Binance API"""
        return cls(
            symbol=symbol,
            interval=interval,
            open_time=datetime.utcfromtimestamp(data[0] / 1000),
            close_time=datetime.utcfromtimestamp(data[6] / 1000),
            open=Decimal(str(data[1])),
            high=Decimal(str(data[2])),
            low=Decimal(str(data[3])),
            close=Decimal(str(data[4])),
            volume=Decimal(str(data[5])),
            quote_volume=Decimal(str(data[7])),
            number_of_trades=data[8],
            taker_buy_volume=Decimal(str(data[9])),
            taker_quote_volume=Decimal(str(data[10])),
        )