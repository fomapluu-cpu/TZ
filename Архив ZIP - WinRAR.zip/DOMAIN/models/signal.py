# signal.py
"""
Модели сигналов для Level Hunter стратегии
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field


class SignalType(str, Enum):
    """Типы торговых сигналов"""
    LEVEL_BREAKOUT = "LEVEL_BREAKOUT"  # Пробой уровня
    LEVEL_BOUNCE = "LEVEL_BOUNCE"  # Отскок от уровня
    TREND_REVERSAL = "TREND_REVERSAL"  # Разворот тренда
    SUPPORT_HOLD = "SUPPORT_HOLD"  # Удержание поддержки
    RESISTANCE_HOLD = "RESISTANCE_HOLD"  # Удержание сопротивления
    EMA_CROSSOVER = "EMA_CROSSOVER"  # Пересечение EMA
    VOLATILITY_EXPANSION = "VOLATILITY_EXPANSION"  # Расширение волатильности


class SignalStrength(str, Enum):
    """Сила сигнала"""
    WEAK = "WEAK"
    MEDIUM = "MEDIUM"
    STRONG = "STRONG"
    VERY_STRONG = "VERY_STRONG"


class Signal(BaseModel):
    """
    Торговый сигнал для Level Hunter стратегии
    Генерируется на основе технического анализа и определяет точки входа
    """

    id: Optional[int] = Field(None, description="Внутренний ID")
    symbol: str = Field(..., description="Торговая пара")
    signal_type: SignalType = Field(..., description="Тип сигнала")
    strength: SignalStrength = Field(..., description="Сила сигнала")

    # Ценовые уровни
    price_level: Decimal = Field(..., description="Целевой ценовой уровень")
    current_price: Decimal = Field(..., description="Текущая цена")
    stop_loss: Optional[Decimal] = Field(None, description="Уровень стоп-лосса")
    take_profit: Optional[Decimal] = Field(None, description="Уровень тейк-профита")

    # Временные параметры
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Время генерации сигнала")
    expiry_time: Optional[datetime] = Field(None, description="Время истечения сигнала")

    # Дополнительная информация
    confidence: Decimal = Field(..., ge=0, le=1, description="Уверенность в сигнале (0-1)")
    volume_confirmation: bool = Field(default=False, description="Подтверждение объемом")
    indicators: Dict[str, Any] = Field(default_factory=dict, description="Показатели индикаторов")

    # Для Level Hunter стратегии
    level_type: str = Field(..., description="Тип уровня (support/resistance/ema/etc)")
    level_strength: Decimal = Field(..., ge=0, le=1, description="Сила уровня")
    trend_direction: str = Field(..., description="Направление тренда")

    # Метаданные
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Дополнительные данные")

    class Config:
        json_encoders = {
            Decimal: str,
            datetime: lambda v: v.isoformat()
        }

    @property
    def risk_reward_ratio(self) -> Optional[Decimal]:
        """Рассчитывает соотношение риск/прибыль"""
        if not self.stop_loss or not self.take_profit:
            return None

        risk = abs(self.price_level - self.stop_loss)
        reward = abs(self.take_profit - self.price_level)

        if risk == 0:
            return None

        return reward / risk

    @property
    def is_valid(self) -> bool:
        """Проверяет, действителен ли сигнал"""
        if self.expiry_time and datetime.utcnow() > self.expiry_time:
            return False
        return self.confidence >= Decimal('0.6')  # Минимальная уверенность 60%

    @property
    def suggested_position_size(self) -> Decimal:
        """Предлагаемый размер позиции на основе силы сигнала"""
        size_map = {
            SignalStrength.WEAK: Decimal('0.01'),
            SignalStrength.MEDIUM: Decimal('0.02'),
            SignalStrength.STRONG: Decimal('0.03'),
            SignalStrength.VERY_STRONG: Decimal('0.05'),
        }
        return size_map.get(self.strength, Decimal('0.01'))

    def to_order_suggestions(self) -> Dict[str, Any]:
        """Генерирует предложения по ордерам на основе сигнала"""
        suggestions = {
            'entry_price': float(self.price_level),
            'position_size': float(self.suggested_position_size),
            'confidence': float(self.confidence),
        }

        if self.stop_loss:
            suggestions['stop_loss'] = float(self.stop_loss)
        if self.take_profit:
            suggestions['take_profit'] = float(self.take_profit)
        if self.risk_reward_ratio:
            suggestions['risk_reward_ratio'] = float(self.risk_reward_ratio)

        return suggestions