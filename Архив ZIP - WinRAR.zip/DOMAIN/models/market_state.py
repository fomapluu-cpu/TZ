# market_state.py
"""
Модель состояния рынка для анализа контекста торговли
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field


class MarketTrend(str, Enum):
    """Тренд рынка"""
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    SIDEWAYS = "SIDEWAYS"
    VOLATILE = "VOLATILE"


class MarketState(BaseModel):
    """
    Состояние рынка для анализа контекста торговли
    Содержит ключевые уровни, тренды и индикаторы
    """

    symbol: str = Field(..., description="Торговая пара")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Время анализа")

    # Текущие цены
    current_price: Decimal = Field(..., description="Текущая цена")
    price_change_24h: Decimal = Field(..., description="Изменение цены за 24h")
    price_change_percent_24h: Decimal = Field(..., description="Изменение цены за 24h в %")

    # Тренды
    trend: MarketTrend = Field(..., description="Общий тренд")
    trend_strength: Decimal = Field(..., ge=0, le=1, description="Сила тренда")
    trend_duration: int = Field(..., description="Длительность тренда в свечах")

    # Ключевые уровни для Level Hunter стратегии
    support_levels: List[Decimal] = Field(default_factory=list, description="Уровни поддержки")
    resistance_levels: List[Decimal] = Field(default_factory=list, description="Уровни сопротивления")

    # Скользящие средние
    ema_20: Optional[Decimal] = Field(None, description="EMA 20")
    ema_50: Optional[Decimal] = Field(None, description="EMA 50")
    ema_200: Optional[Decimal] = Field(None, description="EMA 200")

    # Индикаторы
    rsi: Optional[Decimal] = Field(None, ge=0, le=100, description="RSI")
    macd: Optional[Decimal] = Field(None, description="MACD")
    macd_signal: Optional[Decimal] = Field(None, description="MACD Signal")
    macd_histogram: Optional[Decimal] = Field(None, description="MACD Histogram")

    # Волатильность
    atr: Optional[Decimal] = Field(None, description="Average True Range")
    volatility_24h: Decimal = Field(..., description="Волатильность за 24h")
    bollinger_upper: Optional[Decimal] = Field(None, description="Верхняя полоса Боллинджера")
    bollinger_lower: Optional[Decimal] = Field(None, description="Нижняя полоса Боллинджера")
    bollinger_middle: Optional[Decimal] = Field(None, description="Средняя полоса Боллинджера")

    # Объемы
    volume_24h: Decimal = Field(..., description="Объем за 24h")
    volume_change_24h: Decimal = Field(..., description="Изменение объема за 24h")

    # Стакан ордеров
    order_book_bid: Decimal = Field(..., description="Лучшая цена покупки")
    order_book_ask: Decimal = Field(..., description="Лучшая цена продажи")
    order_book_spread: Decimal = Field(..., description="Спред")
    order_book_imbalance: Decimal = Field(..., description="Дисбаланс стакана")

    # Для Level Hunter стратегии
    nearest_support: Optional[Decimal] = Field(None, description="Ближайшая поддержка")
    nearest_resistance: Optional[Decimal] = Field(None, description="Ближайшее сопротивление")
    support_strength: Decimal = Field(default=Decimal('0'), ge=0, le=1, description="Сила поддержки")
    resistance_strength: Decimal = Field(default=Decimal('0'), ge=0, le=1, description="Сила сопротивления")

    # Торговые условия
    is_overbought: bool = Field(default=False, description="Перекупленность")
    is_oversold: bool = Field(default=False, description="Перепроданность")
    is_volatility_high: bool = Field(default=False, description="Высокая волатильность")
    is_volatility_low: bool = Field(default=False, description="Низкая волатильность")

    # Рекомендации
    trading_signal: Optional[str] = Field(None, description="Торговый сигнал")
    risk_level: Decimal = Field(default=Decimal('0.5'), ge=0, le=1, description="Уровень риска")

    # Метаданные
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Дополнительные данные")

    class Config:
        json_encoders = {
            Decimal: str,
            datetime: lambda v: v.isoformat()
        }

    @property
    def distance_to_nearest_support(self) -> Optional[Decimal]:
        """Расстояние до ближайшей поддержки в %"""
        if not self.nearest_support:
            return None
        return ((self.current_price - self.nearest_support) / self.current_price) * Decimal('100')

    @property
    def distance_to_nearest_resistance(self) -> Optional[Decimal]:
        """Расстояние до ближайшего сопротивления в %"""
        if not self.nearest_resistance:
            return None
        return ((self.nearest_resistance - self.current_price) / self.current_price) * Decimal('100')

    @property
    def is_ema_bullish_alignment(self) -> bool:
        """Проверяет бычье выстраивание EMA"""
        if not all([self.ema_20, self.ema_50, self.ema_200]):
            return False
        return self.ema_20 > self.ema_50 > self.ema_200

    @property
    def is_ema_bearish_alignment(self) -> bool:
        """Проверяет медвежье выстраивание EMA"""
        if not all([self.ema_20, self.ema_50, self.ema_200]):
            return False
        return self.ema_20 < self.ema_50 < self.ema_200

    @property
    def price_vs_ema_20(self) -> Optional[Decimal]:
        """Цена относительно EMA 20 в %"""
        if not self.ema_20:
            return None
        return ((self.current_price - self.ema_20) / self.ema_20) * Decimal('100')

    @property
    def is_near_support(self) -> bool:
        """Находится ли цена рядом с поддержкой"""
        if not self.distance_to_nearest_support:
            return False
        return abs(self.distance_to_nearest_support) < Decimal('2')  # В пределах 2%

    @property
    def is_near_resistance(self) -> bool:
        """Находится ли цена рядом с сопротивлением"""
        if not self.distance_to_nearest_resistance:
            return False
        return abs(self.distance_to_nearest_resistance) < Decimal('2')  # В пределах 2%

    def get_trading_recommendation(self) -> Dict[str, Any]:
        """Генерирует торговые рекомендации на основе состояния рынка"""
        recommendation = {
            'symbol': self.symbol,
            'timestamp': self.timestamp,
            'trend': self.trend.value,
            'risk_level': float(self.risk_level),
            'actions': []
        }

        # Анализ условий для Level Hunter стратегии
        if self.is_near_support and self.trend == MarketTrend.BULLISH:
            recommendation['actions'].append({
                'action': 'BUY_AT_SUPPORT',
                'level': float(self.nearest_support),
                'confidence': float(self.support_strength)
            })

        if self.is_near_resistance and self.trend == MarketTrend.BEARISH:
            recommendation['actions'].append({
                'action': 'SELL_AT_RESISTANCE',
                'level': float(self.nearest_resistance),
                'confidence': float(self.resistance_strength)
            })

        if self.is_ema_bullish_alignment and self.price_vs_ema_20 and self.price_vs_ema_20 < Decimal('-1'):
            recommendation['actions'].append({
                'action': 'BUY_DIP',
                'level': float(self.ema_20),
                'confidence': 0.7
            })

        if self.is_overbought and self.is_near_resistance:
            recommendation['actions'].append({
                'action': 'CAUTION_SELL',
                'level': float(self.nearest_resistance),
                'confidence': 0.8
            })

        if self.is_oversold and self.is_near_support:
            recommendation['actions'].append({
                'action': 'CAUTION_BUY',
                'level': float(self.nearest_support),
                'confidence': 0.8
            })

        return recommendation