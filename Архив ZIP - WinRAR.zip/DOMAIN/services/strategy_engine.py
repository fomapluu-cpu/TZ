"""
Production-ready Strategy Engine для управления множественными стратегиями
Полная интеграция с Telegram для мониторинга
"""

from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Any, Tuple
import asyncio

from domain.strategies.base import BaseStrategy
from domain.strategies.level_hunter import LevelHunterStrategy
from domain.strategies.mean_reversion import MeanReversionStrategy
from domain.models.signal import Signal
from domain.models.candle import Candle
from api.telegram.bot import TelegramBot


class StrategyPerformance:
    """Трекер производительности стратегии"""

    def __init__(self, strategy_name: str):
        self.strategy_name = strategy_name
        self.signals_generated = 0
        self.signals_executed = 0
        self.profitable_trades = 0
        self.total_pnl = Decimal('0')
        self.start_time = datetime.utcnow()

    @property
    def success_rate(self) -> float:
        """Возвращает процент успешных сделок"""
        if self.signals_executed == 0:
            return 0.0
        return (self.profitable_trades / self.signals_executed) * 100

    @property
    def average_pnl(self) -> Decimal:
        """Возвращает средний PnL на сделку"""
        if self.signals_executed == 0:
            return Decimal('0')
        return self.total_pnl / self.signals_executed


class StrategyEngine:
    """
    Production-ready Strategy Engine
    Управляет множественными торговыми стратегиями с приоритизацией
    """

    def __init__(
            self,
            config: Any,
            telegram_bot: Optional[TelegramBot] = None,
            logger=None
    ):
        self.config = config
        self.telegram_bot = telegram_bot
        self.logger = logger

        # Зарегистрированные стратегии
        self._strategies: Dict[str, BaseStrategy] = {}
        self._strategy_performance: Dict[str, StrategyPerformance] = {}
        self._active_strategies: Dict[str, bool] = {}

        # Приоритеты стратегий
        self._strategy_priority = {
            "level_hunter": 100,
            "mean_reversion": 80
        }

    async def initialize(self) -> None:
        """Инициализирует все стратегии"""
        try:
            self.logger.info("Initializing Strategy Engine")

            # Инициализация Level Hunter стратегии
            level_hunter_config = self.config.level_hunter
            level_hunter_strategy = LevelHunterStrategy(level_hunter_config)
            await self.register_strategy("level_hunter", level_hunter_strategy)

            # Инициализация Mean Reversion стратегии
            mean_reversion_config = self.config.get('mean_reversion', {})
            mean_reversion_strategy = MeanReversionStrategy(mean_reversion_config)
            await self.register_strategy("mean_reversion", mean_reversion_strategy)

            self.logger.info(
                "Strategy Engine initialized",
                strategies_count=len(self._strategies)
            )

            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(
                    f"🤖 *Strategy Engine инициализирован*\n\n"
                    f"Загружено стратегий: {len(self._strategies)}\n"
                    f"• Level Hunter: {'🟢' if self._active_strategies.get('level_hunter') else '🔴'}\n"
                    f"• Mean Reversion: {'🟢' if self._active_strategies.get('mean_reversion') else '🔴'}"
                )

        except Exception as e:
            self.logger.error("Strategy Engine initialization failed", error=str(e))
            raise

    async def register_strategy(self, name: str, strategy: BaseStrategy) -> bool:
        """Регистрирует новую стратегию"""
        try:
            self._strategies[name] = strategy
            self._strategy_performance[name] = StrategyPerformance(name)
            self._active_strategies[name] = True

            self.logger.info("Strategy registered", strategy_name=name)
            return True

        except Exception as e:
            self.logger.error("Strategy registration failed", strategy_name=name, error=str(e))
            return False

    async def analyze_market(self, symbol: str, candles: List[Candle]) -> List[Signal]:
        """
        Анализирует рынок всеми активными стратегиями

        Args:
            symbol: Торговый символ
            candles: Список свечей

        Returns:
            List[Signal]: Объединенные сигналы от всех стратегий
        """
        try:
            all_signals = []

            for strategy_name, strategy in self._strategies.items():
                if not self._active_strategies.get(strategy_name, False):
                    continue

                try:
                    signals = await strategy.analyze_market(symbol, candles)

                    # Добавляем информацию о стратегии в сигналы
                    for signal in signals:
                        signal.metadata = signal.metadata or {}
                        signal.metadata['strategy'] = strategy_name
                        signal.metadata['strategy_priority'] = self._strategy_priority.get(strategy_name, 50)

                    all_signals.extend(signals)

                    # Обновляем статистику
                    self._strategy_performance[strategy_name].signals_generated += len(signals)

                    self.logger.debug(
                        "Strategy analysis completed",
                        strategy=strategy_name,
                        symbol=symbol,
                        signals=len(signals)
                    )

                except Exception as e:
                    self.logger.error(
                        "Strategy analysis failed",
                        strategy=strategy_name,
                        symbol=symbol,
                        error=str(e)
                    )

            # Сортируем сигналы по приоритету стратегии и уверенности
            all_signals.sort(
                key=lambda s: (
                    self._strategy_priority.get(s.metadata.get('strategy', ''), 50),
                    s.confidence
                ),
                reverse=True
            )

            return all_signals

        except Exception as e:
            self.logger.error("Market analysis failed", symbol=symbol, error=str(e))
            return []

    async def enable_strategy(self, strategy_name: str) -> bool:
        """Включает стратегию"""
        try:
            if strategy_name not in self._strategies:
                self.logger.warning("Strategy not found", strategy_name=strategy_name)
                return False

            self._active_strategies[strategy_name] = True

            self.logger.info("Strategy enabled", strategy_name=strategy_name)

            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(
                    f"🟢 *Стратегия включена:* {strategy_name}"
                )

            return True

        except Exception as e:
            self.logger.error("Failed to enable strategy", strategy_name=strategy_name, error=str(e))
            return False

    async def disable_strategy(self, strategy_name: str) -> bool:
        """Выключает стратегию"""
        try:
            if strategy_name not in self._strategies:
                self.logger.warning("Strategy not found", strategy_name=strategy_name)
                return False

            self._active_strategies[strategy_name] = False

            self.logger.info("Strategy disabled", strategy_name=strategy_name)

            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(
                    f"🔴 *Стратегия выключена:* {strategy_name}"
                )

            return True

        except Exception as e:
            self.logger.error("Failed to disable strategy", strategy_name=strategy_name, error=str(e))
            return False

    async def on_signal_executed(self, signal: Signal, pnl: Decimal) -> None:
        """Обновляет статистику при исполнении сигнала"""
        try:
            strategy_name = signal.metadata.get('strategy', 'unknown')

            if strategy_name in self._strategy_performance:
                performance = self._strategy_performance[strategy_name]
                performance.signals_executed += 1
                performance.total_pnl += pnl

                if pnl > 0:
                    performance.profitable_trades += 1

                self.logger.debug(
                    "Strategy performance updated",
                    strategy=strategy_name,
                    pnl=float(pnl),
                    success_rate=performance.success_rate
                )

        except Exception as e:
            self.logger.error("Failed to update strategy performance", error=str(e))

    async def get_strategy_performance(self) -> Dict[str, Any]:
        """Возвращает производительность всех стратегий"""
        performance = {}

        for name, perf in self._strategy_performance.items():
            performance[name] = {
                "active": self._active_strategies.get(name, False),
                "signals_generated": perf.signals_generated,
                "signals_executed": perf.signals_executed,
                "profitable_trades": perf.profitable_trades,
                "success_rate": perf.success_rate,
                "total_pnl": float(perf.total_pnl),
                "average_pnl": float(perf.average_pnl),
                "uptime_hours": (datetime.utcnow() - perf.start_time).total_seconds() / 3600
            }

        return performance

    async def get_telegram_status(self) -> str:
        """Возвращает статус для Telegram"""
        performance = await self.get_strategy_performance()

        status_text = "🤖 *STRATEGY ENGINE STATUS*\n\n"

        for strategy_name, stats in performance.items():
            status_text += (
                f"*{strategy_name.upper()}*: {'🟢' if stats['active'] else '🔴'}\n"
                f"• Сигналов: {stats['signals_generated']} gen / {stats['signals_executed']} exec\n"
                f"• Успешность: {stats['success_rate']:.1f}%\n"
                f"• PnL: ${stats['total_pnl']:.2f}\n"
                f"• Avg PnL: ${stats['average_pnl']:.2f}\n\n"
            )

        return status_text

    async def health_check(self) -> Dict[str, Any]:
        """Проверяет здоровье Strategy Engine"""
        try:
            active_strategies = sum(1 for active in self._active_strategies.values() if active)

            return {
                "status": "healthy",
                "total_strategies": len(self._strategies),
                "active_strategies": active_strategies,
                "performance_tracking": len(self._strategy_performance)
            }

        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }