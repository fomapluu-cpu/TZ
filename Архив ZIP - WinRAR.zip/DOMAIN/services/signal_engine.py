"""
Production-ready Signal Engine для Level Hunter стратегии
Генерация, валидация и управление торговыми сигналами
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import Dict, List, Optional, Set
import asyncio

from domain.models.candle import Candle
from domain.models.signal import Signal, SignalType, SignalStrength
from domain.strategies.level_hunter import LevelHunterStrategy
from domain.risk.risk_engine import RiskEngine
from utils.config_loader import LevelHunterConfig


class SignalGenerationError(Exception):
    """Ошибка генерации сигнала"""
    pass


class SignalEngine:
    """
    Production-ready Signal Engine
    Управляет генерацией, фильтрацией и валидацией торговых сигналов
    """

    def __init__(
            self,
            strategy: LevelHunterStrategy,
            risk_engine: RiskEngine,
            config: LevelHunterConfig,
            logger
    ):
        self.strategy = strategy
        self.risk_engine = risk_engine
        self.config = config
        self.logger = logger

        # Состояние движка
        self._active_signals: Dict[str, List[Signal]] = {}
        self._signal_history: List[Signal] = []
        self._symbol_data: Dict[str, List[Candle]] = {}
        self._last_processing_time: Dict[str, datetime] = {}

        # Статистика
        self._signals_generated = 0
        self._signals_executed = 0
        self._signals_rejected = 0

    async def process_market_data(self, symbol: str, candles: List[Candle]) -> List[Signal]:
        """
        Обрабатывает рыночные данные и генерирует сигналы

        Args:
            symbol: Торговый символ
            candles: Список свечей для анализа

        Returns:
            List[Signal]: Список валидных торговых сигналов
        """
        try:
            self.logger.debug(
                "Processing market data",
                symbol=symbol,
                candles_count=len(candles)
            )

            # Обновляем данные символа
            await self._update_symbol_data(symbol, candles)

            # Проверяем частоту обработки (избегаем избыточного анализа)
            if not await self._should_process(symbol):
                return []

            # Генерируем сигналы через стратегию
            strategy_signals = await self.strategy.analyze_market(symbol, candles)

            if not strategy_signals:
                return []

            # Фильтруем и валидируем сигналы
            validated_signals = []
            for signal in strategy_signals:
                validated_signal = await self._validate_and_enrich_signal(signal, symbol)
                if validated_signal:
                    validated_signals.append(validated_signal)

            # Обновляем статистику
            self._signals_generated += len(validated_signals)

            # Сохраняем активные сигналы
            if validated_signals:
                self._active_signals[symbol] = validated_signals
                self._signal_history.extend(validated_signals)

                self.logger.info(
                    "Signals generated",
                    symbol=symbol,
                    count=len(validated_signals),
                    types=[s.signal_type for s in validated_signals]
                )

            return validated_signals

        except Exception as e:
            self.logger.error(
                "Signal processing error",
                symbol=symbol,
                error=str(e)
            )
            raise SignalGenerationError(f"Failed to process market data: {e}") from e

    async def validate_signal_for_execution(self, signal: Signal, portfolio_balance: Decimal) -> bool:
        """
        Валидирует сигнал для исполнения

        Args:
            signal: Сигнал для валидации
            portfolio_balance: Текущий баланс портфеля

        Returns:
            bool: True если сигнал пригоден для исполнения
        """
        try:
            # 1. Проверка рисков
            risk_valid, risk_reason = await self.risk_engine.validate_signal(signal, portfolio_balance)
            if not risk_valid:
                self.logger.warning(
                    "Signal rejected by risk engine",
                    symbol=signal.symbol,
                    signal_type=signal.signal_type,
                    reason=risk_reason
                )
                self._signals_rejected += 1
                return False

            # 2. Проверка минимальной уверенности
            if signal.confidence < self.config.min_confidence:
                self.logger.debug(
                    "Signal confidence too low",
                    symbol=signal.symbol,
                    confidence=float(signal.confidence),
                    required=float(self.config.min_confidence)
                )
                return False

            # 3. Проверка силы уровня
            if signal.level_strength < self.config.min_level_strength:
                self.logger.debug(
                    "Signal level strength too low",
                    symbol=signal.symbol,
                    strength=float(signal.level_strength),
                    required=float(self.config.min_level_strength)
                )
                return False

            # 4. Проверка времени жизни сигнала
            if not signal.is_valid:
                self.logger.debug(
                    "Signal expired or invalid",
                    symbol=signal.symbol,
                    expiry_time=signal.expiry_time
                )
                return False

            # 5. Проверка дублирования сигналов
            if await self._is_duplicate_signal(signal):
                self.logger.debug(
                    "Duplicate signal detected",
                    symbol=signal.symbol,
                    signal_type=signal.signal_type,
                    price_level=float(signal.price_level)
                )
                return False

            self.logger.info(
                "Signal validated for execution",
                symbol=signal.symbol,
                signal_type=signal.signal_type,
                confidence=float(signal.confidence)
            )

            return True

        except Exception as e:
            self.logger.error(
                "Signal validation error",
                symbol=signal.symbol,
                error=str(e)
            )
            return False

    async def get_active_signals(self, symbol: Optional[str] = None) -> Dict[str, List[Signal]]:
        """
        Возвращает активные сигналы

        Args:
            symbol: Опциональный фильтр по символу

        Returns:
            Dict[str, List[Signal]]: Активные сигналы по символам
        """
        if symbol:
            return {symbol: self._active_signals.get(symbol, [])}

        # Фильтруем только валидные сигналы
        valid_signals = {}
        for sym, signals in self._active_signals.items():
            valid_signals[sym] = [s for s in signals if s.is_valid]

        return valid_signals

    async def cleanup_expired_signals(self) -> int:
        """
        Очищает истекшие сигналы

        Returns:
            int: Количество удаленных сигналов
        """
        removed_count = 0

        for symbol in list(self._active_signals.keys()):
            valid_signals = []
            for signal in self._active_signals[symbol]:
                if signal.is_valid:
                    valid_signals.append(signal)
                else:
                    removed_count += 1
                    self.logger.debug(
                        "Removed expired signal",
                        symbol=symbol,
                        signal_type=signal.signal_type,
                        expiry_time=signal.expiry_time
                    )

            self._active_signals[symbol] = valid_signals

        return removed_count

    async def get_signal_statistics(self) -> Dict[str, Any]:
        """
        Возвращает статистику по сигналам
        """
        total_signals = len(self._signal_history)
        active_signals = sum(len(signals) for signals in self._active_signals.values())

        # Статистика по типам сигналов
        signal_types = {}
        for signal in self._signal_history[-1000:]:  # Последние 1000 сигналов
            signal_type = signal.signal_type.value
            signal_types[signal_type] = signal_types.get(signal_type, 0) + 1

        # Эффективность сигналов (в реальной системе будет рассчитываться на основе исполнения)
        success_rate = Decimal('0')
        if total_signals > 0:
            success_rate = Decimal(str(self._signals_executed / total_signals * 100))

        return {
            "total_generated": self._signals_generated,
            "total_executed": self._signals_executed,
            "total_rejected": self._signals_rejected,
            "active_signals": active_signals,
            "success_rate": float(success_rate),
            "signal_types": signal_types,
            "last_processing": {
                symbol: time.isoformat()
                for symbol, time in self._last_processing_time.items()
            }
        }

    async def _update_symbol_data(self, symbol: str, candles: List[Candle]) -> None:
        """Обновляет данные символа с ограничением истории"""
        if symbol not in self._symbol_data:
            self._symbol_data[symbol] = []

        # Добавляем новые свечи
        self._symbol_data[symbol].extend(candles)

        # Ограничиваем историю (последние 1000 свечей)
        if len(self._symbol_data[symbol]) > 1000:
            self._symbol_data[symbol] = self._symbol_data[symbol][-1000:]

    async def _should_process(self, symbol: str) -> bool:
        """Проверяет, нужно ли обрабатывать данные символа"""
        now = datetime.utcnow()
        last_processed = self._last_processing_time.get(symbol)

        # Минимальный интервал между обработками - 1 минута
        if last_processed and (now - last_processed) < timedelta(minutes=1):
            return False

        self._last_processing_time[symbol] = now
        return True

    async def _validate_and_enrich_signal(self, signal: Signal, symbol: str) -> Optional[Signal]:
        """Валидирует и обогащает сигнал дополнительными данными"""
        try:
            # Проверяем базовую валидность
            if not signal.is_valid:
                return None

            # Обогащаем метаданные
            if not signal.metadata:
                signal.metadata = {}

            signal.metadata.update({
                'processed_at': datetime.utcnow().isoformat(),
                'signal_engine_version': '1.0.0',
                'strategy_type': 'level_hunter'
            })

            # Устанавливаем время экспирации если не установлено
            if not signal.expiry_time:
                signal.expiry_time = datetime.utcnow() + timedelta(hours=4)  # 4 часа по умолчанию

            return signal

        except Exception as e:
            self.logger.error(
                "Signal enrichment error",
                symbol=symbol,
                error=str(e)
            )
            return None

    async def _is_duplicate_signal(self, new_signal: Signal) -> bool:
        """Проверяет дублирование сигналов"""
        active_signals = self._active_signals.get(new_signal.symbol, [])

        for existing_signal in active_signals:
            # Считаем дубликатом если тот же тип и цена в пределах 0.5%
            if (existing_signal.signal_type == new_signal.signal_type and
                    abs(existing_signal.price_level - new_signal.price_level) / new_signal.price_level < Decimal(
                        '0.005')):
                return True

        return False

    async def on_signal_executed(self, signal: Signal) -> None:
        """
        Callback при успешном исполнении сигнала
        """
        self._signals_executed += 1

        # Удаляем сигнал из активных
        if signal.symbol in self._active_signals:
            self._active_signals[signal.symbol] = [
                s for s in self._active_signals[signal.symbol]
                if s != signal
            ]

        self.logger.info(
            "Signal executed successfully",
            symbol=signal.symbol,
            signal_type=signal.signal_type,
            price_level=float(signal.price_level)
        )

    async def on_signal_failed(self, signal: Signal, reason: str) -> None:
        """
        Callback при неудачном исполнении сигнала
        """
        self._signals_rejected += 1

        self.logger.warning(
            "Signal execution failed",
            symbol=signal.symbol,
            signal_type=signal.signal_type,
            reason=reason
        )