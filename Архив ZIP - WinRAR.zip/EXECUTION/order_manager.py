"""
Production-ready Order Manager для Level Hunter Bot
Управление жизненным циклом ордеров: создание, отслеживание, отмена
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import Dict, List, Optional, Set
import asyncio

from domain.models.order import Order, OrderSide, OrderType, OrderStatus
from infra.exchange.binance.client import BinanceClient
from utils.config_loader import Config


class OrderManagerError(Exception):
    """Базовое исключение Order Manager"""
    pass


class OrderNotFoundError(OrderManagerError):
    """Ордер не найден"""
    pass


class OrderManager:
    """
    Production-ready Order Manager
    Управляет полным жизненным циклом ордеров от создания до исполнения/отмены
    """

    def __init__(self, exchange_client: BinanceClient, config: Config, logger):
        self.exchange_client = exchange_client
        self.config = config
        self.logger = logger

        # Хранилище ордеров
        self._active_orders: Dict[str, Order] = {}  # order_id -> Order
        self._symbol_orders: Dict[str, Set[str]] = {}  # symbol -> set of order_ids
        self._order_history: List[Order] = []

        # Блокировки для конкурентного доступа
        self._order_locks: Dict[str, asyncio.Lock] = {}

        # Статистика
        self._orders_created = 0
        self._orders_filled = 0
        self._orders_cancelled = 0
        self._orders_failed = 0

    async def create_order(
            self,
            symbol: str,
            side: OrderSide,
            order_type: OrderType,
            quantity: Decimal,
            price: Optional[Decimal] = None,
            stop_price: Optional[Decimal] = None,
            client_order_id: Optional[str] = None,
            time_in_force: str = "GTC",
            **kwargs
    ) -> Order:
        """
        Создает новый ордер на бирже

        Args:
            symbol: Торговый символ
            side: Сторона ордера (BUY/SELL)
            order_type: Тип ордера
            quantity: Количество
            price: Цена (для лимитных ордеров)
            stop_price: Стоп цена (для стоп-ордеров)
            client_order_id: Клиентский ID ордера
            time_in_force: Время действия ордера

        Returns:
            Order: Созданный ордер

        Raises:
            OrderManagerError: При ошибке создания ордера
        """
        try:
            self.logger.info(
                "Creating order",
                symbol=symbol,
                side=side.value,
                order_type=order_type.value,
                quantity=float(quantity),
                price=float(price) if price else None
            )

            # Генерируем client_order_id если не предоставлен
            if not client_order_id:
                client_order_id = self._generate_client_order_id(symbol, side)

            # Создаем ордер на бирже
            exchange_response = await self.exchange_client.create_order(
                symbol=symbol,
                side=side,
                order_type=order_type,
                quantity=float(quantity),
                price=float(price) if price else None,
                stop_price=float(stop_price) if stop_price else None
            )

            # Создаем объект Order из ответа биржи
            order = Order.from_exchange_data(
                exchange_response,
                strategy="level_hunter"
            )

            # Добавляем дополнительные параметры
            order.client_order_id = client_order_id
            order.time_in_force = time_in_force

            if price:
                order.price = price
            if stop_price:
                order.stop_price = stop_price

            # Сохраняем ордер
            await self._store_order(order)

            self._orders_created += 1
            self.logger.info(
                "Order created successfully",
                symbol=symbol,
                order_id=order.order_id,
                client_order_id=client_order_id,
                status=order.status.value
            )

            return order

        except Exception as e:
            self._orders_failed += 1
            self.logger.error(
                "Order creation failed",
                symbol=symbol,
                side=side.value,
                order_type=order_type.value,
                error=str(e)
            )
            raise OrderManagerError(f"Failed to create order: {e}") from e

    async def cancel_order(self, symbol: str, order_id: str) -> bool:
        """
        Отменяет ордер на бирже

        Args:
            symbol: Торговый символ
            order_id: ID ордера

        Returns:
            bool: True если ордер успешно отменен
        """
        try:
            # Получаем лок для ордера
            order_lock = await self._get_order_lock(order_id)

            async with order_lock:
                # Проверяем существование ордера
                if order_id not in self._active_orders:
                    raise OrderNotFoundError(f"Order {order_id} not found")

                order = self._active_orders[order_id]

                # Проверяем можно ли отменить ордер
                if not order.is_active:
                    self.logger.warning(
                        "Cannot cancel inactive order",
                        order_id=order_id,
                        status=order.status.value
                    )
                    return False

                # Отменяем ордер на бирже
                await self.exchange_client.cancel_order(symbol, order_id)

                # Обновляем статус ордера
                order.status = OrderStatus.CANCELED
                order.updated_at = datetime.utcnow()

                self._orders_cancelled += 1
                self.logger.info(
                    "Order cancelled successfully",
                    symbol=symbol,
                    order_id=order_id
                )

                return True

        except OrderNotFoundError:
            raise
        except Exception as e:
            self.logger.error(
                "Order cancellation failed",
                symbol=symbol,
                order_id=order_id,
                error=str(e)
            )
            return False

    async def get_order(self, symbol: str, order_id: str) -> Optional[Order]:
        """
        Получает информацию об ордере

        Args:
            symbol: Торговый символ
            order_id: ID ордера

        Returns:
            Optional[Order]: Ордер или None если не найден
        """
        try:
            # Сначала проверяем локальное хранилище
            if order_id in self._active_orders:
                return self._active_orders[order_id]

            # Если нет в локальном хранилище, запрашиваем у биржи
            exchange_data = await self.exchange_client.get_order(symbol, order_id)
            order = Order.from_exchange_data(exchange_data, strategy="level_hunter")

            # Сохраняем ордер
            await self._store_order(order)

            return order

        except Exception as e:
            self.logger.error(
                "Failed to get order",
                symbol=symbol,
                order_id=order_id,
                error=str(e)
            )
            return None

    async def get_open_orders(self, symbol: str) -> List[Order]:
        """
        Получает список открытых ордеров для символа

        Args:
            symbol: Торговый символ

        Returns:
            List[Order]: Список открытых ордеров
        """
        try:
            # Получаем открытые ордера с биржи
            exchange_orders = await self.exchange_client.get_open_orders(symbol)

            open_orders = []
            for exchange_data in exchange_orders:
                order = Order.from_exchange_data(exchange_data, strategy="level_hunter")
                open_orders.append(order)

                # Обновляем локальное хранилище
                await self._store_order(order)

            return open_orders

        except Exception as e:
            self.logger.error(
                "Failed to get open orders",
                symbol=symbol,
                error=str(e)
            )
            return []

    async def sync_with_exchange(self) -> None:
        """
        Синхронизирует локальное состояние ордеров с биржей
        """
        try:
            self.logger.debug("Starting order sync with exchange")

            # Получаем все символы из конфигурации
            symbols = self.config.trading.symbols

            for symbol in symbols:
                try:
                    # Получаем открытые ордера с биржи
                    exchange_orders = await self.get_open_orders(symbol)

                    # Обновляем локальное состояние
                    await self._update_local_orders(symbol, exchange_orders)

                    self.logger.debug(
                        "Order sync completed for symbol",
                        symbol=symbol,
                        orders_count=len(exchange_orders)
                    )

                except Exception as e:
                    self.logger.error(
                        "Order sync failed for symbol",
                        symbol=symbol,
                        error=str(e)
                    )

            # Очищаем устаревшие ордера
            await self._cleanup_old_orders()

            self.logger.debug("Order sync completed")

        except Exception as e:
            self.logger.error("Order sync failed", error=str(e))

    async def update_order_status(self, order_id: str) -> Optional[Order]:
        """
        Обновляет статус ордера

        Args:
            order_id: ID ордера

        Returns:
            Optional[Order]: Обновленный ордер или None если не найден
        """
        try:
            if order_id not in self._active_orders:
                return None

            order = self._active_orders[order_id]

            # Получаем актуальную информацию с биржи
            exchange_data = await self.exchange_client.get_order(order.symbol, order_id)
            updated_order = Order.from_exchange_data(exchange_data, strategy="level_hunter")

            # Обновляем локальную копию
            self._active_orders[order_id] = updated_order

            # Обновляем статистику если ордер исполнился
            if (order.status != OrderStatus.FILLED and
                    updated_order.status == OrderStatus.FILLED):
                self._orders_filled += 1

            self.logger.debug(
                "Order status updated",
                order_id=order_id,
                old_status=order.status.value,
                new_status=updated_order.status.value
            )

            return updated_order

        except Exception as e:
            self.logger.error(
                "Failed to update order status",
                order_id=order_id,
                error=str(e)
            )
            return None

    async def cleanup_old_orders(self) -> int:
        """
        Очищает старые завершенные ордера из памяти

        Returns:
            int: Количество удаленных ордеров
        """
        removed_count = 0
        now = datetime.utcnow()

        # Ордера старше 24 часов и в завершенном состоянии
        completed_statuses = {
            OrderStatus.FILLED,
            OrderStatus.CANCELED,
            OrderStatus.REJECTED,
            OrderStatus.EXPIRED
        }

        orders_to_remove = []
        for order_id, order in self._active_orders.items():
            if (order.status in completed_statuses and
                    (now - order.updated_at) > timedelta(hours=24)):
                orders_to_remove.append(order_id)

        for order_id in orders_to_remove:
            await self._remove_order(order_id)
            removed_count += 1

        if removed_count > 0:
            self.logger.debug(
                "Old orders cleaned up",
                count=removed_count
            )

        return removed_count

    async def _store_order(self, order: Order) -> None:
        """Сохраняет ордер в локальном хранилище"""
        order_lock = await self._get_order_lock(order.order_id)

        async with order_lock:
            self._active_orders[order.order_id] = order

            # Добавляем в историю по символу
            if order.symbol not in self._symbol_orders:
                self._symbol_orders[order.symbol] = set()
            self._symbol_orders[order.symbol].add(order.order_id)

            # Добавляем в общую историю (ограничиваем размер)
            self._order_history.append(order)
            if len(self._order_history) > 10000:  # Максимум 10к ордеров в истории
                self._order_history = self._order_history[-10000:]

    async def _remove_order(self, order_id: str) -> None:
        """Удаляет ордер из локального хранилища"""
        if order_id not in self._active_orders:
            return

        order_lock = await self._get_order_lock(order_id)

        async with order_lock:
            order = self._active_orders[order_id]

            # Удаляем из хранилища по символу
            if order.symbol in self._symbol_orders:
                self._symbol_orders[order.symbol].discard(order_id)
                if not self._symbol_orders[order.symbol]:
                    del self._symbol_orders[order.symbol]

            # Удаляем из активных ордеров
            del self._active_orders[order_id]

            # Удаляем лок
            if order_id in self._order_locks:
                del self._order_locks[order_id]

    async def _update_local_orders(self, symbol: str, exchange_orders: List[Order]) -> None:
        """Обновляет локальное состояние ордеров на основе данных биржи"""
        # Создаем множество ордеров с биржи
        exchange_order_ids = {order.order_id for order in exchange_orders}

        # Получаем локальные ордера для символа
        local_order_ids = self._symbol_orders.get(symbol, set())

        # Ордера которые есть локально, но нет на бирже (скорее всего исполнены/отменены)
        missing_orders = local_order_ids - exchange_order_ids

        for order_id in missing_orders:
            if order_id in self._active_orders:
                order = self._active_orders[order_id]

                # Если ордер был активен, обновляем его статус
                if order.is_active:
                    await self.update_order_status(order_id)

    async def _get_order_lock(self, order_id: str) -> asyncio.Lock:
        """Возвращает лок для ордера (создает если нужно)"""
        if order_id not in self._order_locks:
            self._order_locks[order_id] = asyncio.Lock()
        return self._order_locks[order_id]

    def _generate_client_order_id(self, symbol: str, side: OrderSide) -> str:
        """Генерирует уникальный client_order_id"""
        timestamp = int(datetime.utcnow().timestamp() * 1000)
        return f"LH_{symbol}_{side.value}_{timestamp}"

    def get_order_statistics(self) -> Dict[str, Any]:
        """Возвращает статистику по ордерам"""
        active_orders = len([o for o in self._active_orders.values() if o.is_active])

        return {
            "total_created": self._orders_created,
            "total_filled": self._orders_filled,
            "total_cancelled": self._orders_cancelled,
            "total_failed": self._orders_failed,
            "active_orders": active_orders,
            "total_tracked": len(self._active_orders),
            "symbols_with_orders": list(self._symbol_orders.keys())
        }

    async def get_orders_by_symbol(self, symbol: str) -> List[Order]:
        """Возвращает все ордера для символа"""
        order_ids = self._symbol_orders.get(symbol, set())
        orders = []

        for order_id in order_ids:
            if order_id in self._active_orders:
                orders.append(self._active_orders[order_id])

        return orders

    async def cancel_all_orders(self, symbol: str) -> int:
        """
        Отменяет все активные ордера для символа

        Returns:
            int: Количество отмененных ордеров
        """
        try:
            open_orders = await self.get_open_orders(symbol)
            cancelled_count = 0

            for order in open_orders:
                if order.is_active:
                    success = await self.cancel_order(symbol, order.order_id)
                    if success:
                        cancelled_count += 1

            self.logger.info(
                "Cancelled all orders for symbol",
                symbol=symbol,
                count=cancelled_count
            )

            return cancelled_count

        except Exception as e:
            self.logger.error(
                "Failed to cancel all orders",
                symbol=symbol,
                error=str(e)
            )
            return 0