"""
Production-ready Trade Executor для Level Hunter Bot
Исполнение торговых сигналов через ордеры с управлением рисками
"""

from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Tuple
import asyncio

from domain.models.signal import Signal, SignalType
from domain.models.order import Order, OrderSide, OrderType
from domain.models.position import Position, PositionSide
from domain.services.signal_engine import SignalEngine
from domain.risk.risk_engine import RiskEngine
from execution.order_manager import OrderManager
from utils.config_loader import Config


class TradeExecutionError(Exception):
    """Ошибка исполнения торгового сигнала"""
    pass


class TradeExecutor:
    """
    Production-ready Trade Executor
    Преобразует торговые сигналы в ордера с полным управлением рисками
    """

    def __init__(
            self,
            signal_engine: SignalEngine,
            order_manager: OrderManager,
            risk_engine: RiskEngine,
            config: Config,
            logger
    ):
        self.signal_engine = signal_engine
        self.order_manager = order_manager
        self.risk_engine = risk_engine
        self.config = config
        self.logger = logger

        # Состояние исполнения
        self._active_positions: Dict[str, Position] = {}
        self._signal_to_order_map: Dict[str, List[str]] = {}  # signal_id -> order_ids
        self._execution_history: List[Dict] = []

        # Статистика
        self._signals_executed = 0
        self._signals_rejected = 0
        self._total_pnl = Decimal('0')

    async def execute_signal(self, signal: Signal, portfolio_balance: Decimal) -> bool:
        """
        Исполняет торговый сигнал

        Args:
            signal: Торговый сигнал для исполнения
            portfolio_balance: Текущий баланс портфеля

        Returns:
            bool: True если сигнал успешно исполнен
        """
        try:
            self.logger.info(
                "Executing trading signal",
                symbol=signal.symbol,
                signal_type=signal.signal_type.value,
                confidence=float(signal.confidence),
                price_level=float(signal.price_level)
            )

            # 1. Валидация сигнала для исполнения
            if not await self.signal_engine.validate_signal_for_execution(signal, portfolio_balance):
                self._signals_rejected += 1
                await self.signal_engine.on_signal_failed(signal, "Validation failed")
                return False

            # 2. Расчет размера позиции
            position_size = await self._calculate_position_size(signal, portfolio_balance)
            if position_size <= Decimal('0'):
                self._signals_rejected += 1
                await self.signal_engine.on_signal_failed(signal, "Invalid position size")
                return False

            # 3. Создание ордеров на основе типа сигнала
            orders = await self._create_orders_from_signal(signal, position_size)
            if not orders:
                self._signals_rejected += 1
                await self.signal_engine.on_signal_failed(signal, "Order creation failed")
                return False

            # 4. Сохранение mapping сигнал -> ордера
            await self._map_signal_to_orders(signal, orders)

            # 5. Обновление статистики и уведомление
            self._signals_executed += 1
            await self.signal_engine.on_signal_executed(signal)

            self.logger.info(
                "Signal executed successfully",
                symbol=signal.symbol,
                signal_type=signal.signal_type.value,
                orders_created=len(orders),
                position_size=float(position_size)
            )

            # 6. Запись в историю исполнения
            await self._record_execution(signal, orders, position_size)

            return True

        except Exception as e:
            self._signals_rejected += 1
            self.logger.error(
                "Signal execution failed",
                symbol=signal.symbol,
                signal_type=signal.signal_type.value,
                error=str(e)
            )
            await self.signal_engine.on_signal_failed(signal, f"Execution error: {e}")
            return False

    async def _calculate_position_size(self, signal: Signal, portfolio_balance: Decimal) -> Decimal:
        """Рассчитывает размер позиции для сигнала"""
        try:
            # Базовый расчет на основе confidence и силы сигнала
            base_size = signal.suggested_position_size * portfolio_balance

            # Корректировка на основе рисков
            volatility_factor = await self._get_volatility_factor(signal.symbol)
            adjusted_size = base_size * volatility_factor

            # Применение лимитов рисков
            max_position_size = portfolio_balance * (
                    self.config.level_hunter.risk.max_position_per_trade / Decimal('100')
            )
            final_size = min(adjusted_size, max_position_size)

            # Проверка минимального размера
            min_size = portfolio_balance * Decimal('0.01')  # 1% минимум
            if final_size < min_size:
                self.logger.warning(
                    "Position size below minimum",
                    symbol=signal.symbol,
                    calculated_size=float(final_size),
                    min_size=float(min_size)
                )
                return Decimal('0')

            self.logger.debug(
                "Position size calculated",
                symbol=signal.symbol,
                base_size=float(base_size),
                adjusted_size=float(adjusted_size),
                final_size=float(final_size),
                volatility_factor=float(volatility_factor)
            )

            return final_size

        except Exception as e:
            self.logger.error(
                "Position size calculation failed",
                symbol=signal.symbol,
                error=str(e)
            )
            return Decimal('0')

    async def _create_orders_from_signal(self, signal: Signal, position_size: Decimal) -> List[Order]:
        """Создает ордера на основе торгового сигнала"""
        orders = []

        try:
            # Определяем сторону ордера на основе типа сигнала
            order_side = self._get_order_side_from_signal(signal)

            # Определяем тип ордера (в Level Hunter используем лимитные ордера)
            order_type = OrderType.LIMIT

            # Рассчитываем количество (размер позиции / цена уровня)
            quantity = position_size / signal.price_level

            # Создаем основной ордер входа
            entry_order = await self.order_manager.create_order(
                symbol=signal.symbol,
                side=order_side,
                order_type=order_type,
                quantity=quantity,
                price=signal.price_level,
                client_order_id=f"ENTRY_{signal.symbol}_{int(datetime.utcnow().timestamp())}"
            )

            if entry_order:
                orders.append(entry_order)

                # Создаем стоп-лосс ордер если указан
                if signal.stop_loss:
                    stop_order = await self._create_stop_order(signal, order_side, quantity)
                    if stop_order:
                        orders.append(stop_order)

                # Создаем тейк-профит ордер если указан
                if signal.take_profit:
                    take_profit_order = await self._create_take_profit_order(signal, order_side, quantity)
                    if take_profit_order:
                        orders.append(take_profit_order)

            return orders

        except Exception as e:
            self.logger.error(
                "Order creation from signal failed",
                symbol=signal.symbol,
                error=str(e)
            )
            # Отменяем созданные ордера при ошибке
            for order in orders:
                await self.order_manager.cancel_order(order.symbol, order.order_id)
            return []

    async def _create_stop_order(self, signal: Signal, order_side: OrderSide, quantity: Decimal) -> Optional[Order]:
        """Создает стоп-лосс ордер"""
        try:
            # Для LONG позиции стоп-лосс - SELL, для SHORT - BUY
            stop_side = OrderSide.SELL if order_side == OrderSide.BUY else OrderSide.BUY

            stop_order = await self.order_manager.create_order(
                symbol=signal.symbol,
                side=stop_side,
                order_type=OrderType.STOP_LOSS_LIMIT,
                quantity=quantity,
                price=signal.stop_loss,  # Цена исполнения
                stop_price=signal.stop_loss,  # Стоп цена
                client_order_id=f"STOP_{signal.symbol}_{int(datetime.utcnow().timestamp())}"
            )

            return stop_order

        except Exception as e:
            self.logger.error(
                "Stop order creation failed",
                symbol=signal.symbol,
                error=str(e)
            )
            return None

    async def _create_take_profit_order(self, signal: Signal, order_side: OrderSide, quantity: Decimal) -> Optional[
        Order]:
        """Создает тейк-профит ордер"""
        try:
            # Для LONG позиции тейк-профит - SELL, для SHORT - BUY
            take_profit_side = OrderSide.SELL if order_side == OrderSide.BUY else OrderSide.BUY

            take_profit_order = await self.order_manager.create_order(
                symbol=signal.symbol,
                side=take_profit_side,
                order_type=OrderType.TAKE_PROFIT_LIMIT,
                quantity=quantity,
                price=signal.take_profit,  # Цена исполнения
                stop_price=signal.take_profit,  # Стоп цена для активации
                client_order_id=f"TP_{signal.symbol}_{int(datetime.utcnow().timestamp())}"
            )

            return take_profit_order

        except Exception as e:
            self.logger.error(
                "Take profit order creation failed",
                symbol=signal.symbol,
                error=str(e)
            )
            return None

    def _get_order_side_from_signal(self, signal: Signal) -> OrderSide:
        """Определяет сторону ордера на основе типа сигнала"""
        buy_signals = {
            SignalType.LEVEL_BOUNCE,
            SignalType.SUPPORT_HOLD,
            SignalType.EMA_CROSSOVER  # если бычий crossover
        }

        sell_signals = {
            SignalType.LEVEL_BREAKOUT,  # пробой сопротивления вниз
            SignalType.RESISTANCE_HOLD,
            SignalType.TREND_REVERSAL  # если медвежий разворот
        }

        if signal.signal_type in buy_signals:
            return OrderSide.BUY
        elif signal.signal_type in sell_signals:
            return OrderSide.SELL
        else:
            # По умолчанию для неопределенных сигналов
            return OrderSide.BUY

    async def _get_volatility_factor(self, symbol: str) -> Decimal:
        """Возвращает коэффициент коррекции на волатильность"""
        # В реальной реализации здесь будет расчет на основе ATR, исторической волатильности
        # Сейчас возвращаем консервативный коэффициент
        return Decimal('0.8')  # Уменьшаем размер на 20% для консервативности

    async def _map_signal_to_orders(self, signal: Signal, orders: List[Order]) -> None:
        """Сохраняет mapping между сигналом и созданными ордерами"""
        signal_id = str(signal.id) if signal.id else f"temp_{id(signal)}"

        if signal_id not in self._signal_to_order_map:
            self._signal_to_order_map[signal_id] = []

        self._signal_to_order_map[signal_id].extend([order.order_id for order in orders])

    async def _record_execution(self, signal: Signal, orders: List[Order], position_size: Decimal) -> None:
        """Записывает информацию об исполнении в историю"""
        execution_record = {
            'timestamp': datetime.utcnow(),
            'signal': {
                'symbol': signal.symbol,
                'type': signal.signal_type.value,
                'confidence': float(signal.confidence),
                'price_level': float(signal.price_level)
            },
            'orders': [order.order_id for order in orders],
            'position_size': float(position_size),
            'total_orders': len(orders)
        }

        self._execution_history.append(execution_record)

        # Ограничиваем размер истории
        if len(self._execution_history) > 1000:
            self._execution_history = self._execution_history[-1000:]

    async def update_positions(self) -> None:
        """Обновляет состояния позиций на основе исполненных ордеров"""
        try:
            # Получаем все активные ордера
            for symbol in self.config.trading.symbols:
                open_orders = await self.order_manager.get_open_orders(symbol)

                # Фильтруем исполненные ордера входа
                filled_entry_orders = [
                    order for order in open_orders
                    if order.is_filled and "ENTRY" in order.client_order_id
                ]

                for order in filled_entry_orders:
                    await self._update_position_from_filled_order(order)

        except Exception as e:
            self.logger.error("Position update failed", error=str(e))

    async def _update_position_from_filled_order(self, order: Order) -> None:
        """Обновляет позицию на основе исполненного ордера входа"""
        try:
            symbol = order.symbol
            position_side = PositionSide.LONG if order.side == OrderSide.BUY else PositionSide.SHORT

            # Создаем или обновляем позицию
            if symbol not in self._active_positions:
                self._active_positions[symbol] = Position(
                    symbol=symbol,
                    side=position_side,
                    quantity=order.filled_quantity,
                    entry_price=order.average_fill_price or order.price or Decimal('0'),
                    current_price=order.average_fill_price or order.price or Decimal('0'),
                    strategy="level_hunter"
                )
            else:
                # Обновляем существующую позицию
                position = self._active_positions[symbol]
                position.add_entry_order(
                    order_id=order.order_id,
                    quantity=order.filled_quantity,
                    price=order.average_fill_price or order.price or Decimal('0'),
                    commission=order.total_commission
                )

            self.logger.info(
                "Position updated from filled order",
                symbol=symbol,
                order_id=order.order_id,
                side=position_side.value,
                quantity=float(order.filled_quantity),
                entry_price=float(order.average_fill_price or order.price or Decimal('0'))
            )

        except Exception as e:
            self.logger.error(
                "Position update from order failed",
                order_id=order.order_id,
                error=str(e)
            )

    async def get_execution_statistics(self) -> Dict[str, Any]:
        """Возвращает статистику исполнения"""
        total_executions = self._signals_executed + self._signals_rejected
        success_rate = (
            (self._signals_executed / total_executions * 100)
            if total_executions > 0 else 0
        )

        return {
            "signals_executed": self._signals_executed,
            "signals_rejected": self._signals_rejected,
            "success_rate": float(success_rate),
            "active_positions": len(self._active_positions),
            "total_pnl": float(self._total_pnl),
            "recent_executions": len(self._execution_history)
        }

    async def get_active_positions(self) -> Dict[str, Position]:
        """Возвращает активные позиции"""
        return self._active_positions.copy()

    async def close_position(self, symbol: str, reason: str = "manual") -> bool:
        """Закрывает позицию по символу"""
        try:
            if symbol not in self._active_positions:
                self.logger.warning("No active position to close", symbol=symbol)
                return False

            position = self._active_positions[symbol]

            # Создаем ордер на закрытие
            close_side = OrderSide.SELL if position.side == PositionSide.LONG else OrderSide.BUY

            close_order = await self.order_manager.create_order(
                symbol=symbol,
                side=close_side,
                order_type=OrderType.MARKET,  # Используем маркет для гарантированного закрытия
                quantity=position.quantity,
                client_order_id=f"CLOSE_{symbol}_{int(datetime.utcnow().timestamp())}"
            )

            if close_order:
                self.logger.info(
                    "Position close order created",
                    symbol=symbol,
                    order_id=close_order.order_id,
                    reason=reason
                )
                return True
            else:
                self.logger.error("Failed to create position close order", symbol=symbol)
                return False

        except Exception as e:
            self.logger.error(
                "Position close failed",
                symbol=symbol,
                error=str(e)
            )
            return False

    async def emergency_close_all(self, reason: str = "emergency") -> Dict[str, bool]:
        """Экстренное закрытие всех позиций"""
        results = {}

        for symbol in list(self._active_positions.keys()):
            try:
                success = await self.close_position(symbol, reason)
                results[symbol] = success
            except Exception as e:
                self.logger.error(
                    "Emergency close failed for symbol",
                    symbol=symbol,
                    error=str(e)
                )
                results[symbol] = False

        self.logger.critical(
            "Emergency close all completed",
            reason=reason,
            results=results
        )

        return results