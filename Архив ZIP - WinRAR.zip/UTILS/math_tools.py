# math_tools.py
