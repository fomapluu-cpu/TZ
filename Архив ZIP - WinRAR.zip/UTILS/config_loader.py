"""
Production-ready конфигурация для Level Hunter стратегии
"""

import os
import secrets
from typing import Any, Dict, List, Optional
from pathlib import Path

import yaml
from pydantic import BaseSettings, Field, validator, root_validator
from pydantic.error_wrappers import ValidationError


class DatabaseConfig(BaseSettings):
    """Конфигурация PostgreSQL с валидацией"""
    host: str = Field(..., env="POSTGRES_HOST")
    port: int = Field(5432, env="POSTGRES_PORT")
    database: str = Field(..., env="POSTGRES_DB")
    username: str = Field(..., env="POSTGRES_USER")
    password: str = Field(..., env="POSTGRES_PASSWORD")
    pool_size: int = Field(20, ge=1, le=50)
    max_overflow: int = Field(30, ge=0, le=100)
    pool_timeout: int = Field(30, ge=1, le=60)

    @property
    def url(self) -> str:
        """Возвращает DSN для подключения"""
        return f"postgresql+asyncpg://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"

    @validator('password')
    def validate_password(cls, v):
        if not v or len(v) < 3:
            raise ValueError('Database password is too short')
        return v


class RedisConfig(BaseSettings):
    """Конфигурация Redis с валидацией"""
    host: str = Field("localhost", env="REDIS_HOST")
    port: int = Field(6379, ge=1, le=65535, env="REDIS_PORT")
    password: Optional[str] = Field(None, env="REDIS_PASSWORD")
    db: int = Field(0, ge=0, le=15)
    socket_timeout: int = Field(5, ge=1, le=30)

    @property
    def url(self) -> str:
        """Возвращает Redis URL"""
        if self.password:
            return f"redis://:{self.password}@{self.host}:{self.port}/{self.db}"
        return f"redis://{self.host}:{self.port}/{self.db}"


class BinanceConfig(BaseSettings):
    """Конфигурация Binance API"""
    api_key: str = Field(..., env="BINANCE_API_KEY")
    api_secret: str = Field(..., env="BINANCE_API_SECRET")
    testnet: bool = Field(True, env="BINANCE_TESTNET")
    rate_limit: int = Field(1200, ge=100, le=5000)
    request_timeout: int = Field(10, ge=5, le=30)
    recv_window: int = Field(5000, ge=1000, le=60000)

    @validator('api_key')
    def validate_api_key(cls, v):
        if not v or len(v) < 10:
            raise ValueError('Invalid API key format')
        return v

    @validator('api_secret')
    def validate_api_secret(cls, v):
        if not v or len(v) < 10:
            raise ValueError('Invalid API secret format')
        return v


class LevelHunterRiskConfig(BaseSettings):
    """Risk Management для Level Hunter стратегии"""
    max_position_per_trade: float = Field(2.0, ge=0.1, le=10.0)  # % от депозита
    daily_loss_limit: float = Field(5.0, ge=1.0, le=20.0)  # Дневной лимит убытков %
    max_drawdown: float = Field(10.0, ge=1.0, le=50.0)  # Максимальная просадка %
    max_open_orders: int = Field(10, ge=1, le=50)  # Макс открытых ордеров
    order_expiry_hours: int = Field(24, ge=1, le=168)  # Время жизни ордера


class LevelHunterConfig(BaseSettings):
    """Конфигурация специфичная для Level Hunter стратегии"""
    order_type: str = Field("LIMIT", regex="^(LIMIT|STOP_LOSS_LIMIT|TAKE_PROFIT_LIMIT)$")
    use_stop_orders: bool = True
    max_open_orders: int = Field(10, ge=1, le=50)
    order_expiry_hours: int = Field(24, ge=1, le=168)

    level_detection:
    support_resistance_period: int = Field(20, ge=5, le=100)
    ema_periods: List[int] = [20, 50, 200]
    volatility_lookback: int = Field(14, ge=5, le=50)


risk: LevelHunterRiskConfig = Field(default_factory=LevelHunterRiskConfig)


class TradingConfig(BaseSettings):
    """Общая конфигурация торговли"""
    enabled: bool = Field(False, env="TRADING_ENABLED")
    demo_mode: bool = Field(True, env="DEMO_MODE")
    initial_balance: float = Field(1000.0, ge=100.0, le=1000000.0)
    symbols: List[str] = ["BTCUSDT", "ETHUSDT"]

    @validator('symbols')
    def validate_symbols(cls, v):
        if not v:
            raise ValueError('At least one trading symbol must be specified')
        return [s.upper() for s in v]


class LoggingConfig(BaseSettings):
    """Конфигурация логирования"""
    level: str = Field("INFO", regex="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$")
    format: str = Field("json", regex="^(json|console)$")
    file: str = "logs/level_hunter.log"
    max_size_mb: int = Field(100, ge=10, le=1024)
    backup_count: int = Field(5, ge=1, le=20)


class MonitoringConfig(BaseSettings):
    """Конфигурация мониторинга"""
    prometheus_port: int = Field(8000, ge=1024, le=65535)
    health_check_port: int = Field(8080, ge=1024, le=65535)
    metrics_enabled: bool = True
    health_check_interval: int = Field(30, ge=5, le=300)


class AppConfig(BaseSettings):
    """Основная конфигурация приложения"""
    name: str = "Level Hunter Bot"
    version: str = "1.0.0"
    environment: str = Field("production", env="ENVIRONMENT")
    instance_id: str = Field("level_hunter_01", env="INSTANCE_ID")


class Config(BaseSettings):
    """Полная конфигурация Level Hunter Bot"""
    app: AppConfig
    database: DatabaseConfig
    redis: RedisConfig
    exchange: BinanceConfig
    level_hunter: LevelHunterConfig
    trading: TradingConfig
    logging: LoggingConfig
    monitoring: MonitoringConfig

    class Config:
        env_nested_delimiter = '__'


class ConfigLoader:
    """
    Production-ready загрузчик конфигурации для Level Hunter Bot
    Поддерживает YAML файлы, переменные окружения и валидацию
    """

    @classmethod
    def load(cls, config_path: Optional[str] = None) -> Config:
        """
        Загружает конфигурацию с приоритетом:
        1. Переменные окружения
        2. YAML конфиги (environment-specific)
        3. YAML конфиги (base)
        4. Значения по умолчанию

        Args:
            config_path: Путь к папке с конфигами

        Returns:
            Config: Валидированная конфигурация

        Raises:
            ValidationError: Если конфигурация невалидна
            FileNotFoundError: Если базовые конфиги отсутствуют
        """
        config_dir = Path(config_path) if config_path else Path("configs")

        if not config_dir.exists():
            raise FileNotFoundError(f"Config directory not found: {config_dir}")

        # Определяем окружение
        environment = os.getenv("ENVIRONMENT", "production")

        try:
            # Загружаем базовую конфигурацию
            base_config = cls._load_yaml_config(config_dir / "base.yaml")

            # Загружаем environment-specific конфигурацию
            env_config_path = config_dir / f"{environment}.yaml"
            env_config = {}
            if env_config_path.exists():
                env_config = cls._load_yaml_config(env_config_path)

            # Мерджим конфигурации
            merged_config = cls._deep_merge(base_config, env_config)

            # Создаем и валидируем конфиг
            return Config(**merged_config)

        except ValidationError as e:
            # Логируем ошибки валидации
            error_msg = f"Configuration validation failed: {e}"
            raise ValidationError(error_msg) from e
        except Exception as e:
            raise RuntimeError(f"Failed to load configuration: {e}") from e

    @staticmethod
    def _load_yaml_config(file_path: Path) -> Dict[str, Any]:
        """Загружает YAML файл с обработкой ошибок"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}

            # Заменяем переменные окружения в значениях
            return cls._replace_env_variables(config)

        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in {file_path}: {e}") from e
        except Exception as e:
            raise IOError(f"Failed to read config file {file_path}: {e}") from e

    @staticmethod
    def _replace_env_variables(config: Dict[str, Any]) -> Dict[str, Any]:
        """Рекурсивно заменяет ${VAR} на значения из окружения"""

        def replace_value(value):
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                env_var = value[2:-1]
                # Поддержка значений по умолчанию: ${VAR:default}
                if ":" in env_var:
                    var_name, default = env_var.split(":", 1)
                    return os.getenv(var_name, default)
                else:
                    return os.getenv(env_var, value)  # Если переменной нет, оставляем как есть
            return value

        def process_dict(d):
            return {k: process_value(v) for k, v in d.items()}

        def process_list(l):
            return [process_value(item) for item in l]

        def process_value(v):
            if isinstance(v, dict):
                return process_dict(v)
            elif isinstance(v, list):
                return process_list(v)
            else:
                return replace_value(v)

        return process_dict(config)

    @staticmethod
    def _deep_merge(base: Dict[str, Any], update: Dict[str, Any]) -> Dict[str, Any]:
        """Рекурсивно мерджит два словаря"""
        result = base.copy()

        for key, value in update.items():
            if (key in result and isinstance(result[key], dict)
                    and isinstance(value, dict)):
                result[key] = ConfigLoader._deep_merge(result[key], value)
            else:
                result[key] = value

        return result

    @classmethod
    def validate_config_for_environment(cls, environment: str) -> bool:
        """
        Валидирует конфигурацию для указанного окружения без загрузки приложения

        Args:
            environment: Окружение для валидации

        Returns:
            bool: True если конфигурация валидна
        """
        try:
            os.environ["ENVIRONMENT"] = environment
            cls.load()
            return True
        except Exception:
            return False