"""
Production-ready логирование для Level Hunter Bot
"""

import logging
import sys
import json
import gzip
import asyncio
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional
from logging.handlers import TimedRotatingFileHandler

import structlog
from structlog.types import EventDict, Processor


class JSONLogRenderer:
    """Кастомный рендерер для JSON логов"""

    def __init__(self, app_name: str, instance_id: str):
        self.app_name = app_name
        self.instance_id = instance_id

    def __call__(self, logger: logging.Logger, name: str, event_dict: EventDict) -> str:
        log_entry = {
            "timestamp": event_dict.pop("timestamp", datetime.utcnow().isoformat() + "Z"),
            "level": event_dict.pop("level", "INFO"),
            "logger": event_dict.pop("logger", name),
            "app": self.app_name,
            "instance": self.instance_id,
            "message": event_dict.pop("event", ""),
        }

        if event_dict:
            log_entry["context"] = event_dict

        return json.dumps(log_entry, ensure_ascii=False)


def setup_logging(config: Any) -> structlog.BoundLogger:
    """
    Настраивает production-ready логирование
    """
    log_config = config.logging
    app_config = config.app

    # Создаем папку для логов
    log_path = Path(log_config.file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Processors для structlog
    processors = [
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
    ]

    # Добавляем информацию о приложении
    def add_app_info(logger, method_name, event_dict):
        event_dict["app"] = app_config.name
        event_dict["instance"] = app_config.instance_id
        event_dict["environment"] = app_config.environment
        return event_dict

    processors.append(add_app_info)

    # Выбор рендерера
    if log_config.format == "json":
        processors.append(JSONLogRenderer(app_config.name, app_config.instance_id))
    else:
        processors.append(structlog.dev.ConsoleRenderer())

    # File handler с ротацией
    file_handler = TimedRotatingFileHandler(
        filename=log_config.file,
        when="midnight",
        interval=1,
        backupCount=log_config.backup_count,
        encoding="utf-8"
    )

    # Stdout handler
    stdout_handler = logging.StreamHandler(sys.stdout)

    # Базовая конфигурация logging
    logging.basicConfig(
        level=getattr(logging, log_config.level),
        handlers=[file_handler, stdout_handler],
        format="%(message)s"
    )

    # Конфигурация structlog
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    return structlog.get_logger()