"""
Prometheus метрики для мониторинга
"""

from prometheus_client import Counter, Gauge, Histogram, start_http_server


class TradingMetrics:
    """Метрики для мониторинга торговой активности"""

    def __init__(self):
        # Orders metrics
        self.orders_created = Counter(
            'level_hunter_orders_created_total',
            'Total orders created',
            ['symbol', 'side', 'type']
        )

        self.orders_filled = Counter(
            'level_hunter_orders_filled_total',
            'Total orders filled',
            ['symbol', 'side']
        )

        self.open_orders = Gauge(
            'level_hunter_open_orders',
            'Current open orders',
            ['symbol']
        )

        # Strategy metrics
        self.signals_generated = Counter(
            'level_hunter_signals_generated_total',
            'Total trading signals generated',
            ['symbol', 'signal_type']
        )

        self.levels_detected = Counter(
            'level_hunter_levels_detected_total',
            'Total price levels detected',
            ['symbol', 'level_type']
        )

        # Risk metrics
        self.risk_violations = Counter(
            'level_hunter_risk_violations_total',
            'Total risk rule violations',
            ['rule', 'symbol']
        )

    def record_order_created(self, symbol: str, side: str, order_type: str):
        self.orders_created.labels(symbol=symbol, side=side, type=order_type).inc()
        self.open_orders.labels(symbol=symbol).inc()

    def record_order_filled(self, symbol: str, side: str):
        self.orders_filled.labels(symbol=symbol, side=side).inc()
        self.open_orders.labels(symbol=symbol).dec()

    def record_signal(self, symbol: str, signal_type: str):
        self.signals_generated.labels(symbol=symbol, signal_type=signal_type).inc()

    def record_level_detected(self, symbol: str, level_type: str):
        self.levels_detected.labels(symbol=symbol, level_type=level_type).inc()


class MetricsServer:
    """Сервер для метрик Prometheus"""

    def __init__(self, port: int = 8000):
        self.port = port
        self.trading_metrics = TradingMetrics()
        self._started = False

    def start(self):
        if not self._started:
            start_http_server(self.port)
            self._started = True

    def get_metrics(self) -> TradingMetrics:
        return self.trading_metrics