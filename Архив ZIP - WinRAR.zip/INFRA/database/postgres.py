"""
Production-ready PostgreSQL клиент для Level Hunter Bot
Асинхронный, с connection pool, retry логикой и мониторингом
"""

import asyncio
import contextlib
from typing import Any, AsyncGenerator, Dict, List, Optional
from datetime import datetime, timedelta

import asyncpg
from asyncpg import Connection, Pool
from asyncpg.pool import PoolAcquireContext
import structlog

from utils.config_loader import DatabaseConfig


class DatabaseError(Exception):
    """Базовое исключение для ошибок базы данных"""
    pass


class ConnectionTimeoutError(DatabaseError):
    """Таймаут подключения к базе данных"""
    pass


class QueryExecutionError(DatabaseError):
    """Ошибка выполнения запроса"""
    pass


class PostgreSQLClient:
    """
    Production-ready клиент для PostgreSQL с:
    - Connection pooling
    - Retry механизмом
    - Health checks
    - Мониторингом метрик
    """

    def __init__(self, config: DatabaseConfig, logger: structlog.BoundLogger):
        self.config = config
        self.logger = logger
        self.pool: Optional[Pool] = None
        self._connection_stats = {
            "acquires": 0,
            "releases": 0,
            "errors": 0,
            "last_health_check": None
        }

    async def connect(self) -> None:
        """Устанавливает подключение к базе данных и создает connection pool"""
        try:
            self.logger.info(
                "Connecting to PostgreSQL",
                host=self.config.host,
                port=self.config.port,
                database=self.config.database
            )

            self.pool = await asyncpg.create_pool(
                dsn=self.config.url,
                min_size=1,
                max_size=self.config.pool_size,
                max_inactive_connection_lifetime=300.0,  # 5 minutes
                timeout=self.config.pool_timeout,
                command_timeout=60.0,
            )

            # Тестируем подключение
            async with self.pool.acquire() as conn:
                await self._test_connection(conn)

            self.logger.info("PostgreSQL connection established successfully")

        except asyncpg.PostgresError as e:
            self.logger.error("Failed to connect to PostgreSQL", error=str(e))
            raise DatabaseError(f"PostgreSQL connection failed: {e}") from e
        except Exception as e:
            self.logger.error("Unexpected error during PostgreSQL connection", error=str(e))
            raise DatabaseError(f"Unexpected connection error: {e}") from e

    async def disconnect(self) -> None:
        """Закрывает connection pool"""
        if self.pool:
            self.logger.info("Closing PostgreSQL connection pool")
            await self.pool.close()
            self.pool = None

    async def _test_connection(self, conn: Connection) -> None:
        """Тестирует подключение и проверяет необходимые таблицы"""
        # Проверяем версию PostgreSQL
        version = await conn.fetchval("SELECT version()")
        self.logger.debug("PostgreSQL version", version=version.split()[1])

        # Проверяем существование основных таблиц
        required_tables = ['orders', 'positions', 'candles', 'signals']
        for table in required_tables:
            exists = await conn.fetchval(
                "SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = $1)",
                table
            )
            if not exists:
                self.logger.warning(f"Required table '{table}' does not exist")

    @contextlib.asynccontextmanager
    async def acquire_connection(self) -> AsyncGenerator[Connection, None]:
        """
        Context manager для безопасного получения соединения из pool
        с retry логикой и мониторингом
        """
        if not self.pool:
            raise DatabaseError("Database connection pool is not initialized")

        max_retries = 3
        retry_delay = 1.0

        for attempt in range(max_retries):
            try:
                async with self.pool.acquire() as connection:
                    self._connection_stats["acquires"] += 1

                    # Устанавливаем timeout для операций
                    await connection.execute("SET statement_timeout = 30000")  # 30 seconds

                    yield connection

                    self._connection_stats["releases"] += 1
                    break

            except asyncpg.exceptions.TooManyConnectionsError:
                if attempt < max_retries - 1:
                    self.logger.warning(
                        "Too many connections, retrying...",
                        attempt=attempt + 1,
                        delay=retry_delay
                    )
                    await asyncio.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    self.logger.error("Max connection retries exceeded")
                    raise ConnectionTimeoutError("Cannot acquire database connection")
            except Exception as e:
                self._connection_stats["errors"] += 1
                self.logger.error("Error acquiring database connection", error=str(e))
                raise

    async def execute(self, query: str, *args) -> str:
        """
        Выполняет SQL команду (INSERT, UPDATE, DELETE)

        Returns:
            str: Status message
        """
        async with self.acquire_connection() as conn:
            try:
                result = await conn.execute(query, *args)
                return result
            except asyncpg.PostgresError as e:
                self.logger.error(
                    "Query execution failed",
                    query=query,
                    args=args,
                    error=str(e)
                )
                raise QueryExecutionError(f"Query failed: {e}") from e

    async def fetch(self, query: str, *args) -> List[asyncpg.Record]:
        """
        Выполняет SELECT запрос и возвращает все строки
        """
        async with self.acquire_connection() as conn:
            try:
                return await conn.fetch(query, *args)
            except asyncpg.PostgresError as e:
                self.logger.error(
                    "Fetch query failed",
                    query=query,
                    args=args,
                    error=str(e)
                )
                raise QueryExecutionError(f"Fetch failed: {e}") from e

    async def fetchrow(self, query: str, *args) -> Optional[asyncpg.Record]:
        """
        Выполняет SELECT запрос и возвращает одну строку
        """
        async with self.acquire_connection() as conn:
            try:
                return await conn.fetchrow(query, *args)
            except asyncpg.PostgresError as e:
                self.logger.error(
                    "Fetchrow query failed",
                    query=query,
                    args=args,
                    error=str(e)
                )
                raise QueryExecutionError(f"Fetchrow failed: {e}") from e

    async def fetchval(self, query: str, *args) -> Any:
        """
        Выполняет SELECT запрос и возвращает одно значение
        """
        async with self.acquire_connection() as conn:
            try:
                return await conn.fetchval(query, *args)
            except asyncpg.PostgresError as e:
                self.logger.error(
                    "Fetchval query failed",
                    query=query,
                    args=args,
                    error=str(e)
                )
                raise QueryExecutionError(f"Fetchval failed: {e}") from e

    async def health_check(self) -> Dict[str, Any]:
        """
        Проверяет здоровье базы данных и возвращает статистику
        """
        try:
            async with self.acquire_connection() as conn:
                # Проверяем базовые метрики
                start_time = datetime.now()

                # Активные подключения
                active_connections = await conn.fetchval(
                    "SELECT COUNT(*) FROM pg_stat_activity WHERE state = 'active'"
                )

                # Размер базы данных
                db_size = await conn.fetchval(
                    "SELECT pg_database_size($1)", self.config.database
                )

                # Время ответа
                ping_time = (datetime.now() - start_time).total_seconds() * 1000

                health_info = {
                    "status": "healthy",
                    "active_connections": active_connections,
                    "database_size_bytes": db_size,
                    "ping_time_ms": round(ping_time, 2),
                    "connection_stats": self._connection_stats.copy(),
                    "pool_size": self.pool.get_size() if self.pool else 0,
                    "pool_free": self.pool.get_free_size() if self.pool else 0,
                }

                self._connection_stats["last_health_check"] = datetime.now()
                return health_info

        except Exception as e:
            self.logger.error("Database health check failed", error=str(e))
            return {
                "status": "unhealthy",
                "error": str(e),
                "connection_stats": self._connection_stats
            }

    async def create_tables(self) -> None:
        """
        Создает необходимые таблицы для Level Hunter Bot
        """
        self.logger.info("Creating database tables...")

        tables_sql = [
            # Таблица ордеров
            """
            CREATE TABLE IF NOT EXISTS orders (
                id SERIAL PRIMARY KEY,
                order_id VARCHAR(100) UNIQUE NOT NULL,
                client_order_id VARCHAR(100),
                symbol VARCHAR(20) NOT NULL,
                side VARCHAR(10) NOT NULL,
                order_type VARCHAR(20) NOT NULL,
                quantity DECIMAL(20, 8) NOT NULL,
                price DECIMAL(20, 8),
                stop_price DECIMAL(20, 8),
                status VARCHAR(20) NOT NULL,
                time_in_force VARCHAR(10),
                created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                filled_quantity DECIMAL(20, 8) DEFAULT 0,
                fills JSONB,
                metadata JSONB
            )
            """,

            # Таблица свечей
            """
            CREATE TABLE IF NOT EXISTS candles (
                id SERIAL PRIMARY KEY,
                symbol VARCHAR(20) NOT NULL,
                interval VARCHAR(10) NOT NULL,
                open_time TIMESTAMP WITH TIME ZONE NOT NULL,
                open_price DECIMAL(20, 8) NOT NULL,
                high_price DECIMAL(20, 8) NOT NULL,
                low_price DECIMAL(20, 8) NOT NULL,
                close_price DECIMAL(20, 8) NOT NULL,
                volume DECIMAL(20, 8) NOT NULL,
                close_time TIMESTAMP WITH TIME ZONE NOT NULL,
                quote_asset_volume DECIMAL(20, 8),
                number_of_trades INTEGER,
                taker_buy_base_volume DECIMAL(20, 8),
                taker_buy_quote_volume DECIMAL(20, 8),
                UNIQUE(symbol, interval, open_time)
            )
            """,

            # Таблица сигналов
            """
            CREATE TABLE IF NOT EXISTS signals (
                id SERIAL PRIMARY KEY,
                symbol VARCHAR(20) NOT NULL,
                signal_type VARCHAR(50) NOT NULL,
                strength DECIMAL(5, 4) NOT NULL,
                price_level DECIMAL(20, 8),
                created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                metadata JSONB
            )
            """,

            # Индексы для производительности
            """
            CREATE INDEX IF NOT EXISTS idx_orders_symbol_status ON orders(symbol, status)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_candles_symbol_interval ON candles(symbol, interval, open_time)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_signals_symbol_created ON signals(symbol, created_at)
            """
        ]

        async with self.acquire_connection() as conn:
            for sql in tables_sql:
                try:
                    await conn.execute(sql)
                except asyncpg.PostgresError as e:
                    self.logger.error("Failed to create table", error=str(e), sql=sql[:100])
                    raise

        self.logger.info("Database tables created successfully")