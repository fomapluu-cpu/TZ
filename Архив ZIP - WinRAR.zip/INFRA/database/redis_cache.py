# redis_cache.py
"""
Production-ready Redis клиент для кеширования и pub/sub
"""

import asyncio
import json
import pickle
from typing import Any, Dict, List, Optional, Union
from datetime import timedelta
from contextlib import asynccontextmanager

import redis.asyncio as redis
from redis.asyncio import Redis, ConnectionPool
import structlog

from utils.config_loader import RedisConfig


class RedisError(Exception):
    """Базовое исключение для ошибок Redis"""
    pass


class RedisClient:
    """
    Production-ready Redis клиент с:
    - Connection pooling
    - Сериализацией данных
    - TTL управлением
    - Pub/Sub функциональностью
    - Health monitoring
    """

    def __init__(self, config: RedisConfig, logger: structlog.BoundLogger):
        self.config = config
        self.logger = logger
        self.redis_client: Optional[Redis] = None
        self.connection_pool: Optional[ConnectionPool] = None

    async def connect(self) -> None:
        """Устанавливает подключение к Redis"""
        try:
            self.logger.info(
                "Connecting to Redis",
                host=self.config.host,
                port=self.config.port,
                db=self.config.db
            )

            self.connection_pool = ConnectionPool.from_url(
                self.config.url,
                max_connections=20,
                socket_connect_timeout=5,
                socket_timeout=self.config.socket_timeout,
                retry_on_timeout=True,
                health_check_interval=30,
            )

            self.redis_client = Redis(connection_pool=self.connection_pool)

            # Тестируем подключение
            await self.redis_client.ping()

            self.logger.info("Redis connection established successfully")

        except Exception as e:
            self.logger.error("Failed to connect to Redis", error=str(e))
            raise RedisError(f"Redis connection failed: {e}") from e

    async def disconnect(self) -> None:
        """Закрывает подключение к Redis"""
        if self.redis_client:
            self.logger.info("Closing Redis connection")
            await self.redis_client.close()
            await self.connection_pool.disconnect()
            self.redis_client = None
            self.connection_pool = None

    def _serialize_value(self, value: Any) -> bytes:
        """Сериализует значение для хранения в Redis"""
        try:
            return pickle.dumps(value)
        except Exception as e:
            self.logger.error("Failed to serialize value", error=str(e))
            raise RedisError(f"Serialization failed: {e}") from e

    def _deserialize_value(self, value: bytes) -> Any:
        """Десериализует значение из Redis"""
        if value is None:
            return None
        try:
            return pickle.loads(value)
        except Exception as e:
            self.logger.error("Failed to deserialize value", error=str(e))
            raise RedisError(f"Deserialization failed: {e}") from e

    async def set(
            self,
            key: str,
            value: Any,
            expire_seconds: Optional[int] = None
    ) -> bool:
        """
        Устанавливает значение по ключу

        Args:
            key: Ключ
            value: Значение (будет сериализовано)
            expire_seconds: TTL в секундах

        Returns:
            bool: Успешность операции
        """
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            serialized_value = self._serialize_value(value)
            if expire_seconds:
                return await self.redis_client.setex(
                    key, expire_seconds, serialized_value
                )
            else:
                return await self.redis_client.set(key, serialized_value)

        except Exception as e:
            self.logger.error("Failed to set Redis key", key=key, error=str(e))
            raise RedisError(f"Set operation failed: {e}") from e

    async def get(self, key: str) -> Any:
        """
        Получает значение по ключу

        Returns:
            Any: Десериализованное значение или None если ключ не существует
        """
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            value = await self.redis_client.get(key)
            return self._deserialize_value(value) if value else None
        except Exception as e:
            self.logger.error("Failed to get Redis key", key=key, error=str(e))
            raise RedisError(f"Get operation failed: {e}") from e

    async def delete(self, key: str) -> bool:
        """Удаляет ключ"""
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            return await self.redis_client.delete(key) > 0
        except Exception as e:
            self.logger.error("Failed to delete Redis key", key=key, error=str(e))
            raise RedisError(f"Delete operation failed: {e}") from e

    async def exists(self, key: str) -> bool:
        """Проверяет существование ключа"""
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            return await self.redis_client.exists(key) > 0
        except Exception as e:
            self.logger.error("Failed to check key existence", key=key, error=str(e))
            raise RedisError(f"Exists operation failed: {e}") from e

    async def hset(self, key: str, field: str, value: Any) -> bool:
        """Устанавливает поле в hash"""
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            serialized_value = self._serialize_value(value)
            return await self.redis_client.hset(key, field, serialized_value)
        except Exception as e:
            self.logger.error("Failed to hset", key=key, field=field, error=str(e))
            raise RedisError(f"HSet operation failed: {e}") from e

    async def hget(self, key: str, field: str) -> Any:
        """Получает поле из hash"""
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            value = await self.redis_client.hget(key, field)
            return self._deserialize_value(value) if value else None
        except Exception as e:
            self.logger.error("Failed to hget", key=key, field=field, error=str(e))
            raise RedisError(f"HGet operation failed: {e}") from e

    async def hgetall(self, key: str) -> Dict[str, Any]:
        """Получает все поля из hash"""
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            data = await self.redis_client.hgetall(key)
            return {k.decode(): self._deserialize_value(v) for k, v in data.items()}
        except Exception as e:
            self.logger.error("Failed to hgetall", key=key, error=str(e))
            raise RedisError(f"HGetAll operation failed: {e}") from e

    async def publish(self, channel: str, message: Any) -> int:
        """
        Публикует сообщение в канал

        Returns:
            int: Количество подписчиков, получивших сообщение
        """
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            serialized_message = self._serialize_value(message)
            return await self.redis_client.publish(channel, serialized_message)
        except Exception as e:
            self.logger.error("Failed to publish", channel=channel, error=str(e))
            raise RedisError(f"Publish operation failed: {e}") from e

    async def subscribe(self, channel: str) -> Any:
        """
        Подписывается на канал и возвращает pubsub объект
        """
        if not self.redis_client:
            raise RedisError("Redis client not connected")

        try:
            pubsub = self.redis_client.pubsub()
            await pubsub.subscribe(channel)
            return pubsub
        except Exception as e:
            self.logger.error("Failed to subscribe", channel=channel, error=str(e))
            raise RedisError(f"Subscribe operation failed: {e}") from e

    async def get_message(self, pubsub, timeout: float = 1.0) -> Optional[Dict[str, Any]]:
        """
        Получает сообщение из pubsub

        Returns:
            Dict или None если timeout
        """
        try:
            message = await pubsub.get_message(
                ignore_subscribe_messages=True,
                timeout=timeout
            )
            if message and message['type'] == 'message':
                message['data'] = self._deserialize_value(message['data'])
            return message
        except Exception as e:
            self.logger.error("Failed to get message", error=str(e))
            return None

    async def health_check(self) -> Dict[str, Any]:
        """Проверяет здоровье Redis соединения"""
        if not self.redis_client:
            return {"status": "disconnected", "error": "Redis client not initialized"}

        try:
            start_time = asyncio.get_event_loop().time()

            # Проверяем ping
            await self.redis_client.ping()

            # Получаем информацию о сервере
            info = await self.redis_client.info()
            ping_time = (asyncio.get_event_loop().time() - start_time) * 1000

            health_info = {
                "status": "healthy",
                "ping_time_ms": round(ping_time, 2),
                "used_memory": info.get('used_memory', 0),
                "connected_clients": info.get('connected_clients', 0),
                "keyspace_hits": info.get('keyspace_hits', 0),
                "keyspace_misses": info.get('keyspace_misses', 0),
            }

            return health_info

        except Exception as e:
            self.logger.error("Redis health check failed", error=str(e))
            return {
                "status": "unhealthy",
                "error": str(e)
            }

    # Специфичные методы для Level Hunter Bot

    async def cache_candle_data(
            self,
            symbol: str,
            interval: str,
            candles: List[Dict[str, Any]],
            expire_minutes: int = 60
    ) -> None:
        """Кеширует данные свечей"""
        key = f"candles:{symbol}:{interval}"
        await self.set(key, candles, expire_seconds=expire_minutes * 60)

    async def get_cached_candles(
            self,
            symbol: str,
            interval: str
    ) -> Optional[List[Dict[str, Any]]]:
        """Получает кешированные данные свечей"""
        key = f"candles:{symbol}:{interval}"
        return await self.get(key)

    async def cache_order_book(
            self,
            symbol: str,
            orderbook: Dict[str, Any],
            expire_seconds: int = 5
    ) -> None:
        """Кеширует стакан ордеров (быстро обновляющиеся данные)"""
        key = f"orderbook:{symbol}"
        await self.set(key, orderbook, expire_seconds=expire_seconds)

    async def get_cached_order_book(
            self,
            symbol: str
    ) -> Optional[Dict[str, Any]]:
        """Получает кешированный стакан ордеров"""
        key = f"orderbook:{symbol}"
        return await self.get(key)

    async def store_active_orders(
            self,
            symbol: str,
            orders: List[Dict[str, Any]]
    ) -> None:
        """Сохраняет активные ордера для символа"""
        key = f"active_orders:{symbol}"
        await self.set(key, orders, expire_seconds=300)  # 5 minutes TTL

    async def get_active_orders(
            self,
            symbol: str
    ) -> Optional[List[Dict[str, Any]]]:
        """Получает активные ордера для символа"""
        key = f"active_orders:{symbol}"
        return await self.get(key)