"""
WebSocket клиент для Binance с обработкой рыночных данных в реальном времени
"""

import asyncio
import json
from typing import Any, Callable, Dict, Optional
import websockets

import structlog


class BinanceWebSocketClient:
    """
    WebSocket клиент для получения рыночных данных в реальном времени
    Поддерживает потоки свечей, стакана ордеров и исполнения ордеров
    """

    def __init__(self, config: Any, logger: structlog.BoundLogger):
        self.config = config
        self.logger = logger
        self.websocket_url = (
            "wss://testnet.binance.vision/ws"
            if config.exchange.binance.testnet
            else "wss://stream.binance.com:9443/ws"
        )
        self.websocket: Optional[websockets.WebSocketClientProtocol] = None
        self.is_connected = False
        self.subscriptions: Dict[str, Callable] = {}
        self._reconnect_delay = 1
        self._max_reconnect_delay = 60

    async def connect(self) -> None:
        """Устанавливает WebSocket соединение"""
        try:
            self.websocket = await websockets.connect(self.websocket_url)
            self.is_connected = True
            self._reconnect_delay = 1
            self.logger.info("WebSocket connected to Binance")
        except Exception as e:
            self.logger.error("Failed to connect WebSocket", error=str(e))
            raise

    async def disconnect(self) -> None:
        """Закрывает WebSocket соединение"""
        self.is_connected = False
        if self.websocket:
            await self.websocket.close()
            self.websocket = None
        self.logger.info("WebSocket disconnected")

    async def subscribe_kline(
            self,
            symbol: str,
            interval: str,
            callback: Callable[[Dict[str, Any]], None]
    ) -> None:
        """Подписывается на поток свечей"""
        stream_name = f"{symbol.lower()}@kline_{interval}"
        self.subscriptions[stream_name] = callback

        if self.is_connected and self.websocket:
            subscribe_msg = {
                "method": "SUBSCRIBE",
                "params": [stream_name],
                "id": 1
            }
            await self.websocket.send(json.dumps(subscribe_msg))
            self.logger.debug("Subscribed to kline stream", stream=stream_name)

    async def subscribe_depth(
            self,
            symbol: str,
            callback: Callable[[Dict[str, Any]], None]
    ) -> None:
        """Подписывается на поток стакана ордеров"""
        stream_name = f"{symbol.lower()}@depth@100ms"
        self.subscriptions[stream_name] = callback

        if self.is_connected and self.websocket:
            subscribe_msg = {
                "method": "SUBSCRIBE",
                "params": [stream_name],
                "id": 1
            }
            await self.websocket.send(json.dumps(subscribe_msg))
            self.logger.debug("Subscribed to depth stream", stream=stream_name)

    async def subscribe_user_data(
            self,
            listen_key: str,
            callback: Callable[[Dict[str, Any]], None]
    ) -> None:
        """Подписывается на поток пользовательских данных (ордера, балансы)"""
        stream_name = listen_key
        self.subscriptions[stream_name] = callback

        if self.is_connected and self.websocket:
            subscribe_msg = {
                "method": "SUBSCRIBE",
                "params": [stream_name],
                "id": 1
            }
            await self.websocket.send(json.dumps(subscribe_msg))
            self.logger.debug("Subscribed to user data stream")

    async def listen(self) -> None:
        """Запускает прослушивание WebSocket сообщений"""
        if not self.websocket:
            raise RuntimeError("WebSocket not connected")

        while self.is_connected:
            try:
                message = await self.websocket.recv()
                data = json.loads(message)

                # Обрабатываем сообщение
                await self._handle_message(data)

            except websockets.exceptions.ConnectionClosed:
                self.logger.warning("WebSocket connection closed, reconnecting...")
                await self._reconnect()
            except Exception as e:
                self.logger.error("Error in WebSocket listener", error=str(e))
                await asyncio.sleep(1)

    async def _handle_message(self, data: Dict[str, Any]) -> None:
        """Обрабатывает входящие WebSocket сообщения"""
        try:
            # Определяем тип потока по структуре сообщения
            if 'e' in data:  # Event type
                stream_name = self._get_stream_name(data)
                if stream_name in self.subscriptions:
                    await self.subscriptions[stream_name](data)
            elif 'result' in data or 'id' in data:
                # Ответ на подписку/отписку, игнорируем
                pass
            else:
                self.logger.warning("Unknown WebSocket message format", data=data)

        except Exception as e:
            self.logger.error("Error handling WebSocket message", error=str(e), data=data)

    def _get_stream_name(self, data: Dict[str, Any]) -> str:
        """Определяет имя потока из данных сообщения"""
        event_type = data.get('e', '')
        symbol = data.get('s', '').lower()

        if event_type == 'kline':
            interval = data.get('k', {}).get('i', '')
            return f"{symbol}@kline_{interval}"
        elif event_type == 'depthUpdate':
            return f"{symbol}@depth@100ms"
        elif event_type in ['executionReport', 'outboundAccountPosition']:
            # Для пользовательских данных используем listen key как идентификатор
            return next((k for k in self.subscriptions.keys() if '@' not in k), '')

        return ''

    async def _reconnect(self) -> None:
        """Выполняет переподключение с exponential backoff"""
        self.is_connected = False

        while True:
            try:
                self.logger.info(
                    "Attempting WebSocket reconnection",
                    delay=self._reconnect_delay
                )

                await asyncio.sleep(self._reconnect_delay)
                await self.connect()

                # Восстанавливаем подписки
                for stream_name in self.subscriptions:
                    subscribe_msg = {
                        "method": "SUBSCRIBE",
                        "params": [stream_name],
                        "id": 1
                    }
                    if self.websocket:
                        await self.websocket.send(json.dumps(subscribe_msg))

                self.logger.info("WebSocket reconnected successfully")
                break

            except Exception as e:
                self.logger.error(
                    "WebSocket reconnection failed",
                    error=str(e),
                    next_attempt=self._reconnect_delay * 2
                )
                self._reconnect_delay = min(
                    self._reconnect_delay * 2,
                    self._max_reconnect_delay
                )