"""
Production-ready клиент для Binance API
С поддержкой spot trading, rate limiting и обработкой ошибок
"""

import time
import hmac
import hashlib
import urllib.parse
from typing import Any, Dict, List, Optional

from infra.exchange.base import (
    BaseExchangeClient, OrderSide, OrderType, OrderStatus,
    ExchangeError, RateLimitError, InsufficientFundsError
)


class BinanceClient(BaseExchangeClient):
    """
    Клиент для Binance Spot API с полной поддержкой Level Hunter стратегии
    """

    def __init__(self, config: Any, logger: structlog.BoundLogger):
        super().__init__(config, logger)
        self.api_key = config.exchange.binance.api_key
        self.api_secret = config.exchange.binance.api_secret
        self.testnet = config.exchange.binance.testnet
        self.base_url = (
            "https://testnet.binance.vision/api/v3"
            if self.testnet
            else "https://api.binance.com/api/v3"
        )
        self.websocket_url = (
            "wss://testnet.binance.vision/ws"
            if self.testnet
            else "wss://stream.binance.com:9443/ws"
        )

    def _sign_request(self, params: Dict[str, Any]) -> str:
        """Подписывает запрос с использованием API secret"""
        query_string = urllib.parse.urlencode(params)
        signature = hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return signature

    def _get_headers(self) -> Dict[str, str]:
        """Возвращает заголовки для аутентифицированных запросов"""
        return {
            'X-MBX-APIKEY': self.api_key
        }

    async def get_account_info(self) -> Dict[str, Any]:
        """Получает информацию об аккаунте"""
        params = {
            'timestamp': int(time.time() * 1000),
            'recvWindow': self.config.exchange.binance.recv_window
        }

        params['signature'] = self._sign_request(params)

        return await self._make_request(
            'GET',
            f'{self.base_url}/account',
            headers=self._get_headers(),
            params=params,
            authenticated=True
        )

    async def create_order(
            self,
            symbol: str,
            side: OrderSide,
            order_type: OrderType,
            quantity: float,
            price: Optional[float] = None,
            stop_price: Optional[float] = None
    ) -> Dict[str, Any]:
        """Создает ордер на Binance"""
        params = {
            'symbol': symbol,
            'side': side.value,
            'type': order_type.value,
            'quantity': round(quantity, 6),  # Binance требует округления
            'timestamp': int(time.time() * 1000),
            'recvWindow': self.config.exchange.binance.recv_window
        }

        if price is not None:
            params['price'] = round(price, 2)  # Округляем цену

        if stop_price is not None and order_type in [OrderType.STOP_LOSS_LIMIT, OrderType.TAKE_PROFIT_LIMIT]:
            params['stopPrice'] = round(stop_price, 2)

        if order_type in [OrderType.LIMIT, OrderType.STOP_LOSS_LIMIT, OrderType.TAKE_PROFIT_LIMIT]:
            params['timeInForce'] = 'GTC'  # Good Till Cancel

        params['signature'] = self._sign_request(params)

        try:
            response = await self._make_request(
                'POST',
                f'{self.base_url}/order',
                headers=self._get_headers(),
                params=params,
                authenticated=True
            )

            self.logger.info(
                "Order created successfully",
                symbol=symbol,
                side=side.value,
                type=order_type.value,
                quantity=quantity,
                price=price,
                order_id=response['orderId']
            )

            return response

        except ExchangeError as e:
            error_msg = str(e)
            if 'Insufficient balance' in error_msg:
                raise InsufficientFundsError("Insufficient funds for order")
            raise

    async def cancel_order(self, symbol: str, order_id: str) -> Dict[str, Any]:
        """Отменяет ордер на Binance"""
        params = {
            'symbol': symbol,
            'orderId': order_id,
            'timestamp': int(time.time() * 1000),
            'recvWindow': self.config.exchange.binance.recv_window
        }

        params['signature'] = self._sign_request(params)

        response = await self._make_request(
            'DELETE',
            f'{self.base_url}/order',
            headers=self._get_headers(),
            params=params,
            authenticated=True
        )

        self.logger.info(
            "Order cancelled",
            symbol=symbol,
            order_id=order_id,
            status=response['status']
        )

        return response

    async def get_order(self, symbol: str, order_id: str) -> Dict[str, Any]:
        """Получает информацию об ордере"""
        params = {
            'symbol': symbol,
            'orderId': order_id,
            'timestamp': int(time.time() * 1000),
            'recvWindow': self.config.exchange.binance.recv_window
        }

        params['signature'] = self._sign_request(params)

        return await self._make_request(
            'GET',
            f'{self.base_url}/order',
            headers=self._get_headers(),
            params=params,
            authenticated=True
        )

    async def get_open_orders(self, symbol: str) -> List[Dict[str, Any]]:
        """Получает список открытых ордеров для символа"""
        params = {
            'symbol': symbol,
            'timestamp': int(time.time() * 1000),
            'recvWindow': self.config.exchange.binance.recv_window
        }

        params['signature'] = self._sign_request(params)

        return await self._make_request(
            'GET',
            f'{self.base_url}/openOrders',
            headers=self._get_headers(),
            params=params,
            authenticated=True
        )

    async def get_klines(
            self,
            symbol: str,
            interval: str,
            limit: int = 500
    ) -> List[Dict[str, Any]]:
        """Получает исторические данные свечей"""
        params = {
            'symbol': symbol,
            'interval': interval,
            'limit': limit
        }

        response = await self._make_request(
            'GET',
            f'{self.base_url}/klines',
            params=params
        )

        # Преобразуем ответ Binance в унифицированный формат
        candles = []
        for kline in response:
            candle = {
                'open_time': kline[0],
                'open': float(kline[1]),
                'high': float(kline[2]),
                'low': float(kline[3]),
                'close': float(kline[4]),
                'volume': float(kline[5]),
                'close_time': kline[6],
                'quote_asset_volume': float(kline[7]),
                'number_of_trades': kline[8],
                'taker_buy_base_volume': float(kline[9]),
                'taker_buy_quote_volume': float(kline[10]),
            }
            candles.append(candle)

        return candles

    async def get_exchange_info(self, symbol: str) -> Dict[str, Any]:
        """Получает информацию о символе (лимиты, шаги цены и количества)"""
        params = {'symbol': symbol}

        response = await self._make_request(
            'GET',
            f'{self.base_url}/exchangeInfo',
            params=params
        )

        symbol_info = next(
            (s for s in response['symbols'] if s['symbol'] == symbol),
            None
        )

        if not symbol_info:
            raise ExchangeError(f"Symbol {symbol} not found")

        return symbol_info

    async def get_order_book(self, symbol: str, limit: int = 100) -> Dict[str, Any]:
        """Получает стакан ордеров"""
        params = {
            'symbol': symbol,
            'limit': limit
        }

        return await self._make_request(
            'GET',
            f'{self.base_url}/depth',
            params=params
        )

    async def get_ticker_price(self, symbol: str) -> Dict[str, Any]:
        """Получает текущую цену символа"""
        params = {'symbol': symbol}

        return await self._make_request(
            'GET',
            f'{self.base_url}/ticker/price',
            params=params
        )

    def _calculate_quantity(self, symbol: str, amount: float, price: float) -> float:
        """
        Рассчитывает количество с учетом лимитов шага для Binance
        В реальной реализации нужно учитывать symbol filters
        """
        quantity = amount / price
        # Округляем до 6 знаков (стандарт для BTC)
        return round(quantity, 6)