"""
Базовый класс для биржевых клиентов с общей логикой
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from datetime import datetime
import asyncio
import aiohttp
from enum import Enum

import structlog


class OrderSide(Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(Enum):
    LIMIT = "LIMIT"
    MARKET = "MARKET"
    STOP_LOSS = "STOP_LOSS"
    STOP_LOSS_LIMIT = "STOP_LOSS_LIMIT"
    TAKE_PROFIT = "TAKE_PROFIT"
    TAKE_PROFIT_LIMIT = "TAKE_PROFIT_LIMIT"


class OrderStatus(Enum):
    NEW = "NEW"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class ExchangeError(Exception):
    """Базовое исключение для ошибок биржи"""
    pass


class RateLimitError(ExchangeError):
    """Превышен лимит запросов"""
    pass


class InsufficientFundsError(ExchangeError):
    """Недостаточно средств"""
    pass


class BaseExchangeClient(ABC):
    """
    Абстрактный базовый класс для всех биржевых клиентов
    Определяет общий интерфейс и реализует общую логику
    """

    def __init__(self, config: Any, logger: structlog.BoundLogger):
        self.config = config
        self.logger = logger
        self.session: Optional[aiohttp.ClientSession] = None
        self._rate_limiter = asyncio.Semaphore(10)  # Базовый rate limiting

    async def connect(self) -> None:
        """Устанавливает подключение к бирже"""
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self.config.exchange.request_timeout)
        )
        self.logger.info("Exchange client connected")

    async def disconnect(self) -> None:
        """Закрывает подключение к бирже"""
        if self.session:
            await self.session.close()
            self.session = None
        self.logger.info("Exchange client disconnected")

    @abstractmethod
    async def get_account_info(self) -> Dict[str, Any]:
        """Получает информацию об аккаунте"""
        pass

    @abstractmethod
    async def create_order(
            self,
            symbol: str,
            side: OrderSide,
            order_type: OrderType,
            quantity: float,
            price: Optional[float] = None,
            stop_price: Optional[float] = None
    ) -> Dict[str, Any]:
        """Создает ордер"""
        pass

    @abstractmethod
    async def cancel_order(self, symbol: str, order_id: str) -> Dict[str, Any]:
        """Отменяет ордер"""
        pass

    @abstractmethod
    async def get_order(self, symbol: str, order_id: str) -> Dict[str, Any]:
        """Получает информацию об ордере"""
        pass

    @abstractmethod
    async def get_open_orders(self, symbol: str) -> List[Dict[str, Any]]:
        """Получает список открытых ордеров"""
        pass

    @abstractmethod
    async def get_klines(
            self,
            symbol: str,
            interval: str,
            limit: int = 500
    ) -> List[Dict[str, Any]]:
        """Получает исторические данные свечей"""
        pass

    async def _make_request(
            self,
            method: str,
            url: str,
            headers: Optional[Dict[str, str]] = None,
            data: Optional[Dict[str, Any]] = None,
            params: Optional[Dict[str, Any]] = None,
            authenticated: bool = False
    ) -> Dict[str, Any]:
        """
        Базовый метод для выполнения HTTP запросов с обработкой ошибок и rate limiting
        """
        if not self.session:
            raise ExchangeError("Exchange client not connected")

        async with self._rate_limiter:
            try:
                async with self.session.request(
                        method=method,
                        url=url,
                        headers=headers,
                        json=data,
                        params=params
                ) as response:

                    if response.status == 429:
                        raise RateLimitError("Rate limit exceeded")

                    if response.status >= 400:
                        error_text = await response.text()
                        self.logger.error(
                            "Exchange API error",
                            status=response.status,
                            url=url,
                            error=error_text
                        )
                        raise ExchangeError(f"API error {response.status}: {error_text}")

                    return await response.json()

            except aiohttp.ClientError as e:
                self.logger.error("Network error during exchange request", error=str(e))
                raise ExchangeError(f"Network error: {e}") from e
            except asyncio.TimeoutError:
                self.logger.error("Request timeout to exchange")
                raise ExchangeError("Request timeout")

    def _calculate_quantity(self, symbol: str, amount: float, price: float) -> float:
        """
        Рассчитывает количество для ордера на основе суммы и цены
        с учетом лимитов биржи
        """
        # Базовая реализация, должна быть переопределена для каждой биржи
        return amount / price

    async def health_check(self) -> Dict[str, Any]:
        """Проверяет здоровье подключения к бирже"""
        try:
            start_time = datetime.now()
            account_info = await self.get_account_info()
            response_time = (datetime.now() - start_time).total_seconds() * 1000

            return {
                "status": "healthy",
                "response_time_ms": round(response_time, 2),
                "can_trade": account_info.get('canTrade', False),
                "balances_count": len(account_info.get('balances', []))
            }
        except Exception as e:
            self.logger.error("Exchange health check failed", error=str(e))
            return {
                "status": "unhealthy",
                "error": str(e)
            }