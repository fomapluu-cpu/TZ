"""
Production-ready точка входа Level Hunter Bot
"""

import asyncio
import logging
import sys
from pathlib import Path

# Добавляем корневую директорию в PYTHONPATH
root_dir = Path(__file__).parent
sys.path.insert(0, str(root_dir))

from engine.app import LevelHunterApp


async def main():
    """
    Основная точка входа Level Hunter Trading Bot
    """
    try:
        # Определяем путь к конфигурации
        config_path = root_dir / "configs"

        print("=" * 60)
        print("🎯 LEVEL HUNTER TRADING BOT")
        print("🤖 Production Ready Algorithmic Trading System")
        print("=" * 60)

        # Создаем и запускаем приложение
        app = LevelHunterApp(str(config_path))

        # Запускаем основное приложение
        await app.start()

    except KeyboardInterrupt:
        print("\n⚡ Received interrupt signal, shutting down gracefully...")
    except Exception as e:
        print(f"💥 Critical error: {e}")
        logging.exception("Application failed with exception")
        sys.exit(1)
    finally:
        print("👋 Level Hunter Bot shutdown complete.")


if __name__ == "__main__":
    # Настройка базового логирования для запуска
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('logs/boot.log')
        ]
    )

    # Запуск приложения
    asyncio.run(main())