"""
Production-ready главное приложение Level Hunter Bot с полной интеграцией Telegram
"""

import asyncio
import signal
import sys
import os
from datetime import datetime
from contextlib import asynccontextmanager
from typing import Optional, Dict, Any, List

from engine.dependency_container import DependencyContainer
from engine.orchestrator import Orchestrator
from api.telegram.bot import TelegramBot
from utils.config_loader import ConfigLoader, Config


class LevelHunterApp:
    """
    Production-ready главное приложение Level Hunter Trading Bot
    с полной интеграцией Telegram управления
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path
        self.container: Optional[DependencyContainer] = None
        self.orchestrator: Optional[Orchestrator] = None
        self.telegram_bot: Optional[TelegramBot] = None
        self._is_running = False
        self._start_time: Optional[datetime] = None
        self._shutdown_event = asyncio.Event()

    async def start(self) -> None:
        """Запускает приложение со всеми компонентами"""
        try:
            self._start_time = datetime.utcnow()
            print("🚀 Starting Level Hunter Trading Bot...")
            print(f"📁 Config path: {self.config_path or 'default'}")

            # Загрузка конфигурации
            config = ConfigLoader.load(self.config_path)

            # Инициализация DI контейнера
            self.container = DependencyContainer(self.config_path)
            await self.container.initialize()

            # Инициализация и запуск Telegram бота (если включен)
            if config.telegram.enabled:
                await self._setup_telegram_bot(config)
            else:
                print("ℹ️ Telegram bot is disabled in config")

            # Инициализация оркестратора
            self.orchestrator = Orchestrator(self.container)

            # Запуск оркестратора
            await self.orchestrator.start()

            self._is_running = True

            # Уведомление о успешном запуске
            startup_time = (datetime.utcnow() - self._start_time).total_seconds()
            print(f"✅ Level Hunter Bot started successfully in {startup_time:.2f}s!")

            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(
                    f"🤖 *Level Hunter Bot запущен!*\n\n"
                    f"• Версия: {config.app.version}\n"
                    f"• Окружение: {config.app.environment}\n"
                    f"• Время запуска: {startup_time:.2f}s\n"
                    f"• Торговля: {'🟢 Включена' if config.trading.enabled else '🔴 Выключена'}\n\n"
                    f"Используйте /start для управления."
                )

            # Настройка обработчиков сигналов
            self._setup_signal_handlers()

            # Ожидание shutdown сигнала
            await self._shutdown_event.wait()

        except Exception as e:
            print(f"❌ Failed to start Level Hunter Bot: {e}")
            await self._handle_startup_error(e)
            raise

    async def stop(self) -> None:
        """Корректно останавливает приложение"""
        if not self._is_running:
            return

        try:
            print("🛑 Stopping Level Hunter Bot...")

            # Уведомление в Telegram об остановке
            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(
                    "🛑 *Level Hunter Bot останавливается...*\n\n"
                    "Выполняется graceful shutdown всех компонентов."
                )

            # Остановка оркестратора
            if self.orchestrator:
                await self.orchestrator.stop()

            # Остановка Telegram бота
            if self.telegram_bot:
                await self.telegram_bot.stop()

            # Остановка DI контейнера
            if self.container:
                await self.container.shutdown()

            self._is_running = False
            uptime = (datetime.utcnow() - self._start_time).total_seconds() if self._start_time else 0

            print(f"✅ Level Hunter Bot stopped successfully!")
            print(f"⏱️ Total uptime: {uptime / 3600:.2f} hours")

            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(
                    f"✅ *Level Hunter Bot остановлен*\n\n"
                    f"Общее время работы: {uptime / 3600:.2f} часов"
                )

        except Exception as e:
            print(f"❌ Error during shutdown: {e}")
            # Принудительный выход при ошибке shutdown
            sys.exit(1)

    async def _setup_telegram_bot(self, config: Config) -> None:
        """Настраивает и запускает Telegram бота"""
        try:
            telegram_token = os.getenv("TELEGRAM_BOT_TOKEN") or config.telegram.token
            allowed_users_str = os.getenv("TELEGRAM_ALLOWED_USERS") or config.telegram.allowed_users

            if not telegram_token:
                print("⚠️ Telegram token not found, disabling Telegram bot")
                return

            if not allowed_users_str:
                print("⚠️ No allowed users specified, disabling Telegram bot")
                return

            # Парсим список разрешенных пользователей
            allowed_users = [int(user_id.strip()) for user_id in allowed_users_str.split(",") if user_id.strip()]

            if not allowed_users:
                print("⚠️ No valid user IDs found, disabling Telegram bot")
                return

            print(f"🤖 Initializing Telegram Bot for {len(allowed_users)} users...")

            self.telegram_bot = TelegramBot(
                container=self.container,
                token=telegram_token,
                allowed_users=allowed_users
            )

            await self.telegram_bot.start()
            print("✅ Telegram Bot started successfully!")

        except Exception as e:
            print(f"❌ Failed to start Telegram Bot: {e}")
            self.telegram_bot = None

    def _setup_signal_handlers(self) -> None:
        """Настраивает обработчики сигналов для graceful shutdown"""
        try:
            loop = asyncio.get_event_loop()

            for sig in [signal.SIGTERM, signal.SIGINT]:
                loop.add_signal_handler(sig, lambda s=sig: asyncio.create_task(self._handle_signal(s)))

            print("📡 Signal handlers configured for graceful shutdown")

        except (ValueError, OSError) as e:
            print(f"⚠️ Could not set up signal handlers: {e}")

    async def _handle_signal(self, signum: int) -> None:
        """Обработчик сигналов для graceful shutdown"""
        signal_name = {signal.SIGTERM: 'SIGTERM', signal.SIGINT: 'SIGINT'}.get(signum, str(signum))
        print(f"📡 Received {signal_name}, initiating shutdown...")

        if self.telegram_bot:
            await self.telegram_bot.broadcast_to_all_users(
                f"📡 *Получен сигнал {signal_name}*\n\n"
                "Инициируется graceful shutdown..."
            )

        self._shutdown_event.set()

    async def _handle_startup_error(self, error: Exception) -> None:
        """Обрабатывает ошибки запуска"""
        error_msg = f"💥 Startup failed: {error}"
        print(error_msg)

        if self.telegram_bot:
            try:
                await self.telegram_bot.broadcast_to_all_users(
                    f"💥 *Ошибка запуска бота*\n\n{str(error)}"
                )
            except:
                pass  # Игнорируем ошибки отправки при startup failure

        await self.stop()

    def is_running(self) -> bool:
        """Проверяет работает ли приложение"""
        return self._is_running

    async def get_status(self) -> Dict[str, Any]:
        """Возвращает детальный статус приложения"""
        if not self._is_running:
            return {"status": "not_running"}

        status = {
            "status": "running",
            "start_time": self._start_time.isoformat() if self._start_time else None,
            "uptime_seconds": (datetime.utcnow() - self._start_time).total_seconds() if self._start_time else 0,
            "components": {}
        }

        # Статус оркестратора
        if self.orchestrator:
            status["components"]["orchestrator"] = self.orchestrator.get_status()

        # Статус Telegram бота
        status["components"]["telegram_bot"] = {
            "enabled": self.telegram_bot is not None,
            "running": self.telegram_bot and self.telegram_bot._is_running
        }

        # Статус контейнера
        if self.container:
            status["components"]["dependency_container"] = self.container.get_health_status()

        return status

    async def restart(self) -> bool:
        """Перезапускает приложение"""
        try:
            print("🔄 Restarting Level Hunter Bot...")

            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users("🔄 *Перезапуск системы...*")

            await self.stop()
            await asyncio.sleep(2)  # Краткая пауза
            await self.start()

            return True

        except Exception as e:
            print(f"❌ Restart failed: {e}")
            if self.telegram_bot:
                await self.telegram_bot.broadcast_to_all_users(f"❌ *Ошибка перезапуска:* {e}")
            return False


@asynccontextmanager
async def create_app(config_path: Optional[str] = None):
    """
    Context manager для безопасного управления приложением
    """
    app = LevelHunterApp(config_path)

    try:
        await app.start()
        yield app
    finally:
        if app.is_running():
            await app.stop()


async def main():
    """Основная функция запуска приложения"""
    # Определяем путь к конфигурации из аргументов или используем по умолчанию
    config_path = None
    if len(sys.argv) > 1:
        config_path = sys.argv[1]
        print(f"📁 Using config from: {config_path}")

    app = LevelHunterApp(config_path)

    try:
        await app.start()
    except KeyboardInterrupt:
        print("\n👋 Received keyboard interrupt")
    except Exception as e:
        print(f"💥 Application failed: {e}")
        sys.exit(1)
    finally:
        if app.is_running():
            await app.stop()


if __name__ == "__main__":
    # Проверка обязательных переменных окружения
    required_env_vars = ["BINANCE_API_KEY", "BINANCE_API_SECRET"]
    missing_vars = [var for var in required_env_vars if not os.getenv(var)]

    if missing_vars:
        print(f"❌ Missing required environment variables: {', '.join(missing_vars)}")
        print("Please set them before running the bot.")
        sys.exit(1)

    # Запуск приложения
    asyncio.run(main())