# state_manager.py
