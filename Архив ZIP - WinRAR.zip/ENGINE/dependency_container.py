"""
Dependency Injection Container для Level Hunter Bot
Централизованное управление зависимостями и конфигурацией
"""

from typing import Any, Dict, Optional, Type
from functools import lru_cache

from infra.exchange.binance.client import BinanceClient
from infra.database.postgres import PostgreSQLClient
from infra.database.redis_cache import RedisCache
from infra.monitoring.logger import setup_logging
from infra.monitoring.metrics import MetricsCollector

from domain.strategies.level_hunter import LevelHunterStrategy, LevelHunterConfig
from domain.risk.risk_engine import RiskEngine
from domain.services.signal_engine import SignalEngine

from execution.order_manager import OrderManager
from execution.trade_executor import TradeExecutor

from utils.config_loader import ConfigLoader, Config


class DependencyContainer:
    """
    Production-ready DI контейнер с lazy loading и кэшированием
    """

    def __init__(self, config_path: Optional[str] = None):
        self._config_path = config_path
        self._instances: Dict[Type, Any] = {}
        self._initialized = False

    async def initialize(self) -> None:
        """Инициализирует все зависимости"""
        if self._initialized:
            return

        try:
            # 1. Загружаем конфигурацию
            config = self.get_config()

            # 2. Настраиваем логирование
            logger = self.get_logger()

            # 3. Инициализируем инфраструктурные компоненты
            await self.get_database()
            await self.get_redis()
            await self.get_exchange_client()

            # 4. Инициализируем бизнес-логику
            self.get_risk_engine()
            self.get_strategy()
            self.get_signal_engine()
            self.get_order_manager()
            self.get_trade_executor()

            self._initialized = True
            logger.info("Dependency container initialized successfully")

        except Exception as e:
            logger.error("Dependency container initialization failed", error=str(e))
            raise

    async def shutdown(self) -> None:
        """Корректно завершает работу всех компонентов"""
        logger = self.get_logger()
        logger.info("Shutting down dependency container...")

        # Закрываем соединения в правильном порядке
        if hasattr(self, '_redis') and self._instances.get(RedisCache):
            await self._instances[RedisCache].disconnect()

        if hasattr(self, '_database') and self._instances.get(PostgreSQLClient):
            await self._instances[PostgreSQLClient].disconnect()

        if hasattr(self, '_exchange_client') and self._instances.get(BinanceClient):
            await self._instances[BinanceClient].disconnect()

        self._instances.clear()
        self._initialized = False
        logger.info("Dependency container shutdown complete")

    @lru_cache()
    def get_config(self) -> Config:
        """Возвращает конфигурацию приложения"""
        return ConfigLoader.load(self._config_path)

    @lru_cache()
    def get_logger(self):
        """Возвращает логгер"""
        config = self.get_config()
        return setup_logging(config)

    async def get_database(self) -> PostgreSQLClient:
        """Возвращает клиент базы данных"""
        if PostgreSQLClient not in self._instances:
            config = self.get_config()
            logger = self.get_logger()

            self._instances[PostgreSQLClient] = PostgreSQLClient(config.database, logger)
            await self._instances[PostgreSQLClient].connect()

        return self._instances[PostgreSQLClient]

    async def get_redis(self) -> RedisCache:
        """Возвращает Redis кэш"""
        if RedisCache not in self._instances:
            config = self.get_config()
            logger = self.get_logger()

            self._instances[RedisCache] = RedisCache(config.redis, logger)
            await self._instances[RedisCache].connect()

        return self._instances[RedisCache]

    async def get_exchange_client(self) -> BinanceClient:
        """Возвращает клиент биржи"""
        if BinanceClient not in self._instances:
            config = self.get_config()
            logger = self.get_logger()

            self._instances[BinanceClient] = BinanceClient(config, logger)
            # Exchange client обычно не требует явного connect

        return self._instances[BinanceClient]

    def get_risk_engine(self) -> RiskEngine:
        """Возвращает risk engine"""
        if RiskEngine not in self._instances:
            config = self.get_config()
            logger = self.get_logger()

            self._instances[RiskEngine] = RiskEngine(config.level_hunter.risk, logger)

        return self._instances[RiskEngine]

    def get_strategy(self) -> LevelHunterStrategy:
        """Возвращает торговую стратегию"""
        if LevelHunterStrategy not in self._instances:
            config = self.get_config()
            logger = self.get_logger()

            strategy_config = LevelHunterConfig(**config.level_hunter.dict())
            self._instances[LevelHunterStrategy] = LevelHunterStrategy(strategy_config)

        return self._instances[LevelHunterStrategy]

    def get_signal_engine(self) -> SignalEngine:
        """Возвращает signal engine"""
        if SignalEngine not in self._instances:
            config = self.get_config()
            logger = self.get_logger()

            strategy = self.get_strategy()
            risk_engine = self.get_risk_engine()

            self._instances[SignalEngine] = SignalEngine(
                strategy=strategy,
                risk_engine=risk_engine,
                config=config.level_hunter,
                logger=logger
            )

        return self._instances[SignalEngine]

    def get_order_manager(self) -> OrderManager:
        """Возвращает order manager"""
        if OrderManager not in self._instances:
            config = self.get_config()
            logger = self.get_logger()
            exchange_client = self._instances.get(BinanceClient)

            self._instances[OrderManager] = OrderManager(
                exchange_client=exchange_client,
                config=config,
                logger=logger
            )

        return self._instances[OrderManager]

    def get_trade_executor(self) -> TradeExecutor:
        """Возвращает trade executor"""
        if TradeExecutor not in self._instances:
            config = self.get_config()
            logger = self.get_logger()

            signal_engine = self.get_signal_engine()
            order_manager = self.get_order_manager()
            risk_engine = self.get_risk_engine()

            self._instances[TradeExecutor] = TradeExecutor(
                signal_engine=signal_engine,
                order_manager=order_manager,
                risk_engine=risk_engine,
                config=config,
                logger=logger
            )

        return self._instances[TradeExecutor]

    def get_metrics_collector(self) -> MetricsCollector:
        """Возвращает сборщик метрик"""
        if MetricsCollector not in self._instances:
            config = self.get_config()
            logger = self.get_logger()

            self._instances[MetricsCollector] = MetricsCollector(config.monitoring, logger)

        return self._instances[MetricsCollector]

    def get_service(self, service_class: Type) -> Any:
        """Универсальный метод получения сервиса"""
        if service_class in self._instances:
            return self._instances[service_class]

        # Автоматическое создание для зарегистрированных сервисов
        creation_methods = {
            PostgreSQLClient: self.get_database,
            RedisCache: self.get_redis,
            BinanceClient: self.get_exchange_client,
            RiskEngine: self.get_risk_engine,
            LevelHunterStrategy: self.get_strategy,
            SignalEngine: self.get_signal_engine,
            OrderManager: self.get_order_manager,
            TradeExecutor: self.get_trade_executor,
            MetricsCollector: self.get_metrics_collector,
        }

        if service_class in creation_methods:
            return creation_methods[service_class]()

        raise ValueError(f"Service {service_class.__name__} not registered in container")

    def is_initialized(self) -> bool:
        """Проверяет инициализацию контейнера"""
        return self._initialized

    def get_health_status(self) -> Dict[str, Any]:
        """Возвращает статус здоровья всех компонентов"""
        health_status = {
            "container_initialized": self._initialized,
            "services": {}
        }

        for service_class, instance in self._instances.items():
            service_name = service_class.__name__

            if hasattr(instance, 'health_check'):
                try:
                    health_status["services"][service_name] = instance.health_check()
                except Exception as e:
                    health_status["services"][service_name] = {
                        "status": "error",
                        "error": str(e)
                    }
            else:
                health_status["services"][service_name] = {
                    "status": "unknown",
                    "reason": "Health check not implemented"
                }

        return health_status