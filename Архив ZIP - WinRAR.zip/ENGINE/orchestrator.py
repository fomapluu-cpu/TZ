"""
Production-ready Orchestrator для Level Hunter Bot
Главный координатор работы всех компонентов системы
"""

import asyncio
import signal
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Dict, List, Optional, Any
import contextlib

from engine.dependency_container import DependencyContainer
from domain.models.candle import Candle
from domain.models.signal import Signal
from utils.config_loader import Config


class Orchestrator:
    """
    Production-ready Orchestrator
    Управляет жизненным циклом приложения и координирует работу всех компонентов
    """

    def __init__(self, container: DependencyContainer):
        self.container = container
        self.config = container.get_config()
        self.logger = container.get_logger()

        # Состояние оркестратора
        self._is_running = False
        self._start_time: Optional[datetime] = None
        self._shutdown_event = asyncio.Event()

        # Компоненты
        self._signal_engine = None
        self._trade_executor = None
        self._order_manager = None
        self._risk_engine = None
        self._metrics_collector = None

        # Тasks
        self._background_tasks: List[asyncio.Task] = []

        # Обработчики сигналов
        self._setup_signal_handlers()

    def _setup_signal_handlers(self) -> None:
        """Настраивает обработчики сигналов для graceful shutdown"""
        try:
            for sig in [signal.SIGTERM, signal.SIGINT]:
                signal.signal(sig, self._signal_handler)
        except (ValueError, OSError) as e:
            self.logger.warning("Could not set up signal handlers", error=str(e))

    def _signal_handler(self, signum, frame) -> None:
        """Обработчик сигналов для graceful shutdown"""
        self.logger.info(f"Received signal {signum}, initiating shutdown...")
        self._shutdown_event.set()

    async def start(self) -> None:
        """Запускает оркестратор и все компоненты"""
        if self._is_running:
            self.logger.warning("Orchestrator is already running")
            return

        try:
            self.logger.info("Starting Level Hunter Bot Orchestrator...")
            self._start_time = datetime.utcnow()

            # Инициализация DI контейнера
            await self.container.initialize()

            # Получаем компоненты
            self._signal_engine = self.container.get_signal_engine()
            self._trade_executor = self.container.get_trade_executor()
            self._order_manager = self.container.get_order_manager()
            self._risk_engine = self.container.get_risk_engine()
            self._metrics_collector = self.container.get_metrics_collector()

            # Запускаем фоновые tasks
            await self._start_background_tasks()

            self._is_running = True
            self.logger.info("Orchestrator started successfully")

            # Основной цикл работы
            await self._main_loop()

        except Exception as e:
            self.logger.error("Failed to start orchestrator", error=str(e))
            await self.stop()
            raise

    async def stop(self) -> None:
        """Останавливает оркестратор и все компоненты"""
        if not self._is_running:
            return

        self.logger.info("Stopping Orchestrator...")
        self._is_running = False

        # Останавливаем фоновые tasks
        await self._stop_background_tasks()

        # Останавливаем DI контейнер
        await self.container.shutdown()

        self.logger.info("Orchestrator stopped successfully")

    async def _main_loop(self) -> None:
        """Основной цикл работы оркестратора"""
        self.logger.info("Starting main orchestration loop")

        while self._is_running and not self._shutdown_event.is_set():
            try:
                # Выполняем цикл обработки
                await self._processing_cycle()

                # Ждем перед следующим циклом
                await asyncio.sleep(5)  # 5 секунд между циклами

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("Error in main loop", error=str(e))
                await asyncio.sleep(10)  # Ждем 10 секунд при ошибке

    async def _processing_cycle(self) -> None:
        """Один цикл обработки данных"""
        cycle_start = datetime.utcnow()

        try:
            # 1. Сбор рыночных данных
            market_data = await self._collect_market_data()
            if not market_data:
                return

            # 2. Обработка данных и генерация сигналов
            signals = await self._process_market_data(market_data)

            # 3. Исполнение сигналов
            if signals:
                await self._execute_signals(signals)

            # 4. Мониторинг и health checks
            await self._perform_health_checks()

            # 5. Сбор метрик
            await self._collect_metrics()

            cycle_duration = (datetime.utcnow() - cycle_start).total_seconds()
            self.logger.debug(
                "Processing cycle completed",
                duration_seconds=cycle_duration,
                signals_generated=len(signals)
            )

        except Exception as e:
            self.logger.error("Processing cycle failed", error=str(e))
            # Не прерываем работу при ошибке в одном цикле

    async def _collect_market_data(self) -> Dict[str, List[Candle]]:
        """Сбор рыночных данных для анализа"""
        # В реальной реализации здесь будет подключение к market data feed
        # Сейчас возвращаем пустые данные как заглушку
        return {}

        # Пример реальной реализации:
        # market_data = {}
        # for symbol in self.config.trading.symbols:
        #     candles = await self.market_data_feed.get_candles(symbol, "1h", 100)
        #     market_data[symbol] = candles
        # return market_data

    async def _process_market_data(self, market_data: Dict[str, List[Candle]]) -> List[Signal]:
        """Обработка рыночных данных и генерация сигналов"""
        all_signals = []

        for symbol, candles in market_data.items():
            try:
                signals = await self._signal_engine.process_market_data(symbol, candles)
                all_signals.extend(signals)

                self.logger.debug(
                    "Market data processed",
                    symbol=symbol,
                    candles_count=len(candles),
                    signals_count=len(signals)
                )

            except Exception as e:
                self.logger.error(
                    "Market data processing failed",
                    symbol=symbol,
                    error=str(e)
                )

        return all_signals

    async def _execute_signals(self, signals: List[Signal]) -> None:
        """Исполнение торговых сигналов"""
        executed_count = 0

        for signal in signals:
            try:
                # Получаем текущий баланс портфеля
                portfolio_balance = await self._get_portfolio_balance()

                # Исполняем сигнал через trade executor
                success = await self._trade_executor.execute_signal(signal, portfolio_balance)

                if success:
                    executed_count += 1
                    self.logger.info(
                        "Signal executed successfully",
                        symbol=signal.symbol,
                        signal_type=signal.signal_type.value,
                        confidence=float(signal.confidence)
                    )
                else:
                    self.logger.warning(
                        "Signal execution failed",
                        symbol=signal.symbol,
                        signal_type=signal.signal_type.value
                    )

            except Exception as e:
                self.logger.error(
                    "Signal execution error",
                    symbol=signal.symbol,
                    error=str(e)
                )

        if executed_count > 0:
            self.logger.info(
                "Signals execution completed",
                total_signals=len(signals),
                executed=executed_count
            )

    async def _get_portfolio_balance(self) -> Decimal:
        """Получает текущий баланс портфеля"""
        # В реальной реализации здесь будет запрос к бирже или базе данных
        return Decimal('10000')  # Заглушка

    async def _perform_health_checks(self) -> None:
        """Выполняет health checks всех компонентов"""
        try:
            health_status = self.container.get_health_status()

            # Проверяем статус критических компонентов
            critical_services = ['PostgreSQLClient', 'RedisCache', 'BinanceClient']
            for service in critical_services:
                if service in health_status['services']:
                    status = health_status['services'][service].get('status', 'unknown')
                    if status != 'healthy':
                        self.logger.warning(
                            "Service health check failed",
                            service=service,
                            status=status
                        )

            # Логируем общий статус раз в 5 минут
            if datetime.utcnow().minute % 5 == 0:
                self.logger.info("Health check completed", status=health_status)

        except Exception as e:
            self.logger.error("Health check failed", error=str(e))

    async def _collect_metrics(self) -> None:
        """Сбор и публикация метрик"""
        try:
            if self._metrics_collector:
                # Собираем метрики производительности
                await self._metrics_collector.record_metrics()

        except Exception as e:
            self.logger.error("Metrics collection failed", error=str(e))

    async def _start_background_tasks(self) -> None:
        """Запускает фоновые tasks"""
        tasks = [
            self._cleanup_task(),
            self._monitoring_task(),
            self._order_sync_task()
        ]

        for task in tasks:
            self._background_tasks.append(asyncio.create_task(task))

    async def _stop_background_tasks(self) -> None:
        """Останавливает фоновые tasks"""
        for task in self._background_tasks:
            if not task.done():
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task

        self._background_tasks.clear()

    async def _cleanup_task(self) -> None:
        """Фоновая task для очистки устаревших данных"""
        while self._is_running and not self._shutdown_event.is_set():
            try:
                # Очистка истекших сигналов
                if self._signal_engine:
                    removed_count = await self._signal_engine.cleanup_expired_signals()
                    if removed_count > 0:
                        self.logger.debug("Expired signals cleaned", count=removed_count)

                # Очистка старых ордеров
                if self._order_manager:
                    await self._order_manager.cleanup_old_orders()

                await asyncio.sleep(300)  # Каждые 5 минут

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("Cleanup task error", error=str(e))
                await asyncio.sleep(60)

    async def _monitoring_task(self) -> None:
        """Фоновая task для мониторинга"""
        while self._is_running and not self._shutdown_event.is_set():
            try:
                # Мониторинг рисков
                if self._risk_engine:
                    risk_metrics = await self._risk_engine.get_risk_metrics()

                    # Проверка критических лимитов
                    if risk_metrics['max_drawdown'] > float(self.config.level_hunter.risk.max_drawdown) * 0.8:
                        self.logger.warning(
                            "Approaching max drawdown limit",
                            current_drawdown=risk_metrics['max_drawdown'],
                            limit=self.config.level_hunter.risk.max_drawdown
                        )

                # Мониторинг сигналов
                if self._signal_engine:
                    signal_stats = await self._signal_engine.get_signal_statistics()
                    if signal_stats['success_rate'] < 50:  # Low success rate
                        self.logger.warning(
                            "Low signal success rate",
                            success_rate=signal_stats['success_rate']
                        )

                await asyncio.sleep(60)  # Каждую минуту

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("Monitoring task error", error=str(e))
                await asyncio.sleep(60)

    async def _order_sync_task(self) -> None:
        """Фоновая task для синхронизации ордеров с биржей"""
        while self._is_running and not self._shutdown_event.is_set():
            try:
                if self._order_manager:
                    await self._order_manager.sync_with_exchange()

                await asyncio.sleep(30)  # Каждые 30 секунд

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("Order sync task error", error=str(e))
                await asyncio.sleep(30)

    def get_status(self) -> Dict[str, Any]:
        """Возвращает статус оркестратора"""
        uptime = (datetime.utcnow() - self._start_time) if self._start_time else timedelta(0)

        return {
            "running": self._is_running,
            "start_time": self._start_time.isoformat() if self._start_time else None,
            "uptime_seconds": uptime.total_seconds(),
            "background_tasks": len(self._background_tasks),
            "shutdown_requested": self._shutdown_event.is_set()
        }

    async def wait_for_shutdown(self) -> None:
        """Ожидает сигнала shutdown"""
        await self._shutdown_event.wait()