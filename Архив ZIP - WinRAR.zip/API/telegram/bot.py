"""
Production-ready Telegram Bot для управления Level Hunter Bot
Панель управления, мониторинг и управление в реальном времени
"""

import asyncio
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Any
import json

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes
)

from engine.dependency_container import DependencyContainer
from domain.models.order import Order, OrderStatus
from domain.models.position import Position
from domain.services.signal_engine import SignalEngine
from execution.trade_executor import TradeExecutor
from execution.order_manager import OrderManager
from domain.risk.risk_engine import RiskEngine


class TelegramBot:
    """
    Production-ready Telegram Bot для управления торговым ботом
    """

    def __init__(self, container: DependencyContainer, token: str, allowed_users: List[int]):
        self.container = container
        self.token = token
        self.allowed_users = allowed_users
        self.application: Optional[Application] = None

        # Компоненты
        self.signal_engine: Optional[SignalEngine] = None
        self.trade_executor: Optional[TradeExecutor] = None
        self.order_manager: Optional[OrderManager] = None
        self.risk_engine: Optional[RiskEngine] = None

        # Состояние бота
        self._is_running = False
        self._user_sessions: Dict[int, Dict] = {}  # user_id -> session_data

    async def start(self) -> None:
        """Запускает Telegram бота"""
        try:
            # Получаем компоненты из контейнера
            self.signal_engine = self.container.get_signal_engine()
            self.trade_executor = self.container.get_trade_executor()
            self.order_manager = self.container.get_order_manager()
            self.risk_engine = self.container.get_risk_engine()

            # Создаем приложение Telegram
            self.application = Application.builder().token(self.token).build()

            # Регистрируем обработчики
            self._register_handlers()

            # Запускаем бота
            await self.application.initialize()
            await self.application.start()
            await self.application.updater.start_polling()

            self._is_running = True
            print("✅ Telegram Bot started successfully!")

            # Запускаем фоновые tasks
            asyncio.create_task(self._status_notifications_task())

        except Exception as e:
            print(f"❌ Failed to start Telegram Bot: {e}")
            raise

    async def stop(self) -> None:
        """Останавливает Telegram бота"""
        if self.application:
            await self.application.updater.stop()
            await self.application.stop()
            await self.application.shutdown()

        self._is_running = False
        print("✅ Telegram Bot stopped successfully!")

    def _register_handlers(self) -> None:
        """Регистрирует обработчики команд"""
        # Команды
        self.application.add_handler(CommandHandler("start", self._start_command))
        self.application.add_handler(CommandHandler("status", self._status_command))
        self.application.add_handler(CommandHandler("portfolio", self._portfolio_command))
        self.application.add_handler(CommandHandler("orders", self._orders_command))
        self.application.add_handler(CommandHandler("signals", self._signals_command))
        self.application.add_handler(CommandHandler("risk", self._risk_command))
        self.application.add_handler(CommandHandler("settings", self._settings_command))

        # Callback queries (кнопки)
        self.application.add_handler(CallbackQueryHandler(self._button_handler))

        # Сообщения
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self._message_handler))

    async def _start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик команды /start"""
        user_id = update.effective_user.id

        if not await self._is_user_allowed(user_id):
            await update.message.reply_text("❌ Доступ запрещен.")
            return

        welcome_text = """
🤖 *Level Hunter Trading Bot*

*Доступные команды:*

📊 /status - Общий статус системы
💼 /portfolio - Портфель и позиции
📋 /orders - Активные ордера
🎯 /signals - Торговые сигналы
⚠️ /risk - Управление рисками
⚙️ /settings - Настройки

Используйте кнопки ниже для быстрого доступа:
        """

        keyboard = [
            [
                InlineKeyboardButton("📊 Статус", callback_data="status"),
                InlineKeyboardButton("💼 Портфель", callback_data="portfolio")
            ],
            [
                InlineKeyboardButton("📋 Ордера", callback_data="orders"),
                InlineKeyboardButton("🎯 Сигналы", callback_data="signals")
            ],
            [
                InlineKeyboardButton("⚠️ Риски", callback_data="risk"),
                InlineKeyboardButton("⚙️ Настройки", callback_data="settings")
            ]
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode='Markdown')

    async def _status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик команды /status"""
        user_id = update.effective_user.id

        if not await self._is_user_allowed(user_id):
            await update.message.reply_text("❌ Доступ запрещен.")
            return

        status_text = await self._get_system_status()
        await update.message.reply_text(status_text, parse_mode='Markdown')

    async def _portfolio_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик команды /portfolio"""
        user_id = update.effective_user.id

        if not await self._is_user_allowed(user_id):
            await update.message.reply_text("❌ Доступ запрещен.")
            return

        portfolio_text = await self._get_portfolio_info()
        await update.message.reply_text(portfolio_text, parse_mode='Markdown')

    async def _orders_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик команды /orders"""
        user_id = update.effective_user.id

        if not await self._is_user_allowed(user_id):
            await update.message.reply_text("❌ Доступ запрещен.")
            return

        orders_text = await self._get_orders_info()
        await update.message.reply_text(orders_text, parse_mode='Markdown')

    async def _signals_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик команды /signals"""
        user_id = update.effective_user.id

        if not await self._is_user_allowed(user_id):
            await update.message.reply_text("❌ Доступ запрещен.")
            return

        signals_text = await self._get_signals_info()
        await update.message.reply_text(signals_text, parse_mode='Markdown')

    async def _risk_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик команды /risk"""
        user_id = update.effective_user.id

        if not await self._is_user_allowed(user_id):
            await update.message.reply_text("❌ Доступ запрещен.")
            return

        risk_text = await self._get_risk_info()
        await update.message.reply_text(risk_text, parse_mode='Markdown')

    async def _settings_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик команды /settings"""
        user_id = update.effective_user.id

        if not await self._is_user_allowed(user_id):
            await update.message.reply_text("❌ Доступ запрещен.")
            return

        settings_text = await self._get_settings_info()
        await update.message.reply_text(settings_text, parse_mode='Markdown')

    async def _button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик нажатий на кнопки"""
        query = update.callback_query
        await query.answer()

        user_id = query.from_user.id
        if not await self._is_user_allowed(user_id):
            await query.edit_message_text("❌ Доступ запрещен.")
            return

        action = query.data

        if action == "status":
            text = await self._get_system_status()
        elif action == "portfolio":
            text = await self._get_portfolio_info()
        elif action == "orders":
            text = await self._get_orders_info()
        elif action == "signals":
            text = await self._get_signals_info()
        elif action == "risk":
            text = await self._get_risk_info()
        elif action == "settings":
            text = await self._get_settings_info()
        else:
            text = "❌ Неизвестная команда"

        # Создаем клавиатуру для возврата
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode='Markdown')

    async def _message_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик текстовых сообщений"""
        user_id = update.effective_user.id

        if not await self._is_user_allowed(user_id):
            return

        text = update.message.text

        if text.lower() in ['статус', 'status']:
            await self._status_command(update, context)
        elif text.lower() in ['портфель', 'portfolio']:
            await self._portfolio_command(update, context)
        elif text.lower() in ['ордера', 'orders']:
            await self._orders_command(update, context)
        elif text.lower() in ['сигналы', 'signals']:
            await self._signals_command(update, context)
        elif text.lower() in ['риски', 'risk']:
            await self._risk_command(update, context)
        else:
            await update.message.reply_text(
                "Используйте команды из меню или кнопки для управления ботом."
            )

    async def _get_system_status(self) -> str:
        """Возвращает статус системы в формате Markdown"""
        try:
            # Получаем статус от оркестратора
            orchestrator = self.container.get_service(self.container.__class__.get_orchestrator)
            status = orchestrator.get_status() if orchestrator else {}

            # Получаем статистику сигналов
            signal_stats = await self.signal_engine.get_signal_statistics()

            # Получаем статистику ордеров
            order_stats = self.order_manager.get_order_statistics()

            status_text = f"""
🤖 *СИСТЕМНЫЙ СТАТУС*

🟢 *Состояние:* {'Работает' if status.get('running', False) else 'Остановлено'}
⏱️ *Аптайм:* {status.get('uptime_seconds', 0) / 3600:.1f} ч
📊 *Фоновых задач:* {status.get('background_tasks', 0)}

🎯 *Сигналы:*
   • Сгенерировано: {signal_stats.get('total_generated', 0)}
   • Исполнено: {signal_stats.get('total_executed', 0)}
   • Успешность: {signal_stats.get('success_rate', 0):.1f}%

📋 *Ордера:*
   • Активные: {order_stats.get('active_orders', 0)}
   • Всего создано: {order_stats.get('total_created', 0)}
   • Исполнено: {order_stats.get('total_filled', 0)}

💼 *Позиции:*
   • Активные: {len(await self.trade_executor.get_active_positions())}
   • Общий PnL: {order_stats.get('total_pnl', 0):.2f} USD

🔄 *Последнее обновление:* {datetime.now().strftime('%H:%M:%S')}
            """

            return status_text

        except Exception as e:
            return f"❌ Ошибка получения статуса: {str(e)}"

    async def _get_portfolio_info(self) -> str:
        """Возвращает информацию о портфеле"""
        try:
            positions = await self.trade_executor.get_active_positions()

            if not positions:
                return "💼 *ПОРТФЕЛЬ*\n\nНет активных позиций."

            portfolio_text = "💼 *АКТИВНЫЕ ПОЗИЦИИ*\n\n"
            total_pnl = Decimal('0')

            for symbol, position in positions.items():
                pnl_percent = position.pnl_percentage
                total_pnl += position.total_pnl

                portfolio_text += f"""
📈 *{symbol}*
   • Сторона: {position.side.value}
   • Количество: {float(position.quantity):.6f}
   • Цена входа: ${float(position.entry_price):.2f}
   • Текущая цена: ${float(position.current_price):.2f}
   • PnL: ${float(position.total_pnl):.2f} ({float(pnl_percent):.2f}%)
   • Стоп-лосс: {f'${float(position.stop_loss):.2f}' if position.stop_loss else 'Не установлен'}
                """

            portfolio_text += f"\n💰 *Общий PnL:* ${float(total_pnl):.2f}"

            return portfolio_text

        except Exception as e:
            return f"❌ Ошибка получения портфеля: {str(e)}"

    async def _get_orders_info(self) -> str:
        """Возвращает информацию об ордерах"""
        try:
            orders_text = "📋 *АКТИВНЫЕ ОРДЕРА*\n\n"
            has_orders = False

            for symbol in self.container.get_config().trading.symbols:
                orders = await self.order_manager.get_orders_by_symbol(symbol)
                active_orders = [o for o in orders if o.is_active]

                if active_orders:
                    has_orders = True
                    orders_text += f"*{symbol}:*\n"

                    for order in active_orders[:5]:  # Показываем первые 5 ордеров
                        orders_text += f"""
   • {order.side.value} {order.order_type.value}
   • Количество: {float(order.quantity):.6f}
   • Цена: {f'${float(order.price):.2f}' if order.price else 'Market'}
   • Статус: {order.status.value}
   • ID: `{order.order_id}`
                        """
                    orders_text += "\n"

            if not has_orders:
                orders_text = "📋 *АКТИВНЫЕ ОРДЕРА*\n\nНет активных ордеров."

            # Добавляем кнопки управления
            keyboard = [
                [InlineKeyboardButton("🔄 Обновить", callback_data="orders")],
                [InlineKeyboardButton("❌ Отменить все", callback_data="cancel_all_orders")]
            ]

            return orders_text

        except Exception as e:
            return f"❌ Ошибка получения ордеров: {str(e)}"

    async def _get_signals_info(self) -> str:
        """Возвращает информацию о сигналах"""
        try:
            signals = await self.signal_engine.get_active_signals()
            signal_stats = await self.signal_engine.get_signal_statistics()

            signals_text = f"""
🎯 *ТОРГОВЫЕ СИГНАЛЫ*

📊 *Статистика:*
   • Всего сгенерировано: {signal_stats.get('total_generated', 0)}
   • Успешно исполнено: {signal_stats.get('total_executed', 0)}
   • Отклонено: {signal_stats.get('total_rejected', 0)}
   • Успешность: {signal_stats.get('success_rate', 0):.1f}%

🔍 *Активные сигналы:*
            """

            has_active_signals = False
            for symbol, symbol_signals in signals.items():
                if symbol_signals:
                    has_active_signals = True
                    signals_text += f"\n*{symbol}:*\n"

                    for signal in symbol_signals[:3]:  # Показываем первые 3 сигнала
                        signals_text += f"""
   • Тип: {signal.signal_type.value}
   • Уровень: ${float(signal.price_level):.2f}
   • Уверенность: {float(signal.confidence * 100):.1f}%
   • Сила: {signal.strength.value}
                        """

            if not has_active_signals:
                signals_text += "\nНет активных сигналов."

            return signals_text

        except Exception as e:
            return f"❌ Ошибка получения сигналов: {str(e)}"

    async def _get_risk_info(self) -> str:
        """Возвращает информацию о рисках"""
        try:
            risk_metrics = await self.risk_engine.get_risk_metrics()

            risk_text = f"""
⚠️ *УПРАВЛЕНИЕ РИСКАМИ*

📉 *Метрики рисков:*
   • Дневной PnL: ${risk_metrics.get('daily_pnl', 0):.2f}
   • Макс. просадка: {risk_metrics.get('max_drawdown', 0):.2f}%
   • Активные позиции: {risk_metrics.get('open_positions_count', 0)}
   • Активные ордера: {risk_metrics.get('open_orders_count', 0)}

🎯 *Лимиты:*
   • Макс. просадка: {self.container.get_config().level_hunter.risk.max_drawdown}%
   • Дневной лимит убытков: {self.container.get_config().level_hunter.risk.daily_loss_limit}%
   • Макс. позиция: {self.container.get_config().level_hunter.risk.max_position_per_trade}%

🛡️ *Защита:*
   • Риск-менеджмент: {'🟢 Активен' if risk_metrics.get('daily_pnl', 0) > -1000 else '🔴 Отключен'}
   • Stop-loss ордера: {'🟢 Активны' if self.container.get_config().level_hunter.use_stop_orders else '🔴 Отключены'}
            """

            # Добавляем кнопки управления рисками
            keyboard = [
                [InlineKeyboardButton("🔄 Обновить", callback_data="risk")],
                [InlineKeyboardButton("🛑 Экстренная остановка", callback_data="emergency_stop")]
            ]

            return risk_text

        except Exception as e:
            return f"❌ Ошибка получения информации о рисках: {str(e)}"

    async def _get_settings_info(self) -> str:
        """Возвращает информацию о настройках"""
        try:
            config = self.container.get_config()

            settings_text = f"""
⚙️ *НАСТРОЙКИ СИСТЕМЫ*

🤖 *Основные:*
   • Режим: {'🟢 Реальный' if not config.trading.demo_mode else '🟡 Демо'}
   • Торговля: {'🟢 Включена' if config.trading.enabled else '🔴 Выключена'}
   • Символы: {', '.join(config.trading.symbols)}

🎯 *Стратегия:*
   • Тип ордеров: {config.level_hunter.order_type}
   • Минимальная уверенность: {float(config.level_hunter.min_confidence * 100):.1f}%
   • Stop-loss ордера: {'🟢 Включены' if config.level_hunter.use_stop_orders else '🔴 Выключены'}

📊 *Риски:*
   • Макс. размер позиции: {config.level_hunter.risk.max_position_per_trade}%
   • Дневной лимит убытков: {config.level_hunter.risk.daily_loss_limit}%
   • Макс. просадка: {config.level_hunter.risk.max_drawdown}%
            """

            return settings_text

        except Exception as e:
            return f"❌ Ошибка получения настроек: {str(e)}"

    async def _is_user_allowed(self, user_id: int) -> bool:
        """Проверяет доступ пользователя"""
        return user_id in self.allowed_users

    async def _status_notifications_task(self) -> None:
        """Фоновая task для отправки уведомлений"""
        while self._is_running:
            try:
                # Здесь можно реализовать отправку периодических уведомлений
                # Например, при значительных изменениях PnL, критических рисках и т.д.
                await asyncio.sleep(60)  # Проверяем каждую минуту

            except Exception as e:
                print(f"Error in status notifications task: {e}")
                await asyncio.sleep(30)

    async def send_notification(self, user_id: int, message: str) -> None:
        """Отправляет уведомление пользователю"""
        try:
            if self.application and await self._is_user_allowed(user_id):
                await self.application.bot.send_message(
                    chat_id=user_id,
                    text=message,
                    parse_mode='Markdown'
                )
        except Exception as e:
            print(f"Failed to send notification: {e}")

    async def broadcast_to_all_users(self, message: str) -> None:
        """Отправляет сообщение всем пользователям"""
        for user_id in self.allowed_users:
            await self.send_notification(user_id, message)